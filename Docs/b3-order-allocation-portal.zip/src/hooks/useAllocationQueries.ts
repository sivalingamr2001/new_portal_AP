import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { AllocationHeader, AllocationLine, FulfillmentRecord } from '@types'
import {
  mockAllocationHeaders,
  mockAllocationLines,
  mockActivityLogs,
  mockDashboardKPI,
  mockMonthlyCancellations,
  mockTerritoryData,
  mockFulfillmentData,
} from '@services/mockData'

// Simulated API delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// ===== Query Hooks =====

export const useAllocationHeaders = () => {
  return useQuery({
    queryKey: ['allocations', 'headers'],
    queryFn: async () => {
      await delay(300)
      return mockAllocationHeaders
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  })
}

export const useAllocationHeader = (id: string) => {
  return useQuery({
    queryKey: ['allocations', 'header', id],
    queryFn: async () => {
      await delay(200)
      return mockAllocationHeaders.find((h) => h.id === id) || null
    },
    staleTime: 1000 * 60 * 5,
    enabled: !!id,
  })
}

export const useAllocationLines = (headerIds?: string[]) => {
  return useQuery({
    queryKey: ['allocations', 'lines', headerIds],
    queryFn: async () => {
      await delay(300)
      if (headerIds && headerIds.length > 0) {
        return mockAllocationLines.filter((line) => headerIds.includes(line.allocationHeaderId))
      }
      return mockAllocationLines
    },
    staleTime: 1000 * 60 * 5,
  })
}

export const useAllocationLine = (id: string) => {
  return useQuery({
    queryKey: ['allocations', 'line', id],
    queryFn: async () => {
      await delay(200)
      return mockAllocationLines.find((l) => l.id === id) || null
    },
    staleTime: 1000 * 60 * 5,
    enabled: !!id,
  })
}

export const useDashboardKPI = () => {
  return useQuery({
    queryKey: ['dashboard', 'kpi'],
    queryFn: async () => {
      await delay(400)
      return mockDashboardKPI
    },
    staleTime: 1000 * 60 * 10,
  })
}

export const useMonthlyCancellations = () => {
  return useQuery({
    queryKey: ['dashboard', 'monthly-cancellations'],
    queryFn: async () => {
      await delay(400)
      return mockMonthlyCancellations
    },
    staleTime: 1000 * 60 * 10,
  })
}

export const useTerritoryData = () => {
  return useQuery({
    queryKey: ['dashboard', 'territory-data'],
    queryFn: async () => {
      await delay(400)
      return mockTerritoryData
    },
    staleTime: 1000 * 60 * 10,
  })
}

export const useActivityLogs = () => {
  return useQuery({
    queryKey: ['dashboard', 'activity-logs'],
    queryFn: async () => {
      await delay(300)
      return mockActivityLogs
    },
    staleTime: 1000 * 60 * 5,
  })
}

export const useFulfillmentData = () => {
  return useQuery({
    queryKey: ['fulfillment', 'data'],
    queryFn: async () => {
      await delay(400)
      return mockFulfillmentData
    },
    staleTime: 1000 * 60 * 5,
  })
}

// ===== Mutation Hooks =====

export const useCreateAllocation = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async (data: { header: AllocationHeader; lines: AllocationLine[] }) => {
      await delay(500)
      const newHeader = {
        ...data.header,
        id: `ah_${Date.now()}`,
        requestId: `REQ-${Date.now()}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
      const newLines = data.lines.map((line, idx) => ({
        ...line,
        id: `al_${Date.now()}_${idx}`,
        allocationHeaderId: newHeader.id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }))

      return { header: newHeader, lines: newLines }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allocations'] })
      queryClient.invalidateQueries({ queryKey: ['dashboard'] })
    },
  })
}

export const useApproveAllocationLine = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async (data: {
      lineId: string
      approvedQuantity: number
      approverName: string
    }) => {
      await delay(500)
      const line = mockAllocationLines.find((l) => l.id === data.lineId)
      if (!line) throw new Error('Line not found')

      return {
        ...line,
        status: 'approved' as const,
        approvedQuantity: data.approvedQuantity,
        approvedBy: data.approverName,
        approvedDate: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allocations'] })
      queryClient.invalidateQueries({ queryKey: ['dashboard'] })
    },
  })
}

export const useCancelAllocationLine = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async (data: {
      lineId: string
      cancelledQuantity: number
      reason: string
      cancelledBy: string
    }) => {
      await delay(500)
      const line = mockAllocationLines.find((l) => l.id === data.lineId)
      if (!line) throw new Error('Line not found')

      return {
        ...line,
        status: 'cancelled' as const,
        cancelledQuantity: data.cancelledQuantity,
        cancelledReason: data.reason,
        cancelledDate: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allocations'] })
      queryClient.invalidateQueries({ queryKey: ['dashboard'] })
    },
  })
}

export const useUpdateAllocationLine = () => {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async (data: Partial<AllocationLine> & { id: string }) => {
      await delay(300)
      const line = mockAllocationLines.find((l) => l.id === data.id)
      if (!line) throw new Error('Line not found')

      return {
        ...line,
        ...data,
        updatedAt: new Date().toISOString(),
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allocations'] })
    },
  })
}
