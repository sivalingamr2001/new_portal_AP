import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClientProvider, QueryClient } from '@tanstack/react-query'
import { AuthProvider } from './context/AuthContext'
import { ThemeProvider } from './context/ThemeContext'
import MainLayout from './layouts/MainLayout'
import LoginPage from './features/auth/LoginPage'
import DashboardPage from './features/dashboard/DashboardPage'
import AllocationListPage from './features/allocations/AllocationListPage'
import NewAllocationPage from './features/allocations/NewAllocationPage'
import ApprovalQueuePage from './features/approvals/ApprovalQueuePage'
import FulfillmentTrackingPage from './features/fulfillment/FulfillmentTrackingPage'
import AdminPage from './features/admin/AdminPage'
import AdminConfigPage from './features/admin/AdminConfigPage'
import AdminRolesPage from './features/admin/AdminRolesPage'
import AdminAuditPage from './features/admin/AdminAuditPage'
import ProtectedRoute from './components/ProtectedRoute'

// Create a client for TanStack Query
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
})

const App: React.FC = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<LoginPage />} />

              <Route element={<ProtectedRoute />}>
                <Route element={<MainLayout />}>
                  <Route path="/dashboard" element={<DashboardPage />} />
                  <Route path="/allocations/list" element={<AllocationListPage />} />
                  <Route path="/allocations/new" element={<NewAllocationPage />} />
                  <Route path="/approvals/pending" element={<ApprovalQueuePage />} />
                  <Route path="/fulfillment/tracking" element={<FulfillmentTrackingPage />} />

                  {/* Admin routes */}
                  <Route
                    path="/admin"
                    element={<ProtectedRoute requiredRole="system_admin" component={<AdminPage />} />}
                  />
                  <Route
                    path="/admin/config"
                    element={
                      <ProtectedRoute
                        requiredRole="system_admin"
                        component={<AdminConfigPage />}
                      />
                    }
                  />
                  <Route
                    path="/admin/roles"
                    element={
                      <ProtectedRoute requiredRole="system_admin" component={<AdminRolesPage />} />
                    }
                  />
                  <Route
                    path="/admin/audit"
                    element={
                      <ProtectedRoute
                        requiredRole="system_admin"
                        component={<AdminAuditPage />}
                      />
                    }
                  />
                </Route>
              </Route>

              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </BrowserRouter>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  )
}

export default App
