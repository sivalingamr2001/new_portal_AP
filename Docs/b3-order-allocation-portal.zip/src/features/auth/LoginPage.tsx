import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { Package, LogIn } from 'lucide-react'

const LoginPage: React.FC = () => {
  const { login, isLoading, error } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('sales@b3.com')
  const [password, setPassword] = useState('demo')
  const [localError, setLocalError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLocalError('')

    try {
      await login(email, password)
      navigate('/dashboard')
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'Login failed')
    }
  }

  const demoAccounts = [
    { email: 'sales@b3.com', role: 'Sales Rep' },
    { email: 'hod@b3.com', role: 'Head of Department' },
    { email: 'admin@b3.com', role: 'System Admin' },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center shadow-lg">
              <Package className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">B3</h1>
              <p className="text-sm text-foreground/60">Order Allocation Portal</p>
            </div>
          </div>
        </div>

        {/* Login Form */}
        <form
          onSubmit={handleSubmit}
          className="bg-card border border-border rounded-xl shadow-xl p-8 space-y-6"
        >
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-2">Welcome Back</h2>
            <p className="text-sm text-foreground/60">
              Sign in to access your allocation dashboard
            </p>
          </div>

          {(error || localError) && (
            <div className="p-4 bg-danger/10 border border-danger/30 rounded-lg">
              <p className="text-sm text-danger font-medium">{error || localError}</p>
            </div>
          )}

          {/* Email Field */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
              placeholder="Enter your email"
              required
            />
          </div>

          {/* Password Field */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
              placeholder="Enter your password"
              required
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-primary text-white font-semibold rounded-lg hover:bg-primary-dark disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Signing in...
              </>
            ) : (
              <>
                <LogIn className="w-5 h-5" />
                Sign In
              </>
            )}
          </button>

          {/* Demo Accounts Section */}
          <div className="pt-6 border-t border-border">
            <p className="text-xs text-foreground/60 mb-4 font-medium">DEMO ACCOUNTS</p>
            <div className="space-y-2">
              {demoAccounts.map((account) => (
                <button
                  key={account.email}
                  type="button"
                  onClick={() => {
                    setEmail(account.email)
                    setPassword('demo')
                  }}
                  className="w-full px-3 py-2 text-sm bg-background hover:bg-background/80 border border-border rounded-lg transition-colors text-left"
                >
                  <p className="font-medium text-foreground/80">{account.role}</p>
                  <p className="text-xs text-foreground/60">{account.email}</p>
                </button>
              ))}
            </div>
          </div>
        </form>

        {/* Footer */}
        <p className="text-center text-xs text-foreground/50 mt-8">
          B3 Order Allocation Portal v1.0.0
        </p>
      </div>
    </div>
  )
}

export default LoginPage
