import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { useFulfillmentData } from '../../hooks/useAllocationQueries'
import { ChevronDown, TrendingUp, TrendingDown, Search, Filter } from 'lucide-react'
import { cn } from '../../lib/utils'

const FulfillmentTrackingPage: React.FC = () => {
  const { data: fulfillmentData, isLoading } = useFulfillmentData()
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState('')

  const filteredData = fulfillmentData?.filter((record) =>
    record.allocationHeaderId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    record.itemCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
    record.soNumber?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getVarianceStatus = (variance: number) => {
    if (variance === 0) {
      return { label: 'Exact Match', color: 'bg-success/10 text-success', icon: '✓' }
    } else if (variance > 0) {
      return { label: 'Under Fulfilled', color: 'bg-warning/10 text-warning', icon: '↓' }
    } else {
      return { label: 'Over Fulfilled', color: 'bg-danger/10 text-danger', icon: '↑' }
    }
  }

  if (isLoading) {
    return (
      <div className="elevated-card p-8 text-center">
        <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-primary/10 rounded-full">
          <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
        <p className="text-foreground/60">Loading fulfillment data...</p>
      </div>
    )
  }

  const summaryStats = {
    total: fulfillmentData?.length || 0,
    exact: fulfillmentData?.filter((r) => r.variance === 0).length || 0,
    under: fulfillmentData?.filter((r) => r.variance > 0).length || 0,
    over: fulfillmentData?.filter((r) => r.variance < 0).length || 0,
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Fulfillment Tracking</h1>
        <p className="text-foreground/60">Monitor allocations vs sales orders and track variances</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0 }}
          className="elevated-card p-4"
        >
          <p className="text-sm text-foreground/60 mb-2">Total Records</p>
          <p className="text-3xl font-bold text-foreground">{summaryStats.total}</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="elevated-card p-4"
        >
          <p className="text-sm text-foreground/60 mb-2">Exact Match</p>
          <p className="text-3xl font-bold text-success">{summaryStats.exact}</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="elevated-card p-4"
        >
          <p className="text-sm text-foreground/60 mb-2">Under Fulfilled</p>
          <p className="text-3xl font-bold text-warning">{summaryStats.under}</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="elevated-card p-4"
        >
          <p className="text-sm text-foreground/60 mb-2">Over Fulfilled</p>
          <p className="text-3xl font-bold text-danger">{summaryStats.over}</p>
        </motion.div>
      </div>

      {/* Search & Filter */}
      <div className="mb-6 flex items-center gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-foreground/40" />
          <input
            type="text"
            placeholder="Search by allocation ID, item code, or SO number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>
      </div>

      {/* Fulfillment Records */}
      <div className="space-y-4">
        {filteredData && filteredData.length > 0 ? (
          filteredData.map((record, idx) => {
            const varianceStatus = getVarianceStatus(record.variance)
            const isExpanded = expandedId === record.id

            return (
              <motion.div
                key={record.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: idx * 0.05 }}
                className="elevated-card overflow-hidden"
              >
                {/* Main Row */}
                <button
                  onClick={() => setExpandedId(isExpanded ? null : record.id)}
                  className="w-full p-6 flex items-center gap-4 hover:bg-background/50 transition-colors text-left"
                >
                  <ChevronDown
                    className={cn(
                      'w-5 h-5 text-foreground/60 transition-transform flex-shrink-0',
                      isExpanded && 'rotate-180',
                    )}
                  />

                  {/* Main Content */}
                  <div className="flex-1 min-w-0 grid grid-cols-2 md:grid-cols-5 gap-4">
                    <div>
                      <p className="text-xs text-foreground/60 mb-1">Allocation ID</p>
                      <p className="font-semibold text-primary text-sm">
                        {record.allocationHeaderId}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-foreground/60 mb-1">Item</p>
                      <p className="font-semibold text-foreground text-sm">{record.itemCode}</p>
                    </div>
                    <div>
                      <p className="text-xs text-foreground/60 mb-1">Approved</p>
                      <p className="font-bold text-foreground text-sm">
                        {record.approvedQuantity}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-foreground/60 mb-1">SO Qty</p>
                      <p className="font-bold text-foreground text-sm">
                        {record.soQuantity || '-'}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-foreground/60 mb-1">Variance</p>
                      <div className="flex items-center justify-end gap-2">
                        {record.variance > 0 && (
                          <TrendingDown className="w-4 h-4 text-warning" />
                        )}
                        {record.variance < 0 && (
                          <TrendingUp className="w-4 h-4 text-danger" />
                        )}
                        <span
                          className={cn(
                            'px-2 py-1 rounded text-sm font-bold',
                            varianceStatus.color,
                          )}
                        >
                          {record.variance > 0 ? '+' : ''}{record.variance}
                        </span>
                      </div>
                    </div>
                  </div>
                </button>

                {/* Expanded Details */}
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="border-t border-border bg-background/30 p-6"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Allocation Details */}
                      <div>
                        <h3 className="font-semibold text-foreground mb-4">Allocation Details</h3>
                        <div className="space-y-3 text-sm">
                          <div>
                            <p className="text-foreground/60">Allocation Line ID</p>
                            <p className="font-medium text-foreground">{record.allocationLineId}</p>
                          </div>
                          <div>
                            <p className="text-foreground/60">Item Code</p>
                            <p className="font-medium text-foreground">{record.itemCode}</p>
                          </div>
                          <div>
                            <p className="text-foreground/60">Approved Quantity</p>
                            <p className="font-medium text-foreground">{record.approvedQuantity}</p>
                          </div>
                        </div>
                      </div>

                      {/* SO Details */}
                      <div>
                        <h3 className="font-semibold text-foreground mb-4">Sales Order Details</h3>
                        <div className="space-y-3 text-sm">
                          <div>
                            <p className="text-foreground/60">SO Number</p>
                            <p className="font-medium text-foreground">
                              {record.soNumber || 'Not Synced'}
                            </p>
                          </div>
                          <div>
                            <p className="text-foreground/60">SO Quantity</p>
                            <p className="font-medium text-foreground">
                              {record.soQuantity || '-'}
                            </p>
                          </div>
                          <div>
                            <p className="text-foreground/60">Order Date</p>
                            <p className="font-medium text-foreground">
                              {record.orderDate
                                ? new Date(record.orderDate).toLocaleDateString()
                                : '-'}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Variance Analysis */}
                      <div className="md:col-span-2">
                        <h3 className="font-semibold text-foreground mb-4">Variance Analysis</h3>
                        <div className="bg-background/50 rounded-lg p-4 space-y-3">
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-foreground/60">Variance Amount</p>
                            <span className={cn('px-3 py-1 rounded font-bold', varianceStatus.color)}>
                              {record.variance > 0 ? '+' : ''}{record.variance}{' '}
                              {varianceStatus.label}
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-foreground/60">ERP Sync Status</p>
                            <span className="px-3 py-1 rounded text-sm font-medium bg-success/10 text-success">
                              {record.erp_sync_status || 'Pending'}
                            </span>
                          </div>
                          {record.erp_sync_date && (
                            <div className="flex items-center justify-between">
                              <p className="text-sm text-foreground/60">Sync Date</p>
                              <p className="text-sm font-medium text-foreground">
                                {new Date(record.erp_sync_date).toLocaleString()}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            )
          })
        ) : (
          <div className="elevated-card p-12 text-center">
            <Search className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">
              No fulfillment records found
            </h3>
            <p className="text-foreground/60">Try adjusting your search criteria</p>
          </div>
        )}
      </div>
    </motion.div>
  )
}

export default FulfillmentTrackingPage
