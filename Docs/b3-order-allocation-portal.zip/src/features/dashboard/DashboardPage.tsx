import React from 'react'
import { motion } from 'framer-motion'
import { 
  Clock, 
  CheckCircle, 
  XCircle, 
  CheckSquare,
  TrendingDown,
  BarChart3,
  Activity,
} from 'lucide-react'
import { 
  useDashboardKPI, 
  useMonthlyCancellations, 
  useTerritoryData,
  useActivityLogs,
} from '../../hooks/useAllocationQueries'
import KPICard from '../../components/KPICard'
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from 'recharts'
import { cn } from '../../lib/utils'

const DashboardPage: React.FC = () => {
  const { data: kpi, isLoading: kpiLoading } = useDashboardKPI()
  const { data: monthlyCancellations, isLoading: monthlyLoading } = useMonthlyCancellations()
  const { data: territoryData, isLoading: territoryLoading } = useTerritoryData()
  const { data: activityLogs, isLoading: activityLoading } = useActivityLogs()

  const chartContainerClasses = 'bg-card border border-border rounded-lg p-6 shadow-sm'
  const titleClasses = 'text-lg font-semibold text-foreground mb-6'

  if (kpiLoading || monthlyLoading || territoryLoading || activityLoading) {
    return (
      <div className="space-y-6">
        {/* KPI Skeleton */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="elevated-card p-6 animate-pulse">
              <div className="h-6 bg-foreground/10 rounded mb-4 w-32" />
              <div className="h-8 bg-foreground/10 rounded w-20" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  const getTrendColor = (trend: number) => (trend >= 0 ? 'success' : 'danger')

  return (
    <div className="space-y-6">
      {/* Page Title */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
        <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
        <p className="text-foreground/60">
          Overview of allocation requests and fulfillment metrics
        </p>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          label="Pending Requests"
          value={kpi?.pending || 0}
          icon={Clock}
          color="warning"
          description="Awaiting approval"
          delay={0}
        />
        <KPICard
          label="Approved Requests"
          value={kpi?.approved || 0}
          icon={CheckCircle}
          color="success"
          description="Ready for fulfillment"
          delay={0.1}
        />
        <KPICard
          label="Cancelled Requests"
          value={kpi?.cancelled || 0}
          icon={XCircle}
          color="danger"
          description="No action required"
          delay={0.2}
        />
        <KPICard
          label="Fulfilled Requests"
          value={kpi?.fulfilled || 0}
          icon={CheckSquare}
          color="primary"
          description="Completed orders"
          delay={0.3}
        />
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Trends */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.4 }}
          className={chartContainerClasses}
        >
          <h2 className={titleClasses}>Monthly Allocation Trends</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyCancellations}>
              <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.1} />
              <XAxis dataKey="month" stroke="currentColor" opacity={0.6} />
              <YAxis stroke="currentColor" opacity={0.6} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'var(--color-card)',
                  border: '1px solid var(--color-border)',
                  borderRadius: '0.5rem',
                }}
                cursor={{ fill: 'rgba(0,0,0,0.1)' }}
              />
              <Legend />
              <Bar dataKey="approved" fill="#16a34a" radius={[8, 8, 0, 0]} />
              <Bar dataKey="cancelled" fill="#dc2626" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Territory Performance */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.4 }}
          className={chartContainerClasses}
        >
          <h2 className={titleClasses}>Territory Performance Heat Map</h2>
          <div className="space-y-3">
            {territoryData?.map((territory, idx) => {
              const intensity = territory.allocations / 10
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium text-foreground">{territory.territory}</span>
                    <span className="text-foreground/60">{territory.allocations} allocations</span>
                  </div>
                  <div className="h-2 bg-background rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(intensity * 10, 100)}%` }}
                      transition={{ delay: 0.5 + idx * 0.1, duration: 0.6 }}
                      className={cn(
                        'h-full rounded-full transition-colors',
                        intensity > 0.7 ? 'bg-danger' : intensity > 0.4 ? 'bg-warning' : 'bg-success',
                      )}
                    />
                  </div>
                </div>
              )
            })}
          </div>
        </motion.div>
      </div>

      {/* Activity Timeline */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.4 }}
        className={chartContainerClasses}
      >
        <h2 className={titleClasses}>Recent Activity</h2>
        <div className="space-y-4">
          {activityLogs?.slice(0, 8).map((log, idx) => {
            const actionColors = {
              created: 'bg-info/10 text-info',
              approved: 'bg-success/10 text-success',
              cancelled: 'bg-danger/10 text-danger',
              fulfilled: 'bg-primary/10 text-primary',
            }

            const actionIcons = {
              created: BarChart3,
              approved: CheckCircle,
              cancelled: XCircle,
              fulfilled: CheckSquare,
            }

            const ActionIcon = actionIcons[log.action]
            const actionColor = actionColors[log.action]

            return (
              <motion.div
                key={log.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + idx * 0.05, duration: 0.3 }}
                className="flex items-center gap-4 pb-4 border-b border-border/50 last:border-0"
              >
                <div className={cn('p-2 rounded-lg', actionColor)}>
                  <ActionIcon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {log.userName}
                    <span className="text-foreground/60 font-normal"> {log.action}</span>
                    <span className="text-foreground/60 font-normal"> {log.entityType}</span>
                  </p>
                  <p className="text-xs text-foreground/50">
                    {new Date(log.timestamp).toLocaleDateString()} at{' '}
                    {new Date(log.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              </motion.div>
            )
          })}
        </div>
      </motion.div>

      {/* Total Quantity Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.4 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-4"
      >
        <div className="elevated-card p-6">
          <div className="flex items-center gap-3 mb-2">
            <TrendingDown className="w-5 h-5 text-foreground/60" />
            <p className="text-sm text-foreground/60">Total Quantity</p>
          </div>
          <p className="text-3xl font-bold text-foreground">{kpi?.totalQuantity || 0}</p>
          <p className="text-xs text-foreground/50 mt-2">Units allocated</p>
        </div>

        <div className="elevated-card p-6">
          <div className="flex items-center gap-3 mb-2">
            <Activity className="w-5 h-5 text-foreground/60" />
            <p className="text-sm text-foreground/60">Avg. Approval Time</p>
          </div>
          <p className="text-3xl font-bold text-foreground">
            {kpi?.averageApprovalTime || 0}h
          </p>
          <p className="text-xs text-foreground/50 mt-2">Per request</p>
        </div>

        <div className="elevated-card p-6">
          <div className="flex items-center gap-3 mb-2">
            <CheckCircle className="w-5 h-5 text-foreground/60" />
            <p className="text-sm text-foreground/60">Success Rate</p>
          </div>
          <p className="text-3xl font-bold text-foreground">
            {kpi?.fulfilled && kpi?.pending
              ? Math.round((kpi.fulfilled / (kpi.fulfilled + kpi.pending)) * 100)
              : 0}
            %
          </p>
          <p className="text-xs text-foreground/50 mt-2">Fulfilled vs pending</p>
        </div>
      </motion.div>
    </div>
  )
}

export default DashboardPage
