import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { useAuth } from '../../context/AuthContext'
import {
  useAllocationHeaders,
  useAllocationLines,
  useApproveAllocationLine,
  useCancelAllocationLine,
} from '../../hooks/useAllocationQueries'
import portalConfig from '../../config/portalConfig'
import { AllocationHeader, LineStatus } from '../../types'
import {
  ChevronDown,
  CheckCircle,
  XCircle,
  Filter,
  AlertCircle,
} from 'lucide-react'
import { cn } from '../../lib/utils'

const ApprovalQueuePage: React.FC = () => {
  const { user } = useAuth()
  const { data: headers, isLoading: headersLoading } = useAllocationHeaders()
  const { data: allLines } = useAllocationLines()
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [selectedLines, setSelectedLines] = useState<Set<string>>(new Set())
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved'>('pending')
  const [showApprovalModal, setShowApprovalModal] = useState(false)
  const [selectedLineForApproval, setSelectedLineForApproval] = useState<string | null>(null)
  const [approvalFormData, setApprovalFormData] = useState({
    quantity: 0,
    reason: '',
    decision: 'approve' as 'approve' | 'cancel',
  })

  const approveLineM = useApproveAllocationLine()
  const cancelLineM = useCancelAllocationLine()

  // Filter pending allocations
  const pendingHeaders = headers?.filter(
    (h) => statusFilter === 'all' || (statusFilter === 'pending' && h.status === 'pending'),
  )

  const getStatusColor = (status: LineStatus) => {
    const config = portalConfig.statuses.line[status]
    const colorMap = {
      amber: 'bg-warning/10 text-warning',
      green: 'bg-success/10 text-success',
      red: 'bg-danger/10 text-danger',
    }
    return colorMap[config.color]
  }

  const getTerritoryLabel = (territory: string) => {
    return portalConfig.territories.find((t) => t.id === territory)?.label || territory
  }

  const getWarehouseLabel = (warehouse: string) => {
    return portalConfig.warehouses.find((w) => w.id === warehouse)?.label || warehouse
  }

  const handleApproveClick = (lineId: string) => {
    setSelectedLineForApproval(lineId)
    setApprovalFormData({ quantity: 0, reason: '', decision: 'approve' })
    setShowApprovalModal(true)
  }

  const handleCancelClick = (lineId: string) => {
    setSelectedLineForApproval(lineId)
    setApprovalFormData({ quantity: 0, reason: '', decision: 'cancel' })
    setShowApprovalModal(true)
  }

  const submitApproval = async () => {
    if (!selectedLineForApproval) return

    try {
      if (approvalFormData.decision === 'approve') {
        if (!approvalFormData.quantity) {
          alert('Please enter approved quantity')
          return
        }
        await approveLineM.mutateAsync({
          lineId: selectedLineForApproval,
          approvedQuantity: approvalFormData.quantity,
          approverName: user?.name || '',
        })
      } else {
        if (!approvalFormData.quantity || !approvalFormData.reason) {
          alert('Please enter quantity and cancellation reason')
          return
        }
        await cancelLineM.mutateAsync({
          lineId: selectedLineForApproval,
          cancelledQuantity: approvalFormData.quantity,
          reason: approvalFormData.reason,
          cancelledBy: user?.name || '',
        })
      }

      setShowApprovalModal(false)
      setSelectedLineForApproval(null)
    } catch (error) {
      alert('Failed to process approval')
    }
  }

  if (headersLoading) {
    return (
      <div className="elevated-card p-8 text-center">
        <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-primary/10 rounded-full">
          <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
        <p className="text-foreground/60">Loading approvals...</p>
      </div>
    )
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Approval Queue</h1>
        <p className="text-foreground/60">Review and approve allocation requests</p>
      </div>

      {/* Filter */}
      <div className="mb-6 flex items-center gap-4">
        <Filter className="w-5 h-5 text-foreground/60" />
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as any)}
          className="px-4 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
        >
          <option value="all">All Status</option>
          <option value="pending">Pending Only</option>
          <option value="approved">Approved</option>
        </select>
      </div>

      {/* Approvals List */}
      <div className="space-y-4">
        {pendingHeaders && pendingHeaders.length > 0 ? (
          pendingHeaders.map((header) => {
            const headerLines = allLines?.filter(
              (line) => line.allocationHeaderId === header.id,
            ) || []
            const isExpanded = expandedId === header.id

            return (
              <motion.div
                key={header.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="elevated-card overflow-hidden"
              >
                {/* Header Row */}
                <button
                  onClick={() => setExpandedId(isExpanded ? null : header.id)}
                  className="w-full p-6 flex items-center gap-4 hover:bg-background/50 transition-colors"
                >
                  <ChevronDown
                    className={cn(
                      'w-5 h-5 text-foreground/60 transition-transform',
                      isExpanded && 'rotate-180',
                    )}
                  />

                  <div className="flex-1 text-left min-w-0">
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="text-lg font-semibold text-foreground">
                        {header.requestId}
                      </h3>
                      <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                        {headerLines.length} lines
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-4 text-sm text-foreground/60">
                      {header.customerName && <span>{header.customerName}</span>}
                      <span>{getTerritoryLabel(header.territory)}</span>
                      <span>{new Date(header.createdDate).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <div className="text-right hidden md:block">
                    <p className="text-sm text-foreground/60">Total Qty</p>
                    <p className="text-2xl font-bold text-foreground">{header.totalQuantity}</p>
                  </div>
                </button>

                {/* Expanded Content */}
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="border-t border-border bg-background/30 p-6"
                  >
                    <div className="space-y-4">
                      {headerLines.map((line) => (
                        <motion.div
                          key={line.id}
                          className="border border-border rounded-lg p-4 bg-card/50"
                        >
                          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-4">
                            <div>
                              <p className="text-xs text-foreground/60 mb-1">Line</p>
                              <p className="font-semibold text-foreground">{line.lineNumber}</p>
                            </div>
                            <div>
                              <p className="text-xs text-foreground/60 mb-1">Item</p>
                              <p className="font-semibold text-foreground">{line.itemCode}</p>
                              <p className="text-xs text-foreground/60">
                                {getWarehouseLabel(line.warehouse)}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-foreground/60 mb-1">Requested</p>
                              <p className="text-xl font-bold text-foreground">
                                {line.requestedQuantity}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-foreground/60 mb-1">Target Date</p>
                              <p className="font-semibold text-foreground">
                                {new Date(line.targetDate).toLocaleDateString()}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-foreground/60 mb-1">Status</p>
                              <span className={cn('px-2 py-1 rounded text-xs font-medium', getStatusColor(line.status))}>
                                {portalConfig.statuses.line[line.status].label}
                              </span>
                            </div>
                          </div>

                          {line.status === 'pending' && (
                            <div className="flex gap-3">
                              <button
                                onClick={() => handleApproveClick(line.id)}
                                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-success/10 text-success hover:bg-success/20 font-semibold rounded-lg transition-colors"
                              >
                                <CheckCircle className="w-5 h-5" />
                                Approve
                              </button>
                              <button
                                onClick={() => handleCancelClick(line.id)}
                                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-danger/10 text-danger hover:bg-danger/20 font-semibold rounded-lg transition-colors"
                              >
                                <XCircle className="w-5 h-5" />
                                Cancel
                              </button>
                            </div>
                          )}
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </motion.div>
            )
          })
        ) : (
          <div className="elevated-card p-12 text-center">
            <AlertCircle className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No allocations to approve</h3>
            <p className="text-foreground/60">All pending allocations have been processed</p>
          </div>
        )}
      </div>

      {/* Approval Modal */}
      {showApprovalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-card border border-border rounded-lg shadow-xl max-w-md w-full p-6"
          >
            <h2 className="text-xl font-bold text-foreground mb-6">
              {approvalFormData.decision === 'approve' ? 'Approve Allocation' : 'Cancel Allocation'}
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  {approvalFormData.decision === 'approve'
                    ? 'Approved Quantity'
                    : 'Cancelled Quantity'}
                </label>
                <input
                  type="number"
                  value={approvalFormData.quantity}
                  onChange={(e) =>
                    setApprovalFormData({
                      ...approvalFormData,
                      quantity: parseInt(e.target.value) || 0,
                    })
                  }
                  min="1"
                  className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                  placeholder="Enter quantity"
                />
              </div>

              {approvalFormData.decision === 'cancel' && (
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Cancellation Reason
                  </label>
                  <select
                    value={approvalFormData.reason}
                    onChange={(e) =>
                      setApprovalFormData({ ...approvalFormData, reason: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                  >
                    <option value="">Select reason</option>
                    {portalConfig.cancellationReasons.map((reason) => (
                      <option key={reason.value} value={reason.value}>
                        {reason.label}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            <div className="flex gap-3 mt-8">
              <button
                onClick={() => setShowApprovalModal(false)}
                className="flex-1 px-4 py-2 bg-background border border-border rounded-lg text-foreground font-semibold hover:bg-background/80 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={submitApproval}
                disabled={approveLineM.isPending || cancelLineM.isPending}
                className={cn(
                  'flex-1 px-4 py-2 rounded-lg text-white font-semibold transition-colors',
                  approvalFormData.decision === 'approve'
                    ? 'bg-success hover:bg-success/90'
                    : 'bg-danger hover:bg-danger/90',
                  (approveLineM.isPending || cancelLineM.isPending) && 'opacity-50 cursor-not-allowed',
                )}
              >
                {approveLineM.isPending || cancelLineM.isPending ? 'Processing...' : 'Confirm'}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  )
}

export default ApprovalQueuePage
