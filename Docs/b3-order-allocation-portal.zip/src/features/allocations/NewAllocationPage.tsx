import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useAuth } from '../../context/AuthContext'
import { useCreateAllocation } from '../../hooks/useAllocationQueries'
import portalConfig from '../../config/portalConfig'
import { AllocationHeader, AllocationLine } from '../../types'
import {
  Plus,
  Trash2,
  Copy,
  ChevronRight,
  CheckCircle,
  AlertCircle,
} from 'lucide-react'

// Validation schemas
const headerSchema = z.object({
  requestDate: z.string().min(1, 'Request date is required'),
  allocationBasis: z.enum(['customer_specific', 'item_specific']),
  customerId: z.string().optional(),
  customerName: z.string().optional(),
  billToId: z.string().optional(),
  shipToId: z.string().optional(),
  territory: z.string().min(1, 'Territory is required'),
  remarks: z.string().optional(),
})

const lineSchema = z.object({
  warehouse: z.string().min(1, 'Warehouse is required'),
  itemCode: z.string().min(1, 'Item code is required'),
  requestedQuantity: z.number().min(1, 'Quantity must be at least 1'),
  targetDate: z.string().min(1, 'Target date is required'),
})

type HeaderFormData = z.infer<typeof headerSchema>
type LineFormData = z.infer<typeof lineSchema>

const NewAllocationPage: React.FC = () => {
  const navigate = useNavigate()
  const { user } = useAuth()
  const [step, setStep] = useState<1 | 2>(1)
  const [lines, setLines] = useState<(LineFormData & { id: string })[]>([])
  const createAllocation = useCreateAllocation()

  const {
    register: registerHeader,
    handleSubmit: handleHeaderSubmit,
    watch: watchHeader,
    formState: { errors: headerErrors },
  } = useForm<HeaderFormData>({
    resolver: zodResolver(headerSchema),
    defaultValues: {
      requestDate: new Date().toISOString().split('T')[0],
      allocationBasis: 'customer_specific',
      territory: '',
    },
  })

  const {
    register: registerLine,
    handleSubmit: handleLineSubmit,
    reset: resetLine,
    formState: { errors: lineErrors },
    setValue: setLineValue,
  } = useForm<LineFormData>({
    resolver: zodResolver(lineSchema),
    defaultValues: {
      warehouse: '',
      itemCode: '',
      requestedQuantity: 1,
      targetDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    },
  })

  const allocationBasis = watchHeader('allocationBasis')

  const addLine = handleLineSubmit((data) => {
    setLines([
      ...lines,
      {
        ...data,
        id: Date.now().toString(),
      },
    ])
    resetLine()
  })

  const removeLine = (id: string) => {
    setLines(lines.filter((line) => line.id !== id))
  }

  const duplicateLine = (id: string) => {
    const lineToDuplicate = lines.find((line) => line.id === id)
    if (lineToDuplicate) {
      const { id: _, ...lineData } = lineToDuplicate
      setLines([
        ...lines,
        {
          ...lineData,
          id: Date.now().toString(),
        },
      ])
    }
  }

  const handleCreateAllocation = handleHeaderSubmit(async (headerData) => {
    if (lines.length === 0) {
      alert('Please add at least one line item')
      return
    }

    try {
      const allocationHeader: AllocationHeader = {
        id: `ah_${Date.now()}`,
        requestId: `REQ-${Date.now()}`,
        createdDate: headerData.requestDate,
        allocationBasis: headerData.allocationBasis,
        customerId: headerData.customerId,
        customerName: headerData.customerName,
        billToId: headerData.billToId,
        shipToId: headerData.shipToId,
        territory: headerData.territory,
        remarks: headerData.remarks,
        status: 'pending',
        totalLines: lines.length,
        totalQuantity: lines.reduce((sum, line) => sum + line.requestedQuantity, 0),
        createdBy: user?.id || '',
        createdByName: user?.name || '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      const allocationLines: AllocationLine[] = lines.map((line, idx) => ({
        id: `al_${Date.now()}_${idx}`,
        allocationHeaderId: allocationHeader.id,
        lineNumber: idx + 1,
        warehouse: line.warehouse,
        itemCode: line.itemCode,
        requestedQuantity: line.requestedQuantity,
        targetDate: line.targetDate,
        status: 'pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }))

      await createAllocation.mutateAsync({
        header: allocationHeader,
        lines: allocationLines,
      })

      navigate('/allocations/list', { state: { success: true } })
    } catch (error) {
      console.error('Failed to create allocation:', error)
      alert('Failed to create allocation request')
    }
  })

  const totalQuantity = lines.reduce((sum, line) => sum + line.requestedQuantity, 0)

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Create Allocation Request</h1>
        <p className="text-foreground/60">Fill in the details to submit your allocation request</p>
      </div>

      {/* Step Indicator */}
      <div className="flex items-center gap-4 mb-8">
        <motion.div
          animate={{
            backgroundColor: step === 1 ? 'rgb(37, 99, 235)' : 'rgb(22, 163, 74)',
          }}
          className="flex items-center justify-center w-10 h-10 rounded-full text-white font-semibold"
        >
          {step === 1 ? '1' : <CheckCircle className="w-6 h-6" />}
        </motion.div>
        <div className="flex-1 h-1 bg-background rounded-full overflow-hidden">
          <motion.div
            animate={{ width: step === 2 ? '100%' : '0%' }}
            transition={{ duration: 0.3 }}
            className="h-full bg-primary"
          />
        </div>
        <motion.div
          animate={{
            backgroundColor: step === 2 ? 'rgb(37, 99, 235)' : 'rgb(203, 213, 225)',
          }}
          className="flex items-center justify-center w-10 h-10 rounded-full text-white font-semibold"
        >
          2
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Form */}
        <div className="lg:col-span-2 space-y-6">
          {step === 1 ? (
            // Step 1: Header
            <motion.form
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={(e) => {
                e.preventDefault()
                setStep(2)
              }}
              className="elevated-card p-8 space-y-6"
            >
              <div>
                <h2 className="text-xl font-semibold text-foreground mb-6">
                  Allocation Details
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Request Date */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      {portalConfig.forms.allocationHeader.requestDate.label}
                    </label>
                    <input
                      type="date"
                      {...registerHeader('requestDate')}
                      className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                    {headerErrors.requestDate && (
                      <p className="text-sm text-danger mt-1">{headerErrors.requestDate.message}</p>
                    )}
                  </div>

                  {/* Allocation Basis */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      {portalConfig.forms.allocationHeader.allocationBasis.label}
                    </label>
                    <select
                      {...registerHeader('allocationBasis')}
                      className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                    >
                      {portalConfig.forms.allocationHeader.allocationBasis.options.map(
                        (opt) => (
                          <option key={opt.value} value={opt.value}>
                            {opt.label}
                          </option>
                        ),
                      )}
                    </select>
                    {headerErrors.allocationBasis && (
                      <p className="text-sm text-danger mt-1">
                        {headerErrors.allocationBasis.message}
                      </p>
                    )}
                  </div>

                  {/* Customer Fields (if customer_specific) */}
                  {allocationBasis === 'customer_specific' && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">
                          {portalConfig.forms.allocationHeader.customer.label}
                        </label>
                        <input
                          type="text"
                          {...registerHeader('customerName')}
                          placeholder={portalConfig.forms.allocationHeader.customer.placeholder}
                          className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">
                          {portalConfig.forms.allocationHeader.billTo.label}
                        </label>
                        <input
                          type="text"
                          {...registerHeader('billToId')}
                          placeholder={portalConfig.forms.allocationHeader.billTo.placeholder}
                          className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">
                          {portalConfig.forms.allocationHeader.shipTo.label}
                        </label>
                        <input
                          type="text"
                          {...registerHeader('shipToId')}
                          placeholder={portalConfig.forms.allocationHeader.shipTo.placeholder}
                          className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                        />
                      </div>
                    </>
                  )}

                  {/* Territory */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      {portalConfig.forms.allocationHeader.territory.label}
                    </label>
                    <select
                      {...registerHeader('territory')}
                      className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                    >
                      <option value="">Select territory</option>
                      {portalConfig.territories.map((territory) => (
                        <option key={territory.id} value={territory.id}>
                          {territory.label}
                        </option>
                      ))}
                    </select>
                    {headerErrors.territory && (
                      <p className="text-sm text-danger mt-1">{headerErrors.territory.message}</p>
                    )}
                  </div>
                </div>

                {/* Remarks */}
                <div className="mt-6">
                  <label className="block text-sm font-medium text-foreground mb-2">
                    {portalConfig.forms.allocationHeader.remarks.label}
                  </label>
                  <textarea
                    {...registerHeader('remarks')}
                    placeholder={portalConfig.forms.allocationHeader.remarks.placeholder}
                    rows={4}
                    className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-primary text-white font-semibold rounded-lg hover:bg-primary-dark transition-colors"
              >
                Next: Add Line Items
                <ChevronRight className="w-5 h-5" />
              </button>
            </motion.form>
          ) : (
            // Step 2: Line Items
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* Add Line Item Form */}
              <form onSubmit={addLine} className="elevated-card p-8 space-y-6">
                <h2 className="text-xl font-semibold text-foreground">Add Line Item</h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      {portalConfig.forms.lineItem.warehouse.label}
                    </label>
                    <select
                      {...registerLine('warehouse')}
                      className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                    >
                      <option value="">Select warehouse</option>
                      {portalConfig.warehouses.map((warehouse) => (
                        <option key={warehouse.id} value={warehouse.id}>
                          {warehouse.label}
                        </option>
                      ))}
                    </select>
                    {lineErrors.warehouse && (
                      <p className="text-sm text-danger mt-1">{lineErrors.warehouse.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      {portalConfig.forms.lineItem.itemCode.label}
                    </label>
                    <input
                      type="text"
                      {...registerLine('itemCode')}
                      placeholder={portalConfig.forms.lineItem.itemCode.placeholder}
                      className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                    {lineErrors.itemCode && (
                      <p className="text-sm text-danger mt-1">{lineErrors.itemCode.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      {portalConfig.forms.lineItem.requestedQuantity.label}
                    </label>
                    <input
                      type="number"
                      {...registerLine('requestedQuantity', { valueAsNumber: true })}
                      placeholder={portalConfig.forms.lineItem.requestedQuantity.placeholder}
                      min="1"
                      className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                    {lineErrors.requestedQuantity && (
                      <p className="text-sm text-danger mt-1">
                        {lineErrors.requestedQuantity.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      {portalConfig.forms.lineItem.targetDate.label}
                    </label>
                    <input
                      type="date"
                      {...registerLine('targetDate')}
                      className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                    {lineErrors.targetDate && (
                      <p className="text-sm text-danger mt-1">{lineErrors.targetDate.message}</p>
                    )}
                  </div>
                </div>

                <button
                  type="submit"
                  className="flex items-center justify-center gap-2 px-4 py-2 bg-primary text-white font-semibold rounded-lg hover:bg-primary-dark transition-colors"
                >
                  <Plus className="w-5 h-5" />
                  Add Line Item
                </button>
              </form>

              {/* Lines List */}
              {lines.length > 0 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="elevated-card overflow-hidden"
                >
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border bg-background/50">
                          <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                            Warehouse
                          </th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                            Item Code
                          </th>
                          <th className="px-6 py-4 text-right text-sm font-semibold text-foreground/80">
                            Quantity
                          </th>
                          <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                            Target Date
                          </th>
                          <th className="px-6 py-4 text-center text-sm font-semibold text-foreground/80">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {lines.map((line) => (
                          <tr
                            key={line.id}
                            className="border-b border-border hover:bg-background/50 transition-colors last:border-0"
                          >
                            <td className="px-6 py-4 text-sm text-foreground/70">
                              {portalConfig.warehouses.find((w) => w.id === line.warehouse)?.label}
                            </td>
                            <td className="px-6 py-4 text-sm font-medium text-foreground">
                              {line.itemCode}
                            </td>
                            <td className="px-6 py-4 text-sm text-right text-foreground">
                              {line.requestedQuantity}
                            </td>
                            <td className="px-6 py-4 text-sm text-foreground/70">
                              {new Date(line.targetDate).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 text-center">
                              <div className="flex items-center justify-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => duplicateLine(line.id)}
                                  className="p-2 hover:bg-background rounded-lg transition-colors text-foreground/60 hover:text-foreground"
                                >
                                  <Copy className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => removeLine(line.id)}
                                  className="p-2 hover:bg-danger/10 rounded-lg transition-colors text-danger"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setStep(1)}
                  className="px-6 py-3 bg-background border border-border rounded-lg text-foreground font-semibold hover:bg-background/80 transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={() => handleCreateAllocation()}
                  disabled={lines.length === 0 || createAllocation.isPending}
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-success text-white font-semibold rounded-lg hover:bg-success/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  {createAllocation.isPending ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-5 h-5" />
                      Submit Allocation
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          )}
        </div>

        {/* Summary Sidebar */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="elevated-card p-6 h-fit sticky top-8"
        >
          <h3 className="text-lg font-semibold text-foreground mb-6">Summary</h3>

          <div className="space-y-4">
            {step === 2 && (
              <>
                <div>
                  <p className="text-sm text-foreground/60 mb-1">Total Lines</p>
                  <p className="text-2xl font-bold text-foreground">{lines.length}</p>
                </div>

                <div>
                  <p className="text-sm text-foreground/60 mb-1">Total Quantity</p>
                  <p className="text-2xl font-bold text-foreground">{totalQuantity}</p>
                </div>

                <div className="bg-info/10 border border-info/30 rounded-lg p-4">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-5 h-5 text-info flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-info">
                      All required fields must be filled before submission.
                    </p>
                  </div>
                </div>
              </>
            )}

            {step === 1 && (
              <div className="bg-primary/10 border border-primary/30 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-primary">
                    Complete the header details first, then add line items in the next step.
                  </p>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </motion.div>
  )
}

export default NewAllocationPage
