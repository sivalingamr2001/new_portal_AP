import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Plus, Filter, Search, Eye } from 'lucide-react'
import { useAllocationHeaders } from '../../hooks/useAllocationQueries'
import { RequestStatus } from '../../types'
import portalConfig from '../../config/portalConfig'
import { cn } from '../../lib/utils'

const AllocationListPage: React.FC = () => {
  const navigate = useNavigate()
  const { data: headers, isLoading } = useAllocationHeaders()
  const [statusFilter, setStatusFilter] = useState<RequestStatus | 'all'>('all')
  const [searchTerm, setSearchTerm] = useState('')

  const filteredHeaders = headers?.filter((header) => {
    const matchesStatus = statusFilter === 'all' || header.status === statusFilter
    const matchesSearch =
      header.requestId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      header.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      header.territory.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesStatus && matchesSearch
  })

  const getStatusBadge = (status: RequestStatus) => {
    const config = portalConfig.statuses.request[status]
    const colorMap = {
      amber: 'bg-warning/10 text-warning',
      green: 'bg-success/10 text-success',
      red: 'bg-danger/10 text-danger',
      blue: 'bg-info/10 text-info',
      emerald: 'bg-success/10 text-success',
      slate: 'bg-foreground/10 text-foreground/70',
    }

    return (
      <span className={cn('px-3 py-1 rounded-full text-sm font-medium', colorMap[config.color])}>
        {config.label}
      </span>
    )
  }

  const getTerritoryLabel = (territory: string) => {
    return portalConfig.territories.find((t) => t.id === territory)?.label || territory
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">My Allocations</h1>
        <p className="text-foreground/60">Manage and track your allocation requests</p>
      </div>

      {/* Action Bar */}
      <div className="flex items-center gap-4 mb-6 flex-wrap">
        <button
          onClick={() => navigate('/allocations/new')}
          className="flex items-center gap-2 px-4 py-3 bg-primary text-white font-semibold rounded-lg hover:bg-primary-dark transition-colors"
        >
          <Plus className="w-5 h-5" />
          New Allocation
        </button>

        {/* Search */}
        <div className="flex-1 min-w-[200px] relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-foreground/40" />
          <input
            type="text"
            placeholder="Search by ID, customer, territory..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>

        {/* Filter */}
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-foreground/60" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as RequestStatus | 'all')}
            className="px-4 py-3 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="partial_approved">Partial Approved</option>
            <option value="cancelled">Cancelled</option>
            <option value="fulfilled">Fulfilled</option>
          </select>
        </div>
      </div>

      {/* Table */}
      {isLoading ? (
        <div className="elevated-card p-8 text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-primary/10 rounded-full">
            <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
          <p className="text-foreground/60">Loading allocations...</p>
        </div>
      ) : filteredHeaders && filteredHeaders.length > 0 ? (
        <div className="elevated-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-background/50">
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                    Request ID
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                    Created
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                    Customer / Territory
                  </th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-foreground/80">
                    Lines
                  </th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-foreground/80">
                    Quantity
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                    Status
                  </th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-foreground/80">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredHeaders.map((header, idx) => (
                  <motion.tr
                    key={header.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: idx * 0.05 }}
                    className="border-b border-border hover:bg-background/50 transition-colors last:border-0"
                  >
                    <td className="px-6 py-4 text-sm font-medium text-primary">
                      {header.requestId}
                    </td>
                    <td className="px-6 py-4 text-sm text-foreground/70">
                      {new Date(header.createdDate).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <div>
                        {header.customerName && (
                          <p className="font-medium text-foreground">{header.customerName}</p>
                        )}
                        <p className="text-foreground/60">
                          {getTerritoryLabel(header.territory)}
                        </p>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-right text-foreground">
                      {header.totalLines}
                    </td>
                    <td className="px-6 py-4 text-sm text-right font-medium text-foreground">
                      {header.totalQuantity}
                    </td>
                    <td className="px-6 py-4">{getStatusBadge(header.status)}</td>
                    <td className="px-6 py-4 text-center">
                      <button
                        onClick={() => navigate(`/allocations/${header.id}`)}
                        className="inline-flex items-center justify-center p-2 hover:bg-background rounded-lg transition-colors text-foreground/60 hover:text-foreground"
                      >
                        <Eye className="w-5 h-5" />
                      </button>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="elevated-card p-12 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 mb-4 bg-foreground/5 rounded-lg">
            <Search className="w-8 h-8 text-foreground/30" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">No allocations found</h3>
          <p className="text-foreground/60 mb-6">
            {searchTerm || statusFilter !== 'all'
              ? 'Try adjusting your filters or search term'
              : 'Create your first allocation request to get started'}
          </p>
          <button
            onClick={() => navigate('/allocations/new')}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white font-semibold rounded-lg hover:bg-primary-dark transition-colors"
          >
            <Plus className="w-5 h-5" />
            Create Allocation
          </button>
        </div>
      )}
    </motion.div>
  )
}

export default AllocationListPage
