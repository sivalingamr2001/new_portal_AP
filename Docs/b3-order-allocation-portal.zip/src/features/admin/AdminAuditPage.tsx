import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { useActivityLogs } from '../../hooks/useAllocationQueries'
import { Search, Filter, Download } from 'lucide-react'
import { cn } from '../../lib/utils'

const AdminAuditPage: React.FC = () => {
  const { data: logs, isLoading } = useActivityLogs()
  const [searchTerm, setSearchTerm] = useState('')
  const [actionFilter, setActionFilter] = useState<'all' | 'created' | 'approved' | 'cancelled' | 'fulfilled'>('all')

  const filteredLogs = logs?.filter((log) => {
    const matchesSearch =
      log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.entityId.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesAction = actionFilter === 'all' || log.action === actionFilter
    return matchesSearch && matchesAction
  })

  const getActionColor = (action: string) => {
    const colors: Record<string, string> = {
      created: 'bg-info/10 text-info',
      approved: 'bg-success/10 text-success',
      cancelled: 'bg-danger/10 text-danger',
      fulfilled: 'bg-primary/10 text-primary',
    }
    return colors[action] || 'bg-foreground/10 text-foreground'
  }

  const downloadAuditLog = () => {
    const csvContent = [
      ['Timestamp', 'User', 'Action', 'Entity Type', 'Entity ID'],
      ...filteredLogs!.map((log) => [
        new Date(log.timestamp).toLocaleString(),
        log.userName,
        log.action,
        log.entityType,
        log.entityId,
      ]),
    ]
      .map((row) => row.join(','))
      .join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `audit-log-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  if (isLoading) {
    return (
      <div className="elevated-card p-8 text-center">
        <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-primary/10 rounded-full">
          <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
        <p className="text-foreground/60">Loading audit logs...</p>
      </div>
    )
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      {/* Header */}
      <div className="mb-8 flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Audit Logs</h1>
          <p className="text-foreground/60">System activity and user actions tracking</p>
        </div>
        <button
          onClick={downloadAuditLog}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-white font-semibold rounded-lg hover:bg-primary-dark transition-colors"
        >
          <Download className="w-5 h-5" />
          Download CSV
        </button>
      </div>

      {/* Search & Filter */}
      <div className="mb-6 flex items-center gap-4 flex-wrap">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-foreground/40" />
          <input
            type="text"
            placeholder="Search by user or entity ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-foreground/60" />
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value as any)}
            className="px-4 py-3 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option value="all">All Actions</option>
            <option value="created">Created</option>
            <option value="approved">Approved</option>
            <option value="cancelled">Cancelled</option>
            <option value="fulfilled">Fulfilled</option>
          </select>
        </div>
      </div>

      {/* Logs Table */}
      {filteredLogs && filteredLogs.length > 0 ? (
        <motion.div className="elevated-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-background/50">
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                    Timestamp
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                    User
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                    Action
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                    Entity
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-foreground/80">
                    Entity ID
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredLogs.map((log, idx) => (
                  <motion.tr
                    key={log.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: idx * 0.02 }}
                    className="border-b border-border hover:bg-background/50 transition-colors last:border-0"
                  >
                    <td className="px-6 py-4 text-sm text-foreground/70 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-foreground">
                      {log.userName}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span className={cn('px-3 py-1 rounded text-xs font-medium capitalize', getActionColor(log.action))}>
                        {log.action}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-foreground/70 capitalize">
                      {log.entityType.replace('_', ' ')}
                    </td>
                    <td className="px-6 py-4 text-sm text-primary font-mono">
                      {log.entityId}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      ) : (
        <div className="elevated-card p-12 text-center">
          <Search className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No audit logs found</h3>
          <p className="text-foreground/60">Try adjusting your filters or search criteria</p>
        </div>
      )}

      {/* Summary */}
      {filteredLogs && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-6 p-4 bg-background rounded-lg text-sm text-foreground/60"
        >
          Showing <span className="font-semibold text-foreground">{filteredLogs.length}</span> of{' '}
          <span className="font-semibold text-foreground">{logs?.length || 0}</span> records
        </motion.div>
      )}
    </motion.div>
  )
}

export default AdminAuditPage
