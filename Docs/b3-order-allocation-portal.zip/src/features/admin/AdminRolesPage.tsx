import React from 'react'
import { motion } from 'framer-motion'
import portalConfig from '../../config/portalConfig'
import { CheckCircle } from 'lucide-react'

const AdminRolesPage: React.FC = () => {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Roles & Permissions</h1>
        <p className="text-foreground/60">Define user roles and access control</p>
      </div>

      {/* Roles List */}
      <div className="space-y-6">
        {Object.entries(portalConfig.roles).map(([roleKey, roleData], idx) => (
          <motion.div
            key={roleKey}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="elevated-card p-8"
          >
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-foreground capitalize mb-2">
                {roleData.label}
              </h2>
              <p className="text-sm text-foreground/60">
                Role ID: <span className="font-mono">{roleKey}</span>
              </p>
            </div>

            <div>
              <p className="text-sm font-semibold text-foreground/80 mb-4">Permissions:</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {roleData.permissions.map((permission) => (
                  <div key={permission} className="flex items-center gap-3 p-3 bg-background rounded-lg">
                    <CheckCircle className="w-5 h-5 text-success flex-shrink-0" />
                    <span className="text-sm text-foreground capitalize">
                      {permission
                        .split('_')
                        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
                        .join(' ')}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* User Count (Mock) */}
            <div className="mt-6 pt-6 border-t border-border">
              <p className="text-sm text-foreground/60">
                Active Users: <span className="font-semibold text-foreground">1</span>
              </p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Role Matrix */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-12 elevated-card p-8"
      >
        <h2 className="text-xl font-bold text-foreground mb-6">Permission Matrix</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-semibold text-foreground/80">
                  Permission
                </th>
                {Object.values(portalConfig.roles).map((role) => (
                  <th key={role.label} className="text-center py-3 px-4 font-semibold text-foreground/80">
                    {role.label.split(' ')[0]}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                'view_dashboard',
                'create_allocation',
                'view_allocations',
                'approve_allocation',
                'cancel_allocation',
                'view_fulfillment',
                'manage_users',
                'manage_roles',
                'view_audit_logs',
                'manage_configuration',
              ].map((permission) => (
                <tr key={permission} className="border-b border-border/50 last:border-0">
                  <td className="py-3 px-4 text-foreground capitalize">
                    {permission
                      .split('_')
                      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
                      .join(' ')}
                  </td>
                  {Object.entries(portalConfig.roles).map(([_, roleData]) => (
                    <td key={roleData.label} className="text-center py-3 px-4">
                      {roleData.permissions.includes(permission) ? (
                        <CheckCircle className="w-5 h-5 text-success mx-auto" />
                      ) : (
                        <div className="w-5 h-5 border border-foreground/20 rounded-full mx-auto" />
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </motion.div>
  )
}

export default AdminRolesPage
