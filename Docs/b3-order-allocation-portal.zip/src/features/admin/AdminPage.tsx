import React from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Sliders, Users, Activity, Settings } from 'lucide-react'

const adminModules = [
  {
    id: 'config',
    title: 'Configuration',
    description: 'Manage API endpoints and system settings',
    icon: Sliders,
    path: '/admin/config',
  },
  {
    id: 'roles',
    title: 'Roles & Permissions',
    description: 'Manage user roles and access control',
    icon: Users,
    path: '/admin/roles',
  },
  {
    id: 'audit',
    title: 'Audit Logs',
    description: 'View system activity and user actions',
    icon: Activity,
    path: '/admin/audit',
  },
]

const AdminPage: React.FC = () => {
  const navigate = useNavigate()

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Administration</h1>
        <p className="text-foreground/60">System configuration and management tools</p>
      </div>

      {/* Modules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {adminModules.map((module, idx) => {
          const Icon = module.icon
          return (
            <motion.button
              key={module.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              onClick={() => navigate(module.path)}
              className="elevated-card p-8 hover:shadow-lg transition-all text-left"
            >
              <div className="mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <h2 className="text-xl font-semibold text-foreground">{module.title}</h2>
              </div>
              <p className="text-sm text-foreground/60">{module.description}</p>
            </motion.button>
          )
        })}
      </div>

      {/* Quick Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="mt-12 elevated-card p-8"
      >
        <h2 className="text-xl font-semibold text-foreground mb-6">System Status</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-foreground/60 mb-2">API Status</p>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-success rounded-full animate-pulse" />
              <p className="font-semibold text-success">Operational</p>
            </div>
          </div>
          <div>
            <p className="text-sm text-foreground/60 mb-2">Database</p>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-success rounded-full animate-pulse" />
              <p className="font-semibold text-success">Connected</p>
            </div>
          </div>
          <div>
            <p className="text-sm text-foreground/60 mb-2">Last Sync</p>
            <p className="font-semibold text-foreground">
              {new Date().toLocaleTimeString()}
            </p>
          </div>
          <div>
            <p className="text-sm text-foreground/60 mb-2">Version</p>
            <p className="font-semibold text-foreground">v1.0.0</p>
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}

export default AdminPage
