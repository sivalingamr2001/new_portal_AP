import React from 'react'
import { motion } from 'framer-motion'
import portalConfig from '../../config/portalConfig'
import { Copy, Check } from 'lucide-react'

const AdminConfigPage: React.FC = () => {
  const [copied, setCopied] = React.useState<string | null>(null)

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">System Configuration</h1>
        <p className="text-foreground/60">API endpoints, base URLs, and system settings</p>
      </div>

      {/* Application Info */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0 }}
        className="elevated-card p-8 mb-6"
      >
        <h2 className="text-xl font-semibold text-foreground mb-6">Application</h2>
        <div className="space-y-4">
          <div>
            <p className="text-sm text-foreground/60 mb-2">Name</p>
            <p className="text-lg font-semibold text-foreground">{portalConfig.app.name}</p>
          </div>
          <div>
            <p className="text-sm text-foreground/60 mb-2">Version</p>
            <p className="text-lg font-semibold text-foreground">{portalConfig.app.version}</p>
          </div>
          <div>
            <p className="text-sm text-foreground/60 mb-2">Description</p>
            <p className="text-lg text-foreground/80">{portalConfig.app.description}</p>
          </div>
        </div>
      </motion.div>

      {/* API Configuration */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="elevated-card p-8 mb-6"
      >
        <h2 className="text-xl font-semibold text-foreground mb-6">API Configuration</h2>

        <div className="mb-6">
          <p className="text-sm text-foreground/60 mb-3">Base URL</p>
          <div className="flex items-center gap-2">
            <code className="flex-1 px-4 py-3 bg-background rounded-lg text-sm font-mono text-foreground/80 break-all">
              {portalConfig.api.baseUrl}
            </code>
            <button
              onClick={() => copyToClipboard(portalConfig.api.baseUrl, 'baseUrl')}
              className="p-2 hover:bg-background rounded-lg transition-colors"
            >
              {copied === 'baseUrl' ? (
                <Check className="w-5 h-5 text-success" />
              ) : (
                <Copy className="w-5 h-5 text-foreground/60" />
              )}
            </button>
          </div>
        </div>

        <div>
          <p className="text-sm text-foreground/60 mb-4">Endpoints</p>
          <div className="space-y-3">
            {Object.entries(portalConfig.api.endpoints).map(([key, endpoint]) => (
              <div
                key={key}
                className="flex items-center justify-between p-3 bg-background rounded-lg"
              >
                <div>
                  <p className="text-sm font-medium text-foreground capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </p>
                  <code className="text-xs text-foreground/60 font-mono">
                    {portalConfig.api.baseUrl}
                    {endpoint}
                  </code>
                </div>
                <button
                  onClick={() =>
                    copyToClipboard(`${portalConfig.api.baseUrl}${endpoint}`, key)
                  }
                  className="p-2 hover:bg-border rounded-lg transition-colors flex-shrink-0"
                >
                  {copied === key ? (
                    <Check className="w-4 h-4 text-success" />
                  ) : (
                    <Copy className="w-4 h-4 text-foreground/60" />
                  )}
                </button>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Features Configuration */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="elevated-card p-8"
      >
        <h2 className="text-xl font-semibold text-foreground mb-6">Features & Limits</h2>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-background rounded-lg">
            <div>
              <p className="font-medium text-foreground">Export to Excel</p>
              <p className="text-sm text-foreground/60">Enable data export functionality</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-12 h-6 bg-success rounded-full" />
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-background rounded-lg">
            <div>
              <p className="font-medium text-foreground">Bulk Operations</p>
              <p className="text-sm text-foreground/60">Allow bulk approval/cancellation</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-12 h-6 bg-success rounded-full" />
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-background rounded-lg">
            <div>
              <p className="font-medium text-foreground">Audit Logging</p>
              <p className="text-sm text-foreground/60">Track all user actions</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-12 h-6 bg-success rounded-full" />
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-background rounded-lg">
            <div>
              <p className="font-medium text-foreground">Email Notifications</p>
              <p className="text-sm text-foreground/60">Send approval notifications</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-12 h-6 bg-foreground/20 rounded-full" />
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}

export default AdminConfigPage
