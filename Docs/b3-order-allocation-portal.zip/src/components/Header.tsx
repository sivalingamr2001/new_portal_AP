import React from 'react'
import { useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { Menu, Bell, User } from 'lucide-react'
import { cn } from '../lib/utils'

interface HeaderProps {
  onMenuClick?: () => void
}

const getBreadcrumbs = (pathname: string) => {
  const segments = pathname.split('/').filter(Boolean)
  return segments.map((segment, idx) => ({
    label: segment
      .split('-')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' '),
    path: '/' + segments.slice(0, idx + 1).join('/'),
  }))
}

const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  const location = useLocation()
  const { user } = useAuth()
  const breadcrumbs = getBreadcrumbs(location.pathname)

  return (
    <header className="sticky top-0 z-20 bg-card border-b border-border">
      <div className="px-4 md:px-8 py-4">
        <div className="flex items-center justify-between mb-4">
          {/* Left: Menu & Title */}
          <div className="flex items-center gap-4">
            <button
              onClick={onMenuClick}
              className="md:hidden p-2 hover:bg-background rounded-lg transition-colors"
            >
              <Menu className="w-6 h-6 text-foreground" />
            </button>

            <div>
              <h1 className="text-2xl font-bold text-foreground">
                {breadcrumbs[breadcrumbs.length - 1]?.label || 'Dashboard'}
              </h1>
              <p className="text-sm text-foreground/60">Welcome back, {user?.name}</p>
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-2 md:gap-4">
            {/* Notification */}
            <button className="relative p-2 md:p-3 hover:bg-background rounded-lg transition-colors">
              <Bell className="w-5 h-5 md:w-6 md:h-6 text-foreground/60 hover:text-foreground" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-danger rounded-full animate-pulse" />
            </button>

            {/* User Menu */}
            <button className="p-2 md:p-3 hover:bg-background rounded-lg transition-colors hidden md:flex items-center gap-2">
              <User className="w-5 h-5 text-foreground/60" />
              <span className="text-sm text-foreground/60 hidden lg:inline">{user?.name}</span>
            </button>
          </div>
        </div>

        {/* Breadcrumbs */}
        {breadcrumbs.length > 0 && (
          <div className="flex items-center gap-2 text-sm text-foreground/60">
            {breadcrumbs.map((breadcrumb, idx) => (
              <React.Fragment key={breadcrumb.path}>
                {idx > 0 && <span className="text-foreground/40">/</span>}
                <span className={cn(idx === breadcrumbs.length - 1 && 'text-primary font-medium')}>
                  {breadcrumb.label}
                </span>
              </React.Fragment>
            ))}
          </div>
        )}
      </div>
    </header>
  )
}

export default Header
