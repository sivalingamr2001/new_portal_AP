import React from 'react'
import { motion } from 'framer-motion'
import { LucideIcon } from 'lucide-react'
import { cn } from '../lib/utils'

interface KPICardProps {
  label: string
  value: number | string
  icon: LucideIcon
  color: 'primary' | 'success' | 'warning' | 'danger'
  trend?: number
  description?: string
  delay?: number
}

const colorClasses = {
  primary: 'bg-primary/10 text-primary',
  success: 'bg-success/10 text-success',
  warning: 'bg-warning/10 text-warning',
  danger: 'bg-danger/10 text-danger',
}

const KPICard: React.FC<KPICardProps> = ({
  label,
  value,
  icon: Icon,
  color,
  trend,
  description,
  delay = 0,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
      className="elevated-card p-6 hover:shadow-lg transition-shadow"
    >
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="text-sm text-foreground/60 font-medium mb-1">{label}</p>
          <p className="text-3xl font-bold text-foreground">{value}</p>
        </div>
        <div className={cn('p-3 rounded-lg', colorClasses[color])}>
          <Icon className="w-6 h-6" />
        </div>
      </div>

      {(trend !== undefined || description) && (
        <div className="flex items-center justify-between text-sm">
          {trend !== undefined && (
            <span className={cn('font-medium', trend >= 0 ? 'text-success' : 'text-danger')}>
              {trend >= 0 ? '+' : ''}{trend}% vs last month
            </span>
          )}
          {description && !trend && <p className="text-foreground/60">{description}</p>}
        </div>
      )}
    </motion.div>
  )
}

export default KPICard
