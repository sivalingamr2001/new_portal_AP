import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useTheme } from '../context/ThemeContext'
import portalConfig from '../config/portalConfig'
import {
  LayoutGrid,
  Package,
  CheckCircle,
  TrendingUp,
  Settings,
  Plus,
  List,
  Sliders,
  Users,
  Activity,
  ChevronDown,
  X,
  Sun,
  Moon,
} from 'lucide-react'
import { cn } from '../lib/utils'

const iconMap: Record<string, React.FC<{ className?: string }>> = {
  LayoutGrid,
  Package,
  CheckCircle,
  TrendingUp,
  Settings,
  Plus,
  List,
  Sliders,
  Users,
  Activity,
}

interface SidebarProps {
  onClose?: () => void
}

const Sidebar: React.FC<SidebarProps> = ({ onClose }) => {
  const { user, logout } = useAuth()
  const { theme, toggleTheme } = useTheme()
  const location = useLocation()
  const [expandedMenu, setExpandedMenu] = useState<string | null>(null)

  const filteredNavigation = portalConfig.navigation.primary.filter((item) =>
    item.roles.includes(user?.role || 'sales_rep'),
  )

  const isActive = (path: string) => location.pathname.startsWith(path)

  const toggleSubmenu = (id: string) => {
    setExpandedMenu(expandedMenu === id ? null : id)
  }

  return (
    <div className="flex flex-col h-full bg-card border-r border-border shadow-lg">
      {/* Logo Section */}
      <div className="flex items-center justify-between p-6 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
            <Package className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">B3</h1>
            <p className="text-xs text-foreground/60">Allocation Portal</p>
          </div>
        </div>
        <button onClick={onClose} className="md:hidden">
          <X className="w-5 h-5 text-foreground/60" />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-4 py-6">
        <div className="space-y-2">
          {filteredNavigation.map((item) => {
            const Icon = iconMap[item.icon]
            const hasChildren = item.children && item.children.length > 0
            const isItemActive = isActive(item.path) || item.children?.some((child) => isActive(child.path))

            return (
              <div key={item.id}>
                {hasChildren ? (
                  <>
                    <button
                      onClick={() => toggleSubmenu(item.id)}
                      className={cn(
                        'w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors',
                        isItemActive
                          ? 'bg-primary/10 text-primary'
                          : 'text-foreground/70 hover:text-foreground hover:bg-background/50',
                      )}
                    >
                      {Icon && <Icon className="w-5 h-5 flex-shrink-0" />}
                      <span className="flex-1 text-left text-sm font-medium">{item.label}</span>
                      <ChevronDown
                        className={cn(
                          'w-4 h-4 transition-transform',
                          expandedMenu === item.id && 'rotate-180',
                        )}
                      />
                    </button>

                    {expandedMenu === item.id && (
                      <div className="ml-6 mt-2 space-y-1">
                        {item.children.map((child) => (
                          <Link
                            key={child.id}
                            to={child.path}
                            onClick={onClose}
                            className={cn(
                              'block px-4 py-2 rounded-lg text-sm transition-colors',
                              isActive(child.path)
                                ? 'bg-primary/10 text-primary font-medium'
                                : 'text-foreground/60 hover:text-foreground hover:bg-background/50',
                            )}
                          >
                            {child.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <Link
                    to={item.path}
                    onClick={onClose}
                    className={cn(
                      'flex items-center gap-3 px-4 py-3 rounded-lg transition-colors',
                      isItemActive
                        ? 'bg-primary/10 text-primary'
                        : 'text-foreground/70 hover:text-foreground hover:bg-background/50',
                    )}
                  >
                    {Icon && <Icon className="w-5 h-5 flex-shrink-0" />}
                    <span className="text-sm font-medium">{item.label}</span>
                  </Link>
                )}
              </div>
            )
          })}
        </div>
      </nav>

      {/* User Section */}
      <div className="border-t border-border p-4 space-y-3">
        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-background/50 hover:bg-background transition-colors"
        >
          {theme === 'light' ? (
            <>
              <Moon className="w-4 h-4" />
              <span className="text-sm">Dark</span>
            </>
          ) : (
            <>
              <Sun className="w-4 h-4" />
              <span className="text-sm">Light</span>
            </>
          )}
        </button>

        {/* User Info */}
        <div className="px-4 py-3 bg-background rounded-lg">
          <p className="text-xs text-foreground/60">Logged in as</p>
          <p className="text-sm font-semibold text-foreground truncate">{user?.name}</p>
          <p className="text-xs text-foreground/60 capitalize">{user?.role.replace('_', ' ')}</p>
        </div>

        {/* Logout */}
        <button
          onClick={logout}
          className="w-full px-4 py-2 text-sm font-medium rounded-lg bg-danger/10 text-danger hover:bg-danger/20 transition-colors"
        >
          Logout
        </button>
      </div>
    </div>
  )
}

export default Sidebar
