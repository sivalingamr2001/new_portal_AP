import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import portalConfig from '../config/portalConfig'
import {
  LayoutGrid,
  Package,
  CheckCircle,
  TrendingUp,
  Settings,
} from 'lucide-react'
import { cn } from '../lib/utils'

const primaryIconMap: Record<string, React.FC<{ className?: string }>> = {
  LayoutGrid,
  Package,
  CheckCircle,
  TrendingUp,
  Settings,
}

const MobileBottomNav: React.FC = () => {
  const { user } = useAuth()
  const location = useLocation()

  // Get primary navigation items visible to user
  const filteredNavigation = portalConfig.navigation.primary.filter((item) =>
    item.roles.includes(user?.role || 'sales_rep'),
  )

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-20 md:hidden bg-card border-t border-border">
      <div className="flex items-center justify-around h-20">
        {filteredNavigation.map((item) => {
          const Icon = primaryIconMap[item.icon]
          const isActive = location.pathname.startsWith(item.path)

          return (
            <Link
              key={item.id}
              to={item.path}
              className={cn(
                'flex flex-col items-center justify-center gap-1 w-full h-full transition-colors',
                isActive ? 'text-primary' : 'text-foreground/60 hover:text-foreground',
              )}
            >
              {Icon && <Icon className="w-6 h-6" />}
              <span className="text-xs font-medium text-center px-1 line-clamp-1">{item.label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}

export default MobileBottomNav
