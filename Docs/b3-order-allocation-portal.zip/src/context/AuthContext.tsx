import React, { createContext, useContext, useState, useCallback, useEffect } from 'react'
import { User, UserRole } from '../types'

interface AuthContextType {
  user: User | null
  isLoading: boolean
  error: string | null
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  setUser: (user: User | null) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Mock users for demo
const MOCK_USERS = {
  'sales@b3.com': {
    id: '1',
    name: 'John Smith',
    email: 'sales@b3.com',
    role: 'sales_rep' as UserRole,
    department: 'Sales',
    active: true,
    createdAt: '2024-01-01',
    updatedAt: '2024-06-11',
  },
  'hod@b3.com': {
    id: '2',
    name: 'Sarah Johnson',
    email: 'hod@b3.com',
    role: 'hod' as UserRole,
    department: 'Operations',
    active: true,
    createdAt: '2024-01-01',
    updatedAt: '2024-06-11',
  },
  'admin@b3.com': {
    id: '3',
    name: 'Mike Admin',
    email: 'admin@b3.com',
    role: 'system_admin' as UserRole,
    department: 'IT',
    active: true,
    createdAt: '2024-01-01',
    updatedAt: '2024-06-11',
  },
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUserState] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Load user from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('b3_user')
    if (storedUser) {
      try {
        setUserState(JSON.parse(storedUser))
      } catch (e) {
        console.error('Failed to load stored user:', e)
      }
    }
    setIsLoading(false)
  }, [])

  const login = useCallback(
    async (email: string, password: string) => {
      setIsLoading(true)
      setError(null)
      try {
        // Mock authentication
        const mockUser = MOCK_USERS[email as keyof typeof MOCK_USERS]
        if (!mockUser) {
          throw new Error('User not found')
        }

        // Store in localStorage
        localStorage.setItem('b3_user', JSON.stringify(mockUser))
        setUserState(mockUser)
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Login failed'
        setError(errorMessage)
        throw err
      } finally {
        setIsLoading(false)
      }
    },
    [],
  )

  const logout = useCallback(() => {
    localStorage.removeItem('b3_user')
    setUserState(null)
    setError(null)
  }, [])

  const setUser = useCallback((newUser: User | null) => {
    if (newUser) {
      localStorage.setItem('b3_user', JSON.stringify(newUser))
    } else {
      localStorage.removeItem('b3_user')
    }
    setUserState(newUser)
  }, [])

  return (
    <AuthContext.Provider value={{ user, isLoading, error, login, logout, setUser }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}
