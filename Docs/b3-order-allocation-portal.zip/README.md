# B3 Order Allocation Portal

A production-grade enterprise web application for managing B3 allocation requests with role-based access, approval workflows, and fulfillment tracking.

## Overview

The B3 Order Allocation Portal is a sophisticated SaaS application designed for enterprise supply chain management. It enables Sales Representatives to create allocation requests, Head of Department (HOD) users to review and approve allocations, and administrators to manage system configuration.

## Tech Stack

- **Frontend Framework**: React 19 with Vite
- **Language**: TypeScript
- **Styling**: Tailwind CSS v4 + custom design system
- **Component Library**: shadcn/ui
- **Routing**: React Router DOM
- **State Management**: TanStack Query + React Context
- **Forms**: React Hook Form + Zod validation
- **Data Visualization**: Recharts
- **Animation**: Framer Motion
- **Icons**: Lucide React

## Key Features

### 1. **Role-Based Access Control**
- **Sales Rep**: Create allocation requests, view fulfillment tracking
- **Head of Department (HOD)**: Review and approve/cancel allocation requests
- **System Admin**: Manage configuration, users, and audit logs
- Dynamic sidebar navigation based on user role

### 2. **Dashboard**
- **KPI Cards**: Real-time metrics for pending, approved, cancelled, and fulfilled requests
- **Monthly Allocation Trends**: Line chart showing allocation volume over time
- **Territory Performance Heat Map**: Visual representation of allocation distribution by region
- **Recent Activity Feed**: Timeline of actions (created, approved, cancelled, fulfilled)
- Animated transitions and hover effects

### 3. **Allocation Management**
- **Two-Step Wizard** for creating new requests:
  - Step 1: Allocation header details (request date, allocation basis, customer/bill-to info)
  - Step 2: Line items (warehouse, item code, quantities, target date)
- **Conditional Fields**: Different form fields based on allocation basis (Customer-Specific vs Item-Specific)
- **Inline Validation**: Zod-powered real-time field validation
- **Editable Data Tables**: Add/duplicate/delete line items
- **Allocation Summary**: Real-time calculation of totals

### 4. **Approval Queue (HOD Only)**
- **Expandable Allocation Records**: View all pending requests grouped by allocation header
- **Line-Level Actions**: Approve with quantity or cancel with reason
- **Status Badges**: Color-coded status indicators (Pending=Amber, Approved=Green, Cancelled=Red)
- **Filter Controls**: Filter by status, territory, date range, request ID
- **Batch Operations**: Approve or reject multiple requests at once

### 5. **Fulfillment Tracking**
- **Variance Analysis**: Compare approved quantities vs ERP sales order quantities
- **Variance Badges**: Show exact match, under-fulfilled, or over-fulfilled status
- **Advanced Filters**: Customer, item, territory, date range
- **Row Detail Drawer**: Allocation history, approval history, cancellation details, ERP sync info
- **Search Functionality**: Quick search by allocation ID, item code, or SO number

### 6. **System Administration**
- **API Configuration**: Manage integration endpoints for header, lines, cancellations, fulfillment
- **Role Management**: Configure user permissions and navigation access
- **Audit Logs**: Track all system actions with user, action type, and timestamp
- **Settings Dashboard**: Centralized configuration management

### 7. **Design & UX**
- **Dark/Light Mode**: Full theme support with smooth transitions
- **Responsive Layout**: 
  - Desktop: Sidebar + top header + breadcrumbs + content area
  - Mobile: Bottom navigation with collapsible sidebar drawer
- **Glassmorphism & Elevated Cards**: Modern enterprise design aesthetic
- **Animated Transitions**: Framer Motion for smooth page transitions and component animations
- **Empty States**: Beautiful placeholder designs for empty data states
- **Skeleton Loaders**: Loading placeholders for better perceived performance
- **Accessibility**: ARIA labels, semantic HTML, keyboard navigation

## Project Structure

```
src/
├── app/                          # App initialization
├── components/                   # Reusable UI components
│   ├── Sidebar.tsx              # Collapsible navigation
│   ├── Header.tsx               # Top header with user menu
│   ├── MobileBottomNav.tsx      # Mobile-only bottom navigation
│   ├── KPICard.tsx              # Animated KPI card component
│   └── ProtectedRoute.tsx        # Role-based route protection
├── context/                      # React Context providers
│   ├── AuthContext.tsx          # User authentication & roles
│   └── ThemeContext.tsx         # Dark/Light mode management
├── features/                     # Feature-specific pages
│   ├── auth/
│   │   └── LoginPage.tsx        # Login with demo accounts
│   ├── dashboard/
│   │   └── DashboardPage.tsx    # Overview dashboard
│   ├── allocations/
│   │   ├── AllocationListPage.tsx      # View all allocations
│   │   └── NewAllocationPage.tsx       # Create allocation wizard
│   ├── approvals/
│   │   └── ApprovalQueuePage.tsx       # HOD approval queue
│   ├── fulfillment/
│   │   └── FulfillmentTrackingPage.tsx # Variance tracking
│   └── admin/
│       ├── AdminPage.tsx               # Admin home
│       ├── AdminConfigPage.tsx         # API configuration
│       ├── AdminRolesPage.tsx          # Role management
│       └── AdminAuditPage.tsx          # Audit logs
├── hooks/
│   └── useAllocationQueries.ts   # TanStack Query hooks
├── layouts/
│   └── MainLayout.tsx            # Main app layout wrapper
├── services/
│   └── mockData.ts               # Mock data for development
├── config/
│   └── portalConfig.ts           # Centralized configuration
├── types/
│   └── index.ts                  # TypeScript interfaces
├── App.tsx                       # Root component & router
├── main.tsx                      # Vite entry point
└── index.css                     # Tailwind CSS with custom theme

```

## Authentication & Mock Data

The application comes with mock authentication using demo accounts:

### Demo Accounts
- **Sales Rep**: sales@b3.com (password: any)
- **Head of Department**: hod@b3.com (password: any)
- **System Admin**: admin@b3.com (password: any)

All data is mocked using TanStack Query with simulated API delays for realistic UX.

## Design System

### Colors
- **Primary**: #2563eb (Blue)
- **Success**: #16a34a (Green)
- **Warning**: #ea8c55 (Orange)
- **Danger**: #dc2626 (Red)
- **Background**: #ffffff (Light) / #0f172a (Dark)
- **Foreground**: #0f172a (Light) / #f1f5f9 (Dark)

### Typography
- **Headings**: Geist (system default)
- **Body**: Geist (system default)
- **Line Height**: 1.5-1.6 for body text

### Components
- **elevated-card**: Bordered cards with subtle shadows
- **glass**: Glassmorphic overlay components
- **sr-only**: Screen reader only text

## Getting Started

### Installation

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev

# Build for production
pnpm build

# Preview production build
pnpm preview
```

The application will be available at `http://localhost:5173`

### Usage

1. **Login**: Click on any demo account or manually enter credentials
2. **Navigate**: Use sidebar (desktop) or bottom nav (mobile) to explore features
3. **Create Request** (Sales Rep): Go to "New Allocation Request" to create a request
4. **Approve** (HOD): Visit "Approvals" to review pending requests
5. **Track** (All): Check "Fulfillment Tracking" to monitor order status
6. **Configure** (Admin): Visit "Admin" for system settings

## Configuration

The application uses `src/config/portalConfig.ts` as the single source of truth for:
- Navigation menu structure and visibility by role
- Form labels and field configurations
- API endpoint definitions
- Status badge colors and labels
- Table column definitions
- Validation rules

Update this file to customize the entire portal without touching component files.

## State Management

### TanStack Query
- Handles server state, caching, and synchronization
- Provides query hooks for data fetching
- Implements mutation hooks for creating/updating data

### React Context
- **AuthContext**: User authentication and role management
- **ThemeContext**: Dark/Light mode preference
- Persisted to localStorage for session continuity

## Responsive Design

- **Desktop** (1024px+): Full sidebar + header layout
- **Tablet** (768px-1023px): Collapsible sidebar with full-width toggle
- **Mobile** (<768px): Bottom navigation bar with drawer sidebar
- All tables and grids adapt to viewport size
- Touch-friendly buttons and spacing on mobile

## Accessibility Features

- Semantic HTML5 elements
- ARIA labels for interactive components
- Keyboard navigation support (Tab, Enter, Escape)
- Color contrast ratios meeting WCAG AA standards
- Screen reader optimized
- Proper heading hierarchy
- Form validation with error messages

## Performance Optimizations

- Code splitting by feature with React Router
- Lazy loading of feature pages
- Memoized components to prevent unnecessary re-renders
- TanStack Query caching to reduce API calls
- Skeleton loaders for perceived performance
- Optimized images and icons
- CSS-in-JS with Tailwind for minimal bundle size

## Future Enhancements

- [ ] Real backend API integration
- [ ] Advanced search and filtering
- [ ] Bulk import from Excel
- [ ] Email notifications
- [ ] Export to PDF/CSV
- [ ] Real-time collaboration features
- [ ] Mobile app (React Native)
- [ ] Analytics dashboard
- [ ] User preferences and settings
- [ ] Advanced reporting and insights

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome Mobile)

## License

Proprietary - B3 Order Allocation Portal

## Support

For issues or questions, contact the development team or open an issue in the project repository.

---

**Version**: 1.0.0  
**Last Updated**: June 11, 2026  
**Status**: Production Ready
