import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true,
    // Add the allowed hosts array here
    allowedHosts: ['sb-1a7aduhm2ytk.vercel.run']
  },
  build: {
    outDir: 'dist',
    sourcemap: true,
  },
})