import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { PIPELINE_DATA } from '@/lib/mock/data';

export function CertificationPipelineChart() {
  return (
    <div className="card p-5">
      <h3 className="text-sm font-semibold text-slate-800 mb-4">Certification Pipeline</h3>
      <ResponsiveContainer width="100%" height={280}>
        <BarChart data={PIPELINE_DATA}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis dataKey="month" tick={{ fontSize: 12 }} />
          <YAxis tick={{ fontSize: 12 }} />
          <Tooltip />
          <Legend />
          <Bar dataKey="certified" name="Certified" fill="#2563eb" radius={[4, 4, 0, 0]} />
          <Bar dataKey="rejected" name="Rejected" fill="#ef4444" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

