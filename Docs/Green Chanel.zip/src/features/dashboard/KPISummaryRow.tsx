import { StatCard } from '@/components/ui/StatCard';
import { DASHBOARD_KPIS } from '@/lib/mock/data';

export function KPISummaryRow() {
  const { totalCertified, approvedToday, pendingApprovals, rejectionRate } = DASHBOARD_KPIS;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
      <StatCard
        label="Total Certified"
        value={totalCertified.toLocaleString()}
        color="text-blue-600"
        bgColor="bg-blue-50"
        to="/reports"
        trend={5.2}
      />
      <StatCard
        label="Approved Today"
        value={approvedToday}
        color="text-emerald-600"
        bgColor="bg-emerald-50"
        to="/reports?status=approved"
        trend={12}
      />
      <StatCard
        label="Pending Approvals"
        value={pendingApprovals}
        color="text-orange-600"
        bgColor="bg-orange-50"
        to="/approvals"
        pulse={pendingApprovals > 0}
      />
      <StatCard
        label="Rejection Rate"
        value={rejectionRate}
        suffix="%"
        color={rejectionRate > 10 ? 'text-red-600' : 'text-slate-600'}
        bgColor="bg-red-50"
        to="/reports?status=rejected"
        trend={-2.1}
      />
    </div>
  );
}
