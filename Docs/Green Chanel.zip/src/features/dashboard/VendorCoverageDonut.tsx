import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { VENDOR_COVERAGE } from '@/lib/mock/data';

export function VendorCoverageDonut() {
  return (
    <div className="card p-5">
      <h3 className="text-sm font-semibold text-slate-800 mb-4">Vendor Coverage</h3>
      <ResponsiveContainer width="100%" height={280}>
        <PieChart>
          <Pie
            data={VENDOR_COVERAGE}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={90}
            paddingAngle={3}
            dataKey="value"
          >
            {VENDOR_COVERAGE.map((entry) => (
              <Cell key={entry.name} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip formatter={(v) => `${v}%`} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
