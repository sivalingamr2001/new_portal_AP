import { useQuery } from '@tanstack/react-query';
import { MOCK_AUDIT_EVENTS } from '@/lib/mock/data';

export interface AuditTrailFilters {
  eventType: string;
  actor: string;
  dateFrom: string;
  dateTo: string;
  requestId: string;
}

export function useAuditTrail(filters: AuditTrailFilters) {
  return useQuery({
    queryKey: ['audit-trail', filters],
    queryFn: async () => {
      await new Promise((r) => setTimeout(r, 200));
      return MOCK_AUDIT_EVENTS.filter((e) => {
        if (filters.eventType && filters.eventType !== 'all' && e.eventType !== filters.eventType)
          return false;
        if (filters.actor && !e.actor.toLowerCase().includes(filters.actor.toLowerCase()))
          return false;
        if (filters.requestId && !e.targetRequestId.includes(filters.requestId)) return false;
        return true;
      });
    },
  });
}
