import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  fetchApprovals,
  fetchPendingCount,
  approveRequest,
  rejectRequest,
  bulkApprove,
  bulkReject,
  type ApprovalFilters,
} from '@/lib/api/approvals';
import type { RejectionReason } from '@/lib/types/approval.types';

export function useApprovals(filters: ApprovalFilters) {
  return useQuery({
    queryKey: ['approvals', filters],
    queryFn: () => fetchApprovals(filters),
  });
}

export function useApprovalCount() {
  return useQuery({
    queryKey: ['approvals-count'],
    queryFn: fetchPendingCount,
    refetchInterval: 60_000,
  });
}

export function useApproveMutation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ requestId, remarks }: { requestId: string; remarks: string }) =>
      approveRequest(requestId, remarks),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['approvals'] });
      qc.invalidateQueries({ queryKey: ['approvals-count'] });
    },
  });
}

export function useRejectMutation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({
      requestId,
      reason,
      remarks,
    }: {
      requestId: string;
      reason: RejectionReason;
      remarks: string;
    }) => rejectRequest(requestId, reason, remarks),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['approvals'] });
      qc.invalidateQueries({ queryKey: ['approvals-count'] });
    },
  });
}

export function useBulkApproveMutation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ ids, remarks }: { ids: string[]; remarks: string }) =>
      bulkApprove(ids, remarks),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['approvals'] });
      qc.invalidateQueries({ queryKey: ['approvals-count'] });
    },
  });
}

export function useBulkRejectMutation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({
      ids,
      reason,
      remarks,
    }: {
      ids: string[];
      reason: RejectionReason;
      remarks: string;
    }) => bulkReject(ids, reason, remarks),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['approvals'] });
      qc.invalidateQueries({ queryKey: ['approvals-count'] });
    },
  });
}
