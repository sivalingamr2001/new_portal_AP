import type { ApprovalFilters as Filters } from '@/lib/api/approvals';

const CATEGORIES = ['', 'Bearings', 'Fasteners', 'Sealing', 'Shafts', 'Springs', 'Pneumatics', 'Other'];
const STATUSES = [
  { value: 'pending', label: 'Pending' },
  { value: 'approved', label: 'Approved' },
  { value: 'rejected', label: 'Rejected' },
  { value: 'all', label: 'All' },
];

export function ApprovalFilters({
  filters,
  onChange,
}: {
  filters: Filters;
  onChange: (f: Filters) => void;
}) {
  return (
    <div className="card p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
      <div>
        <label className="text-xs font-medium text-slate-500 mb-1 block">Vendor</label>
        <input
          value={filters.vendor}
          onChange={(e) => onChange({ ...filters, vendor: e.target.value })}
          placeholder="Search vendor..."
          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
        />
      </div>
      <div>
        <label className="text-xs font-medium text-slate-500 mb-1 block">Category</label>
        <select
          value={filters.category}
          onChange={(e) => onChange({ ...filters, category: e.target.value })}
          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
        >
          <option value="">All categories</option>
          {CATEGORIES.filter(Boolean).map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="text-xs font-medium text-slate-500 mb-1 block">Status</label>
        <select
          value={filters.status}
          onChange={(e) => onChange({ ...filters, status: e.target.value })}
          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
        >
          {STATUSES.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="text-xs font-medium text-slate-500 mb-1 block">Date From</label>
        <input
          type="date"
          value={filters.dateFrom}
          onChange={(e) => onChange({ ...filters, dateFrom: e.target.value })}
          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
        />
      </div>
    </div>
  );
}

