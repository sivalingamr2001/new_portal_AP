import { useQuery } from '@tanstack/react-query';
import { fetchAuditLog } from '@/lib/api/reports';
import type { ReportFilters } from '@/lib/types/report.types';

export function useReports(filters: ReportFilters) {
  return useQuery({
    queryKey: ['reports', filters],
    queryFn: () => fetchAuditLog(filters),
  });
}
