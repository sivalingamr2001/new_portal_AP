import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { itemEntrySchema } from '@/lib/schemas/certification.schema';
import type { z } from 'zod';
import { ItemCodeCombobox } from '@/components/shared/ItemCodeCombobox';
import { CharCountTextarea } from '@/components/ui/CharCountTextarea';
import { DatePickerField } from '@/components/shared/DatePickerField';
import { Plus } from 'lucide-react';
import type { CertificationItem } from '@/lib/types/certification.types';
import type { VendorItem } from '@/lib/types/vendor.types';

type FormData = z.input<typeof itemEntrySchema>;

interface ItemEntryFormProps {
  vendorId: string;
  existingItems: CertificationItem[];
  onAdd: (item: CertificationItem) => void;
}

export function ItemEntryForm({ vendorId, existingItems, onAdd }: ItemEntryFormProps) {
  const {
    control,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors, isValid },
  } = useForm<FormData>({
    resolver: zodResolver(itemEntrySchema),
    mode: 'onChange',
    defaultValues: {
      itemCode: '',
      itemName: '',
      category: '',
      certificationDate: '',
      remarks: '',
    },
  });

  const itemCode = watch('itemCode');

  const handleItemSelect = (item: VendorItem) => {
    setValue('itemCode', item.code, { shouldValidate: true });
    setValue('itemName', item.name, { shouldValidate: true });
    setValue('category', item.category, { shouldValidate: true });
  };

  const onSubmit = handleSubmit((data) => {
    const parsed = itemEntrySchema.parse(data);
    onAdd({
      itemCode: parsed.itemCode,
      itemName: parsed.itemName,
      category: parsed.category as CertificationItem['category'],
      certificationDate: parsed.certificationDate,
      certificationExpiry: parsed.certificationExpiry,
      remarks: parsed.remarks,
    });
    reset();
  });

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ItemCodeCombobox
          vendorId={vendorId}
          value={itemCode}
          onSelect={handleItemSelect}
          existingCodes={existingItems.map((i) => i.itemCode)}
        />
        <div>
          <label className="text-sm font-medium text-slate-700 mb-1.5 block">Item Name</label>
          <Controller
            name="itemName"
            control={control}
            render={({ field }) => (
              <input
                {...field}
                readOnly
                className="w-full px-3 py-2.5 border border-slate-200 rounded-lg text-sm bg-slate-50 text-slate-600"
              />
            )}
          />
          {errors.itemName && (
            <p className="text-xs text-red-600 mt-1">{errors.itemName.message}</p>
          )}
        </div>
        <Controller
          name="certificationDate"
          control={control}
          render={({ field }) => (
            <DatePickerField
              label="Certification Date"
              value={field.value}
              onChange={field.onChange}
              error={errors.certificationDate?.message}
            />
          )}
        />
      </div>
      <Controller
        name="remarks"
        control={control}
        render={({ field }) => (
          <CharCountTextarea
            label="Remarks"
            value={field.value}
            onChange={field.onChange}
            minLength={20}
            maxLength={500}
            placeholder="Describe certification basis, test standards, and quality evidence..."
            error={errors.remarks?.message}
          />
        )}
      />
      <button
        type="submit"
        disabled={!isValid}
        className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <Plus size={16} />
        Add Item
      </button>
    </form>
  );
}

