import type { CertificationItem } from '@/lib/types/certification.types';
import { formatDate } from '@/lib/utils/date';
import { CategoryBadge } from '@/components/ui/CategoryBadge';
import { Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils/cn';
import { EmptyState } from '@/components/ui/EmptyState';

interface SelectedItemsTableProps {
  items: CertificationItem[];
  onRemove: (itemCode: string) => void;
  className?: string;
}

export function SelectedItemsTable({ items, onRemove, className }: SelectedItemsTableProps) {
  if (items.length === 0) {
    return (
      <EmptyState
        title="No items added"
        description="Add items using the form above or bulk upload."
        className={className}
      />
    );
  }

  return (
    <div className={cn('card overflow-hidden', className)}>
      <div className="px-5 py-4 border-b border-slate-100">
        <h3 className="text-sm font-semibold text-slate-800">
          Selected Items ({items.length})
        </h3>
      </div>
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-xs text-slate-500 uppercase">
            <tr>
              <th className="px-4 py-3 text-left">Item Code</th>
              <th className="px-4 py-3 text-left">Item Name</th>
              <th className="px-4 py-3 text-left">Category</th>
              <th className="px-4 py-3 text-left">Cert. Date</th>
              <th className="px-4 py-3 text-left">Expiry</th>
              <th className="px-4 py-3 text-left">Remarks</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.itemCode} className="border-t border-slate-100">
                <td className="px-4 py-3 font-mono text-xs font-medium">{item.itemCode}</td>
                <td className="px-4 py-3">{item.itemName}</td>
                <td className="px-4 py-3">
                  <CategoryBadge category={item.category} />
                </td>
                <td className="px-4 py-3">{formatDate(item.certificationDate)}</td>
                <td className="px-4 py-3">{formatDate(item.certificationExpiry)}</td>
                <td className="px-4 py-3 text-xs text-slate-600 max-w-xs">{item.remarks}</td>
                <td className="px-4 py-3">
                  <button
                    type="button"
                    onClick={() => onRemove(item.itemCode)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg min-h-0 min-w-0"
                    aria-label={`Remove ${item.itemCode}`}
                  >
                    <Trash2 size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="md:hidden divide-y divide-slate-100">
        {items.map((item) => (
          <div key={item.itemCode} className="p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-mono text-sm font-medium">{item.itemCode}</p>
                <p className="text-sm text-slate-600 mt-0.5">{item.itemName}</p>
              </div>
              <button
                type="button"
                onClick={() => onRemove(item.itemCode)}
                className="p-2 text-red-500 min-h-0 min-w-0"
              >
                <Trash2 size={16} />
              </button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              <CategoryBadge category={item.category} />
              <span className="text-xs text-slate-500">
                {formatDate(item.certificationDate)} → {formatDate(item.certificationExpiry)}
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-2">{item.remarks}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

