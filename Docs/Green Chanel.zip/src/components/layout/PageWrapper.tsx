import { cn } from '@/lib/utils/cn';

interface PageWrapperProps {
  title: string;
  description?: string;
  badge?: number;
  headerActions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}

export function PageWrapper({
  title,
  description,
  badge,
  headerActions,
  children,
  className,
}: PageWrapperProps) {
  return (
    <div className={cn('page-container mobile-safe-bottom', className)}>
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">{title}</h1>
            {badge !== undefined && badge > 0 && (
              <span className="bg-orange-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                {badge}
              </span>
            )}
          </div>
          {description && <p className="text-sm text-slate-500 mt-1">{description}</p>}
        </div>
        {headerActions && <div className="flex items-center gap-2 shrink-0">{headerActions}</div>}
      </div>
      {children}
    </div>
  );
}
