import { cn } from '@/lib/utils/cn';

interface DatePickerFieldProps {
  label?: string;
  value: string;
  onChange: (value: string) => void;
  min?: string;
  error?: string;
  className?: string;
}

export function DatePickerField({
  label,
  value,
  onChange,
  min,
  error,
  className,
}: DatePickerFieldProps) {
  const today = new Date().toISOString().split('T')[0];

  return (
    <div className={cn('flex flex-col gap-1.5', className)}>
      {label && <label className="text-sm font-medium text-slate-700">{label}</label>}
      <input
        type="date"
        value={value}
        min={min ?? today}
        onChange={(e) => onChange(e.target.value)}
        className={cn(
          'w-full px-3 py-2.5 text-sm rounded-lg border min-h-[44px]',
          error
            ? 'border-red-300 focus:ring-red-200'
            : 'border-slate-300 focus:ring-blue-200 focus:border-blue-400',
          'focus:outline-none focus:ring-2'
        )}
      />
      {error && <span className="text-xs text-red-600">{error}</span>}
    </div>
  );
}
