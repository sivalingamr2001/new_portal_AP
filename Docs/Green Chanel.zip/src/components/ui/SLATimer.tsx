import { cn } from '@/lib/utils/cn';
import { formatPendingDuration, isSlaBreached } from '@/lib/utils/date';
import { Clock } from 'lucide-react';

export function SLATimer({ submittedAt }: { submittedAt: string }) {
  const breached = isSlaBreached(submittedAt);
  const duration = formatPendingDuration(submittedAt);

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 text-xs font-medium',
        breached ? 'text-amber-600' : 'text-slate-500'
      )}
    >
      <Clock size={12} className={breached ? 'text-amber-500' : 'text-slate-400'} />
      {duration}
    </span>
  );
}
