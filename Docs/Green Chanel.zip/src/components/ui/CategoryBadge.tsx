import { cn } from '@/lib/utils/cn';

const CATEGORY_COLORS: Record<string, string> = {
  Bearings: 'bg-blue-50 text-blue-700 border-blue-200',
  Fasteners: 'bg-slate-100 text-slate-700 border-slate-200',
  Sealing: 'bg-cyan-50 text-cyan-700 border-cyan-200',
  Shafts: 'bg-violet-50 text-violet-700 border-violet-200',
  Springs: 'bg-amber-50 text-amber-700 border-amber-200',
  Pneumatics: 'bg-indigo-50 text-indigo-700 border-indigo-200',
  Other: 'bg-slate-50 text-slate-600 border-slate-200',
};

export function CategoryBadge({ category }: { category: string }) {
  return (
    <span
      className={cn(
        'inline-flex px-2 py-0.5 rounded-md text-xs font-medium border',
        CATEGORY_COLORS[category] ?? CATEGORY_COLORS.Other
      )}
    >
      {category}
    </span>
  );
}
