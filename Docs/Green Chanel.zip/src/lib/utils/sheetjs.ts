import * as XLSX from 'xlsx';
import type { BulkUploadRow } from '@/lib/types/certification.types';

const REQUIRED_COLUMNS = ['ItemCode', 'ItemName', 'CertificationDate', 'Remarks'];

export function parseAndValidateBulkUpload(file: ArrayBuffer): BulkUploadRow[] {
  const workbook = XLSX.read(file, { type: 'array' });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const raw = XLSX.utils.sheet_to_json<Record<string, string>>(sheet);

  return raw.map((row, index) => {
    const errors: string[] = [];
    const itemCode = row.ItemCode ?? row.itemCode ?? '';
    const itemName = row.ItemName ?? row.itemName ?? '';
    const certificationDate = row.CertificationDate ?? row.certificationDate ?? '';
    const remarks = row.Remarks ?? row.remarks ?? '';

    if (!itemCode) errors.push('Item code required');
    if (!itemName) errors.push('Item name required');
    if (!certificationDate) errors.push('Certification date required');
    if (!remarks || remarks.length < 20) errors.push('Remarks must be at least 20 characters');

    return {
      itemCode,
      itemName,
      certificationDate,
      remarks,
      _rowIndex: index + 2,
      _errors: errors,
      _isValid: errors.length === 0,
    };
  });
}

export function downloadBulkUploadTemplate() {
  const ws = XLSX.utils.aoa_to_sheet([
    REQUIRED_COLUMNS,
    ['BRG-2024-A', 'Precision Bearing Assembly', '2026-05-19', 'Sample remarks with at least twenty characters here.'],
  ]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Template');
  XLSX.writeFile(wb, 'gcc-bulk-upload-template.xlsx');
}
