import type { CertificationItem } from '@/lib/types/certification.types';

export async function submitCertification(
  vendorId: string,
  vendorCode: string,
  vendorName: string,
  items: CertificationItem[]
): Promise<{ requestId: string }> {
  await delay(600);
  const requestId = `GC-${Math.floor(100000 + Math.random() * 900000)}`;
  console.info('Submitted certification', { requestId, vendorId, vendorCode, vendorName, items });
  return { requestId };
}

function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
