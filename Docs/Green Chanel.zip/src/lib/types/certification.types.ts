import type { ItemCategory } from './vendor.types';

export interface CertificationItem {
  itemCode: string;
  itemName: string;
  category: ItemCategory;
  certificationDate: string;
  certificationExpiry: string;
  remarks: string;
}

export interface CertificationDraft {
  vendorId: string;
  vendorCode: string;
  vendorName: string;
  items: CertificationItem[];
  createdAt: string;
  isDirty: boolean;
}

export interface CertificationRequest {
  requestId: string;
  vendorId: string;
  vendorCode: string;
  vendorName: string;
  items: CertificationItem[];
  submittedAt: string;
  submittedBy: string;
  status: CertificationStatus;
}

export type CertificationStatus = 'pending' | 'approved' | 'rejected' | 'expired';

export interface BulkUploadRow {
  itemCode: string;
  itemName: string;
  certificationDate: string;
  remarks: string;
  _rowIndex: number;
  _errors: string[];
  _isValid: boolean;
}
