import { createBrowserRouter, RouterProvider, Navigate } from 'react-router-dom';
import { AppShell } from '@/components/layout/AppShell';
import { DashboardPage } from '@/features/dashboard/DashboardPage';
import { CertificationPage } from '@/features/certification/CertificationPage';
import { CertificationPreviewPage } from '@/features/certification/CertificationPreviewPage';
import { ApprovalsPage } from '@/features/approvals/ApprovalsPage';
import { ReportsPage } from '@/features/reports/ReportsPage';
import { AuditTrailPage } from '@/features/audit/AuditTrailPage';
import { NotFoundPage } from '@/components/ui/NotFoundPage';

const router = createBrowserRouter([
  {
    path: '/',
    element: <AppShell />,
    children: [
      { index: true, element: <Navigate to="/dashboard" replace /> },
      { path: 'dashboard', element: <DashboardPage /> },
      {
        path: 'certifications',
        children: [
          { index: true, element: <CertificationPage /> },
          { path: 'preview', element: <CertificationPreviewPage /> },
        ],
      },
      { path: 'approvals', element: <ApprovalsPage /> },
      { path: 'reports', element: <ReportsPage /> },
      { path: 'audit', element: <AuditTrailPage /> },
    ],
  },
  { path: '*', element: <NotFoundPage /> },
]);

export function AppRouter() {
  return <RouterProvider router={router} />;
}
