﻿using Microsoft.EntityFrameworkCore;
using Server.Core.Domain.Entities;
using Server.Core.Domain.Enums;
using Server.Core.Interfaces;
using Server.Infrastructure.Data;

namespace Server.Infrastructure.Services;

public sealed class AccessRequestWorkflow(
    AppDbContext appDb,
    IdentityDbContext identityDb) : IAccessRequestWorkflow
{
    private const string ItRoleGroupName = "IT";

    private static readonly SemaphoreSlim TicketSemaphore = new(1, 1);

    /// <summary>
    /// Stage 0: Registers a master request envelope with multi-item folder tokens.
    /// </summary>
    public async Task<int> CreateMultiItemRequestAsync(int requesterUserId, List<(string FolderPath, AccessTypes AccessType, string Reason)> items)
    {
        if (items == null || items.Count == 0)
        {
            throw new ArgumentException("Workflow Abort: An access request submission block must contain at least one folder item.");
        }

        var userAccount = await identityDb.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.UserId == requesterUserId)
            ?? throw new KeyNotFoundException($"Security Boundary Failure: User profile ID #{requesterUserId} does not exist.");

        if (userAccount.DeptId == null)
        {
            throw new InvalidOperationException($"Data Alignment Failure: User '{userAccount.UserName}' is not currently linked to an active department.");
        }

        var userDepartment = await appDb.Departments
            .AsNoTracking()
            .FirstOrDefaultAsync(d => d.DepartmentId == userAccount.DeptId)
            ?? throw new InvalidOperationException($"Configuration Gap: Primary department mapping records are missing for ID #{userAccount.DeptId}.");

        int userDirectHodId = userDepartment.HodId ?? 0;
        if (userDirectHodId == 0)
        {
            throw new InvalidOperationException("Workflow Abort: The requester's designated department does not have an active HOD assigned.");
        }

        var userDirectHodProfile = await identityDb.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.UserId == userDirectHodId);

        using var transaction = await appDb.Database.BeginTransactionAsync();
        try
        {
            var accessRequest = new AccessRequestEntity
            {
                UserId = requesterUserId,
                ReqTo = userDirectHodId,
                IsAgreed = false,
                ItsrNo = "BATCH-" + DateTime.UtcNow.ToString("yyyyMMddHHmmss")
            };
            appDb.AccessRequests.Add(accessRequest);
            await appDb.SaveChangesAsync();

            foreach (var item in items)
            {
                var folderMapping = await appDb.FolderMappings
                    .AsNoTracking()
                    .FirstOrDefaultAsync(f => item.FolderPath.StartsWith(f.FolderName))
                    ?? throw new KeyNotFoundException($"Security Guard: The path string '{item.FolderPath}' does not map to any registered corporate assets.");

                int folderOwnerHodId = folderMapping.PrimaryHodId;
                string generatedTicketNumber = await GenerateNextTicketNumberSequenceAsync();

                var accessItem = new AccessItemEntity
                {
                    AccessReqId = accessRequest.AccessReqId,
                    TicketNumber = generatedTicketNumber,
                    FolderPath = item.FolderPath,
                    Reason = item.Reason,
                    AccessType = item.AccessType,
                    ConfirmAccessType = item.AccessType,
                    Status = RequestStatus.Pending
                };
                appDb.AccessItems.Add(accessItem);
                await appDb.SaveChangesAsync();

                var notifyDirectHod = new AccessReqAuditEntity
                {
                    AccessReqId = accessRequest.AccessReqId,
                    AccessItemId = accessItem.AccessItemId,
                    EventType = "HOD_PENDING",
                    Message = $"Access item ticket {generatedTicketNumber} submitted by your team member {userAccount.UserName} requires validation.",
                    RecipientUserId = userDirectHodId,
                    RecipientName = userDirectHodProfile?.UserName ?? "Department Head",
                    RecipientRole = "Hod",
                    IsRead = false
                };
                appDb.AccessReqAudits.Add(notifyDirectHod);

                if (folderOwnerHodId != userDirectHodId && folderOwnerHodId != 0)
                {
                    var folderHodProfile = await identityDb.Users
                        .AsNoTracking()
                        .FirstOrDefaultAsync(u => u.UserId == folderOwnerHodId);

                    var notifyFolderOwner = new AccessReqAuditEntity
                    {
                        AccessReqId = accessRequest.AccessReqId,
                        AccessItemId = accessItem.AccessItemId,
                        EventType = "OWNER_PENDING",
                        Message = $"Cross-department asset ticket {generatedTicketNumber} filed by {userAccount.UserName} requires data security clearance.",
                        RecipientUserId = folderOwnerHodId,
                        RecipientName = folderHodProfile?.UserName ?? folderMapping.PrimaryHodName ?? "Asset Data Owner HOD",
                        RecipientRole = "Hod",
                        IsRead = false
                    };
                    appDb.AccessReqAudits.Add(notifyFolderOwner);
                }
            }

            await appDb.SaveChangesAsync();
            await transaction.CommitAsync();
            return accessRequest.AccessReqId;
        }
        catch (Exception)
        {
            await transaction.RollbackAsync();
            throw;
        }
    }

    /// <summary>
    /// Stage 1: Processes an approval or rejection decision for a specific line item ticket. 
    /// Handles single-approval short-circuiting to the IT queue or immediate veto/termination.
    /// </summary>
    public async Task ProcessItemApprovalAsync(int currentApproverId, int accessItemId, RequestStatus decision, string comments)
    {
        // 1. Load the specific operational line item tracking target with its master context
        var lineItem = await appDb.AccessItems
            .Include(ai => ai.AccessRequest)
            .FirstOrDefaultAsync(ai => ai.AccessItemId == accessItemId)
            ?? throw new KeyNotFoundException($"Transactional Fault: Line item tracking reference #{accessItemId} was not found.");

        // Concurrency Guard Rule: Prevent double processing or tampering with finalized states
        if (lineItem.Status == RequestStatus.Rejected ||
            lineItem.Status == RequestStatus.ApprovedByHod ||
            lineItem.Status == RequestStatus.Completed)
        {
            throw new InvalidOperationException($"Concurrency Shield: This individual item ticket ({lineItem.TicketNumber}) has already been finalized or advanced.");
        }

        // 2. Resolve folder asset mappings to evaluate structural boundaries
        var folderMapping = await appDb.FolderMappings
            .AsNoTracking()
            .FirstOrDefaultAsync(f => lineItem.FolderPath.StartsWith(f.FolderName))
            ?? throw new InvalidOperationException($"Configuration Error: Asset path rules missing for route '{lineItem.FolderPath}'.");

        // 3. Look up requester profile metadata to identify their structural department authorities
        var requesterAccount = await identityDb.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.UserId == lineItem.AccessRequest.UserId)
            ?? throw new InvalidOperationException("Data Integrity Fault: The original requester account no longer exists.");

        var requesterDept = await appDb.Departments
            .AsNoTracking()
            .FirstOrDefaultAsync(d => d.DepartmentId == requesterAccount.DeptId);

        int userDirectHodId = requesterDept?.HodId ?? 0;
        int folderOwnerHodId = folderMapping.PrimaryHodId;

        // Strict Security Authorization Check: Verify the actor is either the Line Manager or the Data Owner
        bool isUserDirectHod = currentApproverId == userDirectHodId;
        bool isFolderOwnerHod = currentApproverId == folderOwnerHodId;

        if (!isUserDirectHod && !isFolderOwnerHod)
        {
            throw new UnauthorizedAccessException("Access Denied: You do not possess structural validation credentials to evaluate this folder item ticket.");
        }

        // Fetch interactive author profile for log clarity (Connection 1)
        var approverProfile = await identityDb.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.UserId == currentApproverId);
        string approverName = approverProfile?.UserName ?? "Authorized Head";

        // Open transaction block to preserve data consistency across approvals and audits
        using var transaction = await appDb.Database.BeginTransactionAsync();
        try
        {
            // =======================================================================================
            // PATH BRANCH A: THE VETO REJECTION ENGINE (Immediate Individual Ticket Failure)
            // =======================================================================================
            if (decision == RequestStatus.Rejected)
            {
                lineItem.Status = RequestStatus.Rejected;

                // Document persistent historical sign-off timeline footprint
                var approvalRow = new AccessApprovalEntity
                {
                    AccessReqId = lineItem.AccessReqId,
                    AccessItemId = lineItem.AccessItemId,
                    ApproverId = currentApproverId,
                    ApprovalStatus = RequestStatus.Rejected,
                    Comments = comments
                };
                appDb.Approvals.Add(approvalRow);

                // Deliver exactly ONE targeted notification alert straight to the requester's inbox
                var vetoNotification = new AccessReqAuditEntity
                {
                    AccessReqId = lineItem.AccessReqId,
                    AccessItemId = lineItem.AccessItemId,
                    EventType = "REQUEST_REJECTED",
                    Message = $"Your item ticket '{lineItem.TicketNumber}' for folder path '{lineItem.FolderPath}' was rejected by {approverName}. Reason: {comments}",
                    RecipientUserId = lineItem.AccessRequest.UserId,
                    RecipientName = requesterAccount.UserName ?? "Requester Account",
                    RecipientRole = "User",
                    IsRead = false
                };
                appDb.AccessReqAudits.Add(vetoNotification);

                await appDb.SaveChangesAsync();
                await transaction.CommitAsync();

                // Sweep structural context state to evaluate if this closes out the overarching parent container
                await EvaluateParentHeaderResolutionStateAsync(lineItem.AccessReqId);
                return;
            }

            // =======================================================================================
            // PATH BRANCH B: THE SHORT-CIRCUIT GREENLIGHT ENGINE (One Manager Sign-off Routes straight to IT)
            // =======================================================================================
            if (decision == RequestStatus.Approved)
            {
                lineItem.Status = RequestStatus.ApprovedByHod;

                // Log persistent sign-off tracking data
                var approvalRow = new AccessApprovalEntity
                {
                    AccessReqId = lineItem.AccessReqId,
                    AccessItemId = lineItem.AccessItemId,
                    ApproverId = currentApproverId,
                    ApprovalStatus = RequestStatus.Approved,
                    Comments = comments
                };
                appDb.Approvals.Add(approvalRow);

                // Locate the active queue worker configuration identifier on the IT operations desk
                var targetItUserDetail = await appDb.UserDetails
                    .AsNoTracking()
                    .FirstOrDefaultAsync(ud => ud.UserRole == ItRoleGroupName && ud.IsActive);

                int targetItUserId = targetItUserDetail?.UserId ?? 0;
                if (targetItUserId != 0)
                {
                    var itProfileAccount = await identityDb.Users
                        .AsNoTracking()
                        .FirstOrDefaultAsync(u => u.UserId == targetItUserId);

                    // Dispatch exactly ONE system alert row to direct the IT Engineer team to provision the share
                    var itNotification = new AccessReqAuditEntity
                    {
                        AccessReqId = lineItem.AccessReqId,
                        AccessItemId = lineItem.AccessItemId,
                        EventType = "IT_PENDING",
                        Message = $"Item ticket {lineItem.TicketNumber} has cleared governance verification via {approverName}. Routed to IT for physical permission mapping.",
                        RecipientUserId = targetItUserId,
                        RecipientName = itProfileAccount?.UserName ?? "IT Provisioning Queue",
                        RecipientRole = ItRoleGroupName,
                        IsRead = false
                    };
                    appDb.AccessReqAudits.Add(itNotification);
                }

                // Push workflow handover pointer to track the IT queue desk assignment
                lineItem.AccessRequest.ReqTo = targetItUserId;

                await appDb.SaveChangesAsync();
                await transaction.CommitAsync();

                // Sweep structural context state to evaluate if this closes out the overarching parent container
                await EvaluateParentHeaderResolutionStateAsync(lineItem.AccessReqId);
            }
        }
        catch (Exception)
        {
            await transaction.RollbackAsync();
            throw;
        }
    }

    /// <summary>
    /// Ad-hoc Stage: Enables an authorized IT administrator to immediately force-terminate active folder permissions.
    /// Triggers an urgent revocation audit record trace and sets the parent resolution state.
    /// </summary>
    /// <summary>
    /// Ad-hoc Stage: Forced manual administrative revocation.
    /// </summary>
    public async Task RevokeAccessAsync(int itAgentUserId, int accessItemId, string revocationReason)
    {
        if (string.IsNullOrWhiteSpace(revocationReason))
        {
            throw new ArgumentException("Compliance Guard: A valid reason must be provided.");
        }

        var lineItem = await appDb.AccessItems
            .Include(ai => ai.AccessRequest)
            .FirstOrDefaultAsync(ai => ai.AccessItemId == accessItemId)
            ?? throw new KeyNotFoundException($"Request item ticket ID #{accessItemId} not found.");

        if (lineItem.Status != RequestStatus.Completed)
        {
            throw new InvalidOperationException($"Validation Error: Ticket '{lineItem.TicketNumber}' cannot be revoked because it is not Completed.");
        }

        // Fixed CS0201: Added explicit variable assignment ('var _ =') to validate the expression
        var _ = await appDb.UserDetails
            .AsNoTracking()
            .FirstOrDefaultAsync(ud => ud.UserId == itAgentUserId && ud.UserRole == ItRoleGroupName && ud.IsActive)
            ?? throw new UnauthorizedAccessException("Security Violation: Action restricted exclusively to active IT Administration agents.");

        var requesterAccount = await identityDb.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.UserId == lineItem.AccessRequest.UserId);

        using var transaction = await appDb.Database.BeginTransactionAsync();
        try
        {
            lineItem.Status = RequestStatus.Revoked;
            lineItem.RevokedOn = DateTime.UtcNow;
            lineItem.RevokedBy = itAgentUserId;

            // Fixed Error: Corrected spelling variable designation token signature alignment
            var revocationApprovalRow = new AccessApprovalEntity
            {
                AccessReqId = lineItem.AccessReqId,
                AccessItemId = lineItem.AccessItemId,
                ApproverId = itAgentUserId,
                ApprovalStatus = RequestStatus.Revoked,
                Comments = $"IT FORCE REVOCATION: {revocationReason}"
            };
            appDb.Approvals.Add(revocationApprovalRow);

            // Fixed Error: Balanced statement formatting parameters with proper closing boundaries
            appDb.AccessReqAudits.Add(new AccessReqAuditEntity
            {
                AccessReqId = lineItem.AccessReqId,
                AccessItemId = lineItem.AccessItemId,
                EventType = "ACCESS_REVOKED",
                Message = $"CRITICAL: Your permissions for ticket '{lineItem.TicketNumber}' have been force-terminated by IT. Reason: {revocationReason}",
                RecipientUserId = lineItem.AccessRequest.UserId,
                RecipientName = requesterAccount?.UserName ?? "Requester Account",
                RecipientRole = "User",
                IsRead = false
            });

            await appDb.SaveChangesAsync();
            await transaction.CommitAsync();
            await EvaluateParentHeaderResolutionStateAsync(lineItem.AccessReqId);
        }
        catch (Exception)
        {
            await transaction.RollbackAsync();
            throw;
        }
    }

    /// <summary>
    /// Lifecycle Recycle Gate: Allows a user to instantly clone and resubmit a failed, revoked, or expired access item ticket.
    /// Extracts original properties and forwards them directly to the Stage 0 creation engine.
    /// </summary>
    /// <param name="requesterUserId">The database ID of the user requesting the recycle execution.</param>
    /// <param name="historicalAccessItemId">The old, inactive access item identifier to use as a template.</param>
    /// <param name="updatedReasonIfAny">An optional fresh business justification string to replace the old text.</param>
    /// <returns>The newly generated cloned master AccessRequest identifier.</returns>
    public async Task<int> ResubmitExpiredOrFailedRequestAsync(int requesterUserId, int historicalAccessItemId, string? updatedReasonIfAny = null)
    {
        // 1. Fetch the historical source item context with its core master configurations
        var oldLineItem = await appDb.AccessItems
            .Include(ai => ai.AccessRequest)
            .FirstOrDefaultAsync(ai => ai.AccessItemId == historicalAccessItemId)
            ?? throw new KeyNotFoundException($"Data Validation Error: Historical tracking ticket ID #{historicalAccessItemId} was not found.");

        // Strict Security Guard Rule: Enforce user identity ownership boundaries
        if (oldLineItem.AccessRequest.UserId != requesterUserId)
        {
            throw new UnauthorizedAccessException("Security Guard: You can only resubmit and recycle requests originally created by your own account session.");
        }

        // State Validation Gate: Block active, processing, or valid tokens from undergoing duplicate resubmissions
        if (oldLineItem.Status == RequestStatus.Pending ||
            oldLineItem.Status == RequestStatus.ApprovedByHod ||
            oldLineItem.Status == RequestStatus.Completed)
        {
            throw new InvalidOperationException($"Workflow Abort: Ticket '{oldLineItem.TicketNumber}' is currently active or fully approved. Resubmission denied.");
        }

        // 2. Wrap historical item properties inside an explicit single-item matrix list collection
        var singleItemBatch = new List<(string FolderPath, AccessTypes AccessType, string Reason)>
        {
            (
                FolderPath: oldLineItem.FolderPath,
                AccessType: oldLineItem.AccessType,
                Reason: !string.IsNullOrWhiteSpace(updatedReasonIfAny) ? updatedReasonIfAny : oldLineItem.Reason
            )
        };

        // 3. Open explicit transactional boundary to handle the history footprint log safely
        using var transaction = await appDb.Database.BeginTransactionAsync();
        try
        {
            string historicTicketIdStr = oldLineItem.TicketNumber;

            // Log an explicit operational footprint indicating this ticket was recycled
            var recycleAuditLog = new AccessReqAuditEntity
            {
                AccessReqId = oldLineItem.AccessReqId,
                AccessItemId = oldLineItem.AccessItemId,
                EventType = "TICKET_RESUBMITTED",
                Message = $"User has recycled historical item ticket {historicTicketIdStr} to instantiate a brand new workflow request sequence loop.",
                RecipientUserId = requesterUserId,
                RecipientName = "System Audit Trail Log",
                RecipientRole = "System",
                IsRead = true // Automatically marked read since it serves as a pure structural tracking trail
            };
            appDb.AccessReqAudits.Add(recycleAuditLog);
            await appDb.SaveChangesAsync();

            // 4. Delegate compilation logic parameters straight back to our thread-safe Create Request block
            // This automatically handles fresh master headers, calculates next month sequences, and alerts target HODs.
            int modernGeneratedMasterRequestId = await CreateMultiItemRequestAsync(
                requesterUserId,
                singleItemBatch
            );

            // Commit historical logs and inner creation engine elements together
            await transaction.CommitAsync();

            return modernGeneratedMasterRequestId;
        }
        catch (Exception)
        {
            await transaction.RollbackAsync();
            throw;
        }
    }

    /// <summary>
    /// Stage 2: Finalizes provisioning closeout for an individual line item ticket, 
    /// appending a strict 90-day time capsule upon successful setup.
    /// </summary>
    public async Task FinalizeItemProvisioningAsync(int itAgentUserId, int accessItemId, RequestStatus finalDecision, AccessTypes confirmedAccessType, string operationalComments)
    {
        var lineItem = await appDb.AccessItems
            .Include(ai => ai.AccessRequest)
            .FirstOrDefaultAsync(ai => ai.AccessItemId == accessItemId)
            ?? throw new KeyNotFoundException($"Infrastructure Error: Access item context ID #{accessItemId} missing reference.");

        if (lineItem.Status != RequestStatus.ApprovedByHod)
        {
            throw new InvalidOperationException($"State Exception: Target item ticket ({lineItem.TicketNumber}) cannot undergo infrastructure provisioning without prior HOD clear-stamps.");
        }

        // Fixed CS0201: Added explicit variable assignment ('var _ =') to validate the expression
        var _ = await appDb.UserDetails
            .AsNoTracking()
            .FirstOrDefaultAsync(ud => ud.UserId == itAgentUserId && ud.UserRole == ItRoleGroupName && ud.IsActive)
            ?? throw new UnauthorizedAccessException("Security Violation: Action restricted to active IT agents.");

        var requesterAccount = await identityDb.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.UserId == lineItem.AccessRequest.UserId)
            ?? throw new InvalidOperationException("Data Integrity Fault: The original requester account no longer exists.");

        var folderMapping = await appDb.FolderMappings
            .AsNoTracking()
            .FirstOrDefaultAsync(f => lineItem.FolderPath.StartsWith(f.FolderName))
            ?? throw new InvalidOperationException($"Configuration Error: Asset path rules missing for route '{lineItem.FolderPath}'.");

        var requesterDept = await appDb.Departments
            .AsNoTracking()
            .FirstOrDefaultAsync(d => d.DepartmentId == requesterAccount.DeptId);

        int userDirectHodId = requesterDept?.HodId ?? 0;
        int folderOwnerHodId = folderMapping.PrimaryHodId;
        bool isCrossDepartment = folderOwnerHodId != userDirectHodId && folderOwnerHodId != 0;

        using var transaction = await appDb.Database.BeginTransactionAsync();
        try
        {
            if (finalDecision == RequestStatus.ItemRejectedByIt || finalDecision == RequestStatus.Rejected)
            {
                lineItem.Status = RequestStatus.Rejected;

                appDb.AccessReqAudits.Add(new AccessReqAuditEntity
                {
                    AccessReqId = lineItem.AccessReqId,
                    AccessItemId = lineItem.AccessItemId,
                    EventType = "IT_REJECTED",
                    Message = $"IT Operations Desk has declined the configuration deployment for your individual item ticket {lineItem.TicketNumber}. Notes: {operationalComments}",
                    RecipientUserId = lineItem.AccessRequest.UserId,
                    RecipientName = requesterAccount.UserName ?? "Requester Account",
                    RecipientRole = "User",
                    IsRead = false
                });
            }
            else if (finalDecision == RequestStatus.Completed)
            {
                var currentUtcTime = DateTime.UtcNow;

                lineItem.Status = RequestStatus.Completed;
                lineItem.ConfirmAccessType = confirmedAccessType;
                lineItem.AccessFrom = currentUtcTime;
                lineItem.AccessTo = currentUtcTime.AddDays(90);

                string auditMetaSummary = isCrossDepartment
                    ? "Passed combined Line Management and Data Asset Owner authorization gates."
                    : "Passed local Department Head validation gate.";

                appDb.AccessReqAudits.Add(new AccessReqAuditEntity
                {
                    AccessReqId = lineItem.AccessReqId,
                    AccessItemId = lineItem.AccessItemId,
                    EventType = "ACCESS_GRANTED",
                    Message = $"Provisioning complete for ticket {lineItem.TicketNumber}. {auditMetaSummary} Full '{confirmedAccessType}' rights mapped until {lineItem.AccessTo:yyyy-MM-dd}.",
                    RecipientUserId = lineItem.AccessRequest.UserId,
                    RecipientName = requesterAccount.UserName ?? "Requester Account",
                    RecipientRole = "User",
                    IsRead = false
                });
            }
            else
            {
                throw new ArgumentException("Workflow Fault: Invalid execution decision parameter passed for IT provisioning closeout.");
            }

            appDb.Approvals.Add(new AccessApprovalEntity
            {
                AccessReqId = lineItem.AccessReqId,
                AccessItemId = lineItem.AccessItemId,
                ApproverId = itAgentUserId,
                ApprovalStatus = finalDecision,
                Comments = $"IT Ticket Closeout: {operationalComments}"
            });

            await appDb.SaveChangesAsync();
            await transaction.CommitAsync();
            await EvaluateParentHeaderResolutionStateAsync(lineItem.AccessReqId);
        }
        catch (Exception)
        {
            await transaction.RollbackAsync();
            throw;
        }
    }

    #region Private Workflow Core Utilities

    /// <summary>
    /// Generates the next sequential unique ticket identifier in a high-performance, thread-safe format: REQ-202606-001
    /// </summary>
    private async Task<string> GenerateNextTicketNumberSequenceAsync()
    {
        await TicketSemaphore.WaitAsync();
        try
        {
            // Production Standard: Ensure dates align with system execution time context (202606)
            var currentUtcTime = DateTime.UtcNow;
            string prefixYearMonth = currentUtcTime.ToString("yyyyMM");
            string targetTokenMatch = $"REQ-{prefixYearMonth}-";

            // Find the highest sequence current suffix number living in the DB for the current month
            var lastTicketInCurrentMonth = await appDb.AccessItems
                .AsNoTracking()
                .Where(ai => ai.TicketNumber.StartsWith(targetTokenMatch))
                .OrderByDescending(ai => ai.TicketNumber)
                .Select(ai => ai.TicketNumber)
                .FirstOrDefaultAsync();

            int nextSequenceNumber = 1;

            if (lastTicketInCurrentMonth != null)
            {
                string suffixPart = lastTicketInCurrentMonth.Substring(targetTokenMatch.Length);
                if (int.TryParse(suffixPart, out int currentHighestSuffix))
                {
                    nextSequenceNumber = currentHighestSuffix + 1;
                }
            }

            return $"{targetTokenMatch}{nextSequenceNumber:D3}"; // D3 padding formatting yields "001"
        }
        finally
        {
            TicketSemaphore.Release();
        }
    }

    /// <summary>
    /// Evaluates if all sub-items inside a parent access batch are complete to flip the master global header safely.
    /// </summary>
    private async Task EvaluateParentHeaderResolutionStateAsync(int parentAccessReqId)
    {
        var masterRequest = await appDb.AccessRequests
            .Include(r => r.AccessItems)
            .FirstOrDefaultAsync(r => r.AccessReqId == parentAccessReqId);

        if (masterRequest != null)
        {
            // If ANY single line item inside this master batch is still pending processing by HOD or IT, 
            // the master envelope header 'IsAgreed' remains false.
            bool holdsActiveUnresolvedItems = masterRequest.AccessItems
                .Any(ai => ai.Status == RequestStatus.Pending || ai.Status == RequestStatus.ApprovedByHod);

            masterRequest.IsAgreed = !holdsActiveUnresolvedItems;
            await appDb.SaveChangesAsync();
        }
    }

    #endregion
}
