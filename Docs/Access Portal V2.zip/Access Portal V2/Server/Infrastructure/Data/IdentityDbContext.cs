﻿using global::Server.Core.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Server.Infrastructure.Data;

public sealed class IdentityDbContext : DbContext
{
    public IdentityDbContext(DbContextOptions options) : base(options)
    {
        ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
    }

    public DbSet<UserAccount> Users => Set<UserAccount>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<UserAccount>(builder =>
        {
            builder.ToTable("jan_complaint_login", t => t.ExcludeFromMigrations()); // Safe boundary
            builder.HasKey(x => x.UserId);

            builder.Ignore(x => x.UserDetail);
            builder.Ignore(x => x.Department);
        });
    }

    public override int SaveChanges() => throw new InvalidOperationException("IdentityDbContext is strictly read-only.");
    public override int SaveChanges(bool acceptAllChangesOnSuccess) => throw new InvalidOperationException("IdentityDbContext is strictly read-only.");
    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default) => throw new InvalidOperationException("IdentityDbContext is strictly read-only.");
    public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default) => throw new InvalidOperationException("IdentityDbContext is strictly read-only.");
}
