﻿using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using Server.Core.Domain.Common;
using Server.Infrastructure.Data;
using Server.Infrastructure.Security;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

// =========================================================================
// 1. CONFIGURATION & VARIABLES
// =========================================================================
var connectionStringCmpl = builder.Configuration.GetConnectionString("MySQLConnection_CMPL");
var connectionStringHod = builder.Configuration.GetConnectionString("MySQLConnection_HOD");
var dbProvider = builder.Configuration.GetValue<string>("Database:Provider");

// =========================================================================
// 2. CORE SYSTEM SERVICES (DI Framework Foundations Must Load First!)
// =========================================================================
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    });

builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSignalR();
builder.Services.AddProblemDetails();

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Access Governance Web API", Version = "v1" });

    const string schemeId = "UserIdHeader";

    c.AddSecurityDefinition(schemeId, new OpenApiSecurityScheme
    {
        Description = "Enter your numeric User ID directly to authenticate requests (e.g., 1).",
        In = ParameterLocation.Header,
        Name = "X-User-Id",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "ApiKeyScheme"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = schemeId
                }
            },
            Array.Empty<string>()
        }
    });
});

// =========================================================================
// 3. CORS CONFIGURATION
// =========================================================================
const string CorsPolicyName = "SignalRAndApiPolicy";

builder.Services.AddCors(options =>
{
    options.AddPolicy(CorsPolicyName, policy =>
    {
        policy.WithOrigins("http://localhost:5173")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });
});

// =========================================================================
// 4. DATABASE CONTEXTS
// =========================================================================
var providerName = dbProvider?.Trim();
bool isMySql = !string.IsNullOrEmpty(providerName) && providerName.Equals("MySQL", StringComparison.OrdinalIgnoreCase);

var defaultConnection = builder.Configuration.GetConnectionString("DefaultConnection");
var sqliteConnection = builder.Configuration.GetConnectionString("SqliteConnection") ?? "Data Source=app.db";

var appServerVersion = ServerVersion.AutoDetect(defaultConnection);
var externalServerVersion = ServerVersion.AutoDetect(connectionStringCmpl);

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(defaultConnection, appServerVersion));

builder.Services.AddDbContext<IdentityDbContext>(options =>
    options.UseMySql(connectionStringCmpl, externalServerVersion));

// =========================================================================
// 5. APPLICATION SERVICES (DI REGISTRATION)
// =========================================================================
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentUserProvider, HttpHeaderUserProvider>();


// =========================================================================
// 6. PIPELINE & MIDDLEWARE BUILD
// =========================================================================
var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;   
    var env = services.GetRequiredService<IWebHostEnvironment>();
    var logger = services.GetRequiredService<ILoggerFactory>().CreateLogger("DatabaseInitializer");
    var db = services.GetRequiredService<AppDbContext>();

    try
    {
        await db.Database.EnsureCreatedAsync();
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "An error occurred while initializing the primary database tables.");
    }
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Web API v1");
        c.RoutePrefix = "swagger";
    });
}

app.UseExceptionHandler();
app.UseStatusCodePages();
app.UseHttpsRedirection();

app.UseCors(CorsPolicyName);

// =========================================================================
// 7. ENDPOINT MAPPINGS
// =========================================================================
app.MapControllers();
//app.MapHub<NotificationHub>("/hubs/notifications");

app.Run();
