﻿using global::Server.Core.Domain.Enums;

namespace Server.Core.Interfaces;

/// <summary>
/// Defines the enterprise architectural contract for the multi-item, dual-gate Access Request state machine.
/// </summary>
public interface IAccessRequestWorkflow
{
    /// <summary>
    /// Stage 0: Initiates a master request header containing multiple folder access line items. 
    /// Generates unique padded sequential tickets (e.g., REQ-202606-001) and dispatches target HOD notifications.
    /// </summary>
    /// <param name="requesterUserId">The database ID of the employee creating the request.</param>
    /// <param name="items">The collection of requested folder paths, access permission scopes, and business justifications.</param>
    /// <returns>The newly generated master AccessRequest identifier.</returns>
    Task<int> CreateMultiItemRequestAsync(int requesterUserId, List<(string FolderPath, AccessTypes AccessType, string Reason)> items);

    /// <summary>
    /// Stage 1: Processes an approval or rejection decision for a specific line item ticket. 
    /// Handles single-approval short-circuiting to the IT queue or immediate veto/termination.
    /// </summary>
    /// <param name="currentApproverId">The database ID of the approving Line HOD or Folder Data Owner.</param>
    /// <param name="accessItemId">The unique tracking identifier of the specific folder line item.</param>
    /// <param name="decision">The evaluation state status (Approved or Rejected).</param>
    /// <param name="comments">The explanatory feedback text written by the approver.</param>
    Task ProcessItemApprovalAsync(int currentApproverId, int accessItemId, RequestStatus decision, string comments);

    /// <summary>
    /// Stage 2: Finalizes provisioning for a specific line item ticket after it clears management blocks.
    /// Allocates the strict 90-day availability validity window upon completion.
    /// </summary>
    /// <param name="itAgentUserId">The database ID of the active IT Infrastructure Engineer processing the task.</param>
    /// <param name="accessItemId">The unique tracking identifier of the specific folder line item.</param>
    /// <param name="finalDecision">The resolution outcome parameter (Completed or Rejected).</param>
    /// <param name="confirmedAccessType">The final access permissions actively mapped on the network share directories.</param>
    /// <param name="operationalComments">The deployment notes or technical closeout remarks.</param>
    Task FinalizeItemProvisioningAsync(int itAgentUserId, int accessItemId, RequestStatus finalDecision, AccessTypes confirmedAccessType, string operationalComments);

    /// <summary>
    /// Ad-hoc Stage: Enables an authorized IT administrator to immediately force-terminate active folder permissions.
    /// Triggers an urgent revocation audit record trace.
    /// </summary>
    /// <param name="itAgentUserId">The database ID of the IT Engineer executing the revocation.</param>
    /// <param name="accessItemId">The unique tracking identifier of the active folder line item to terminate.</param>
    /// <param name="revocationReason">The compliance or security reason for shutting down folder access prematurely.</param>
    Task RevokeAccessAsync(int itAgentUserId, int accessItemId, string revocationReason);

    /// <summary>
    /// Lifecycle Recycle Gate: Implements a one-click resubmission pattern by automatically cloning 
    /// the folder specifications of a dead, expired, or rejected ticket into a fresh workflow loop.
    /// </summary>
    /// <param name="requesterUserId">The database ID of the user requesting the recycle execution.</param>
    /// <param name="historicalAccessItemId">The old, inactive access item identifier to use as a template.</param>
    /// <param name="updatedReasonIfAny">An optional fresh business justification string to replace the old text.</param>
    /// <returns>The newly generated cloned master AccessRequest identifier.</returns>
    Task<int> ResubmitExpiredOrFailedRequestAsync(int requesterUserId, int historicalAccessItemId, string? updatedReasonIfAny = null);
}
