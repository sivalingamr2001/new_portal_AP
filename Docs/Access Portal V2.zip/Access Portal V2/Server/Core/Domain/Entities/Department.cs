﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Server.Core.Domain.Entities;

[Table("jan_department")]
public class DepartmentEntity : BaseEntity
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    [Column("id")]
    public int DepartmentId { get; set; }

    [Required]
    [Column("dept_name")]
    [StringLength(150)]
    public string DepartmentName { get; set; } = string.Empty;

    [Column("hod_id")]
    public int? HodId { get; set; }

    // Relationship Links
    [ForeignKey(nameof(HodId))]
    public virtual UserAccount? HeadOfDepartment { get; set; }
}
