using Microsoft.AspNetCore.Mvc;
using Server.Core.Domain.Dto;
using Server.Core.Interfaces;

namespace Server.Controllers;

[ApiController]
[Route("api/access-requests")]
public sealed class AccessRequestsController(IAccessRequestWorkflow workflowEngine) : ControllerBase
{
    private const string UserIdHeaderName = "X-User-Id";

    /// <summary>
    /// POST: api/access-requests
    /// Stage 0: Submits a single batch folder request envelope containing multiple child tracking tickets.
    /// </summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> CreateRequest([FromBody] CreateRequestDto dto)
    {
        int requesterUserId = GetAuthenticatedUserId();

        // Convert DTO shapes to the ValueTuple schema expected by the workflow service layer
        var tupleCollection = dto.Items
            .Select(i => (i.FolderPath, i.AccessType, i.Reason))
            .ToList();

        int generatedMasterId = await workflowEngine.CreateMultiItemRequestAsync(requesterUserId, tupleCollection);

        return StatusCode(StatusCodes.Status201Created, new { masterRequestId = generatedMasterId, message = "Multi-item request batch initialized successfully." });
    }

    /// <summary>
    /// POST: api/access-requests/items/{itemId}/approve
    /// Stage 1: Submits an evaluation sign-off decision (Approve/Reject) on an item-by-ticket basis.
    /// </summary>
    [HttpPost("items/{itemId:int}/approve")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> ApproveItem([FromRoute] int itemId, [FromBody] ProcessApprovalDto dto)
    {
        int approverId = GetAuthenticatedUserId();

        await workflowEngine.ProcessItemApprovalAsync(approverId, itemId, dto.Decision, dto.Comments);

        return Ok(new { message = $"Item ticket #{itemId} evaluation state updated successfully." });
    }

    /// <summary>
    /// POST: api/access-requests/items/{itemId}/provision
    /// Stage 2: Final technical fulfillment closeout processing step managed by the IT Infrastructure Desk.
    /// </summary>
    [HttpPost("items/{itemId:int}/provision")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> ProvisionItem([FromRoute] int itemId, [FromBody] FinalizeProvisioningDto dto)
    {
        int itAgentId = GetAuthenticatedUserId();

        await workflowEngine.FinalizeItemProvisioningAsync(itAgentUserId: itAgentId, accessItemId: itemId, finalDecision: dto.FinalDecision, confirmedAccessType: dto.ConfirmedAccessType, operationalComments: dto.OperationalComments);

        return Ok(new { message = $"Infrastructure deployment lifecycle completed for item ticket #{itemId}." });
    }

    /// <summary>
    /// POST: api/access-requests/items/{itemId}/revoke
    /// Ad-hoc Stage: Direct force-termination of an active, completed permission ticket slot.
    /// </summary>
    [HttpPost("items/{itemId:int}/revoke")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> RevokeItem([FromRoute] int itemId, [FromBody] RevokeAccessDto dto)
    {
        int itAgentId = GetAuthenticatedUserId();

        await workflowEngine.RevokeAccessAsync(itAgentId, itemId, dto.RevocationReason);

        return Ok(new { message = $"Active drive access footprint for item ticket #{itemId} has been permanently revoked." });
    }

    /// <summary>
    /// POST: api/access-requests/items/{itemId}/resubmit
    /// Recycling Gate: Instantly clones and reinstantiates a dead request back into a fresh workflow tracking sequence.
    /// </summary>
    [HttpPost("items/{itemId:int}/resubmit")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> ResubmitItem([FromRoute] int itemId, [FromBody] ResubmitRequestDto dto)
    {
        int requesterUserId = GetAuthenticatedUserId();

        int freshMasterId = await workflowEngine.ResubmitExpiredOrFailedRequestAsync(requesterUserId, itemId, dto.UpdatedReason);

        return Ok(new { message = "One-click resubmission successful. Fresh workflow tracking path generated.", newMasterRequestId = freshMasterId });
    }

    #region Private Endpoint Helper Protections

    /// <summary>
    /// Extracts the custom identification context value parsed by your system middleware layers.
    /// </summary>
    private int GetAuthenticatedUserId()
    {
        if (Request.Headers.TryGetValue(UserIdHeaderName, out var headerValue) &&
            int.TryParse(headerValue, out var userId) && userId > 0)
        {
            return userId;
        }

        // Throw specialized HTTP status execution errors for missing header components
        throw new BadHttpRequestException("Security Protocol Breakage: Missing or invalid authentication identity contexts via 'X-User-Id' headers.", StatusCodes.Status401Unauthorized);
    }

    #endregion
}
