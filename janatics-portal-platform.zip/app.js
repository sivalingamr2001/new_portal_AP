/* =========================================
   JANATICS PORTAL PLATFORM — app.js
   Shared utilities and component registry
   ========================================= */

'use strict';

// ---- Portal Registry (embedded for file:// compatibility) ----
// Instead of fetch(), we embed the metadata directly in JS for
// zero-server file:// protocol support. studio.html manages state.

window.PORTAL_REGISTRY = {};

window.BUILTIN_PORTALS = {
  hr: {
    portalId: "hr",
    portalName: "HR Portal",
    portalIcon: "👥",
    portalColor: "#6366F1",
    layout: "sidebar-header",
    navigation: [
      { id: "dashboard", label: "Dashboard", icon: "📊", page: "dashboard" },
      { id: "employees", label: "Employees", icon: "👤", page: "grid" },
      { id: "onboarding", label: "Onboarding", icon: "📝", page: "form" },
      { id: "reports", label: "Reports", icon: "📈", page: "dashboard" }
    ],
    pages: [
      {
        pageId: "dashboard", pageTitle: "HR Dashboard",
        components: [
          { type: "widget", id: "w1", props: { label: "Total Employees", value: "1,248", trend: "+12", color: "#6366F1", icon: "👥" } },
          { type: "widget", id: "w2", props: { label: "Open Positions", value: "34", trend: "+5", color: "#F59E0B", icon: "💼" } },
          { type: "widget", id: "w3", props: { label: "On Leave Today", value: "17", trend: "-3", color: "#10B981", icon: "🌴" } },
          { type: "widget", id: "w4", props: { label: "New This Month", value: "23", trend: "+8", color: "#EF4444", icon: "🆕" } },
          { type: "card", id: "c1", props: { title: "Recent Activity", content: "5 new onboarding requests submitted. 3 leave approvals pending. Annual performance review cycle starts next week." } },
          { type: "card", id: "c2", props: { title: "Announcements", content: "Company-wide training on workplace safety is scheduled for June 15. Please ensure all team members have registered." } }
        ]
      },
      {
        pageId: "grid", pageTitle: "Employee Directory",
        components: [
          { type: "grid", id: "g1", props: {
            title: "All Employees",
            columns: ["Name", "Department", "Role", "Status", "Joined"],
            rows: [
              ["Arun Kumar", "Engineering", "Senior Developer", "Active", "2021-03-15"],
              ["Priya Sharma", "HR", "HR Manager", "Active", "2019-07-22"],
              ["Ravi Chandran", "Finance", "Finance Analyst", "Active", "2022-01-10"],
              ["Meena Nair", "Operations", "Ops Lead", "On Leave", "2020-09-05"],
              ["Suresh Babu", "Engineering", "Junior Developer", "Active", "2023-06-01"],
              ["Lakshmi Devi", "Marketing", "Content Strategist", "Active", "2021-11-30"],
              ["Vijay Raj", "Engineering", "DevOps Engineer", "Active", "2020-04-18"],
              ["Anitha Selvam", "HR", "Recruiter", "Active", "2022-08-25"]
            ]
          }}
        ]
      },
      {
        pageId: "form", pageTitle: "Employee Onboarding",
        components: [
          { type: "form", id: "f1", props: {
            title: "New Employee Onboarding Form",
            fields: [
              { name: "fullName", label: "Full Name", type: "text", placeholder: "Enter full name" },
              { name: "email", label: "Work Email", type: "email", placeholder: "name@janatics.com" },
              { name: "department", label: "Department", type: "select", options: ["Engineering", "HR", "Finance", "Operations", "Marketing"] },
              { name: "role", label: "Job Title", type: "text", placeholder: "e.g. Senior Developer" },
              { name: "startDate", label: "Start Date", type: "date" },
              { name: "manager", label: "Reporting Manager", type: "text", placeholder: "Manager's name" }
            ],
            submitLabel: "Submit Onboarding Request"
          }}
        ]
      }
    ]
  },
  finance: {
    portalId: "finance",
    portalName: "Finance Portal",
    portalIcon: "💰",
    portalColor: "#10B981",
    layout: "top-nav",
    navigation: [
      { id: "dashboard", label: "Overview", icon: "📊", page: "dashboard" },
      { id: "transactions", label: "Transactions", icon: "💳", page: "grid" },
      { id: "budget", label: "Budget Entry", icon: "📝", page: "form" },
      { id: "reports", label: "Reports", icon: "📈", page: "dashboard" }
    ],
    pages: [
      {
        pageId: "dashboard", pageTitle: "Finance Overview",
        components: [
          { type: "widget", id: "w1", props: { label: "Total Revenue", value: "₹4.2 Cr", trend: "+18%", color: "#10B981", icon: "💹" } },
          { type: "widget", id: "w2", props: { label: "Total Expenses", value: "₹2.8 Cr", trend: "+6%", color: "#EF4444", icon: "📉" } },
          { type: "widget", id: "w3", props: { label: "Net Profit", value: "₹1.4 Cr", trend: "+32%", color: "#6366F1", icon: "🏦" } },
          { type: "widget", id: "w4", props: { label: "Pending Invoices", value: "47", trend: "-12", color: "#F59E0B", icon: "🧾" } },
          { type: "card", id: "c1", props: { title: "Q2 Summary", content: "Revenue exceeded targets by 18%. Cost optimization drive saved ₹22L. Board review scheduled for July 10." } },
          { type: "card", id: "c2", props: { title: "Budget Alerts", content: "R&D budget at 87% utilization. Marketing overspend flagged — ₹3.2L above allocation. IT renewal due next quarter." } }
        ]
      },
      {
        pageId: "grid", pageTitle: "Transaction Ledger",
        components: [
          { type: "grid", id: "g1", props: {
            title: "Recent Transactions",
            columns: ["Date", "Description", "Category", "Amount", "Status"],
            rows: [
              ["2026-06-01", "Vendor Payment - Infosys", "Operations", "₹4,50,000", "Completed"],
              ["2026-06-02", "Raw Material Purchase", "Manufacturing", "₹12,30,000", "Completed"],
              ["2026-06-03", "Employee Salaries", "Payroll", "₹38,50,000", "Completed"],
              ["2026-06-04", "Office Rent - Coimbatore HQ", "Facilities", "₹2,20,000", "Completed"],
              ["2026-06-05", "Software Licenses", "IT", "₹85,000", "Pending"],
              ["2026-06-06", "Client Invoice #1042", "Revenue", "₹18,00,000", "Received"],
              ["2026-06-07", "Marketing Campaign", "Marketing", "₹3,40,000", "Pending"],
              ["2026-06-08", "Equipment Maintenance", "Maintenance", "₹1,15,000", "Completed"]
            ]
          }}
        ]
      },
      {
        pageId: "form", pageTitle: "Budget Entry",
        components: [
          { type: "form", id: "f1", props: {
            title: "New Budget Entry",
            fields: [
              { name: "department", label: "Department", type: "select", options: ["Engineering", "HR", "Finance", "Operations", "Marketing", "IT"] },
              { name: "category", label: "Expense Category", type: "text", placeholder: "e.g. Software Licenses" },
              { name: "amount", label: "Amount (₹)", type: "number", placeholder: "0.00" },
              { name: "fiscalYear", label: "Fiscal Year", type: "select", options: ["FY 2025-26", "FY 2026-27"] },
              { name: "quarter", label: "Quarter", type: "select", options: ["Q1 (Apr-Jun)", "Q2 (Jul-Sep)", "Q3 (Oct-Dec)", "Q4 (Jan-Mar)"] },
              { name: "notes", label: "Notes", type: "text", placeholder: "Justification or additional notes" }
            ],
            submitLabel: "Submit Budget Entry"
          }}
        ]
      }
    ]
  },
  admin: {
    portalId: "admin",
    portalName: "Admin Console",
    portalIcon: "⚙️",
    portalColor: "#EF4444",
    layout: "sidebar-header",
    navigation: [
      { id: "dashboard", label: "System Overview", icon: "🖥️", page: "dashboard" },
      { id: "users", label: "User Management", icon: "👤", page: "grid" },
      { id: "config", label: "Configuration", icon: "⚙️", page: "form" },
      { id: "logs", label: "Audit Logs", icon: "📋", page: "grid" }
    ],
    pages: [
      {
        pageId: "dashboard", pageTitle: "System Overview",
        components: [
          { type: "widget", id: "w1", props: { label: "Active Users", value: "312", trend: "+7", color: "#EF4444", icon: "🟢" } },
          { type: "widget", id: "w2", props: { label: "Portals Deployed", value: "8", trend: "+1", color: "#6366F1", icon: "🚀" } },
          { type: "widget", id: "w3", props: { label: "API Requests / hr", value: "14.3K", trend: "+22%", color: "#F59E0B", icon: "⚡" } },
          { type: "widget", id: "w4", props: { label: "System Uptime", value: "99.98%", trend: "stable", color: "#10B981", icon: "💪" } },
          { type: "card", id: "c1", props: { title: "System Health", content: "All services operational. Last deployment: June 8, 2026. Next scheduled maintenance window: June 20." } },
          { type: "card", id: "c2", props: { title: "Security Alerts", content: "2 failed login attempts detected. SSL certificates valid for 87 days. MFA enforcement active for all admin accounts." } }
        ]
      },
      {
        pageId: "grid", pageTitle: "User Management",
        components: [
          { type: "grid", id: "g1", props: {
            title: "System Users",
            columns: ["Username", "Email", "Role", "Last Login", "Status"],
            rows: [
              ["arun.kumar", "arun.kumar@janatics.com", "Admin", "2026-06-09 09:12", "Active"],
              ["priya.sharma", "priya.sharma@janatics.com", "HR Manager", "2026-06-09 08:55", "Active"],
              ["ravi.chandran", "ravi.chandran@janatics.com", "Finance Analyst", "2026-06-08 17:30", "Active"],
              ["meena.nair", "meena.nair@janatics.com", "Ops Lead", "2026-06-07 14:20", "Inactive"],
              ["suresh.babu", "suresh.babu@janatics.com", "Developer", "2026-06-09 10:01", "Active"],
              ["vijay.raj", "vijay.raj@janatics.com", "DevOps", "2026-06-09 07:45", "Active"]
            ]
          }}
        ]
      },
      {
        pageId: "form", pageTitle: "System Configuration",
        components: [
          { type: "form", id: "f1", props: {
            title: "Portal Configuration",
            fields: [
              { name: "portalName", label: "Portal Display Name", type: "text", placeholder: "e.g. Janatics HR Portal" },
              { name: "environment", label: "Environment", type: "select", options: ["Development", "Staging", "Production"] },
              { name: "sessionTimeout", label: "Session Timeout (minutes)", type: "number", placeholder: "30" },
              { name: "mfaEnabled", label: "MFA Requirement", type: "select", options: ["Enabled for All", "Admins Only", "Disabled"] },
              { name: "logLevel", label: "Log Level", type: "select", options: ["ERROR", "WARN", "INFO", "DEBUG"] },
              { name: "maintenanceNote", label: "Maintenance Message", type: "text", placeholder: "Displayed during maintenance windows" }
            ],
            submitLabel: "Save Configuration"
          }}
        ]
      }
    ]
  }
};

// ---- LocalStorage helpers ----
const Storage = {
  KEY: 'janatics_portals',
  load() {
    try {
      const raw = localStorage.getItem(this.KEY);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  },
  save(portals) {
    try { localStorage.setItem(this.KEY, JSON.stringify(portals)); } catch {}
  },
  getAll() {
    const saved = this.load();
    if (!saved) {
      this.save({ ...window.BUILTIN_PORTALS });
      return { ...window.BUILTIN_PORTALS };
    }
    return saved;
  },
  get(id) { return this.getAll()[id] || null; },
  set(portal) {
    const all = this.getAll();
    all[portal.portalId] = portal;
    this.save(all);
  },
  delete(id) {
    const all = this.getAll();
    delete all[id];
    this.save(all);
  }
};

// ---- Toast ----
function showToast(msg, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span> ${msg}`;
  container.appendChild(toast);
  requestAnimationFrame(() => {
    requestAnimationFrame(() => toast.classList.add('show'));
  });
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ---- Component Registry ----
const ComponentRegistry = {
  // Runtime renderers
  renderWidget(comp) {
    return `<div class="runtime-widget">
      <div class="runtime-widget-top">
        <span class="runtime-widget-label">${comp.props.label}</span>
        <div class="runtime-widget-icon" style="background:${comp.props.color}22">${comp.props.icon}</div>
      </div>
      <div class="runtime-widget-value" style="color:${comp.props.color}">${comp.props.value}</div>
      <div class="runtime-widget-trend ${comp.props.trend.startsWith('-') ? 'down' : ''}">${comp.props.trend} from last period</div>
    </div>`;
  },
  renderCard(comp) {
    return `<div class="runtime-card">
      <div class="runtime-card-title">${comp.props.title}</div>
      <div class="runtime-card-content">${comp.props.content}</div>
    </div>`;
  },
  renderGrid(comp) {
    const cols = comp.props.columns.map(c => `<th>${c}</th>`).join('');
    const rows = comp.props.rows.map(row => {
      const cells = row.map((cell, i) => {
        if (i === row.length - 1) {
          const slug = cell.toLowerCase().replace(/\s+/g, '-');
          const cls = `status-${slug}`;
          return `<td><span class="status-badge ${cls}">${cell}</span></td>`;
        }
        return `<td>${cell}</td>`;
      }).join('');
      return `<tr>${cells}</tr>`;
    }).join('');
    return `<div class="runtime-grid-wrap">
      <div class="runtime-grid-header">
        <span class="runtime-grid-title">${comp.props.title}</span>
        <span class="runtime-grid-count">${comp.props.rows.length} records</span>
      </div>
      <table class="runtime-table"><thead><tr>${cols}</tr></thead><tbody>${rows}</tbody></table>
    </div>`;
  },
  renderForm(comp) {
    const fields = comp.props.fields.map(f => {
      let input = '';
      if (f.type === 'select') {
        const opts = (f.options || []).map(o => `<option>${o}</option>`).join('');
        input = `<select id="field-${f.name}"><option value="">Select…</option>${opts}</select>`;
      } else {
        input = `<input type="${f.type}" id="field-${f.name}" placeholder="${f.placeholder || ''}">`;
      }
      return `<div class="runtime-form-field"><label for="field-${f.name}">${f.label}</label>${input}</div>`;
    }).join('');
    return `<div class="runtime-form-wrap">
      <div class="runtime-form-header"><div class="runtime-form-title">${comp.props.title}</div></div>
      <div class="runtime-form-body">
        <div class="runtime-form-grid">${fields}</div>
      </div>
      <div class="runtime-form-actions">
        <button class="runtime-form-submit" onclick="handleFormSubmit(this)">${comp.props.submitLabel}</button>
        <button class="runtime-form-cancel" onclick="handleFormReset(this)">Reset</button>
      </div>
    </div>`;
  },
  renderButton(comp) {
    return `<button class="btn-primary">${comp.props.label || 'Button'}</button>`;
  },
  renderText(comp) {
    return `<p style="color:var(--navy-700);font-size:14px;line-height:1.6">${comp.props.content || 'Text content'}</p>`;
  },

  // Render a component for runtime
  render(comp) {
    switch (comp.type) {
      case 'widget': return this.renderWidget(comp);
      case 'card': return this.renderCard(comp);
      case 'grid': return this.renderGrid(comp);
      case 'form': return this.renderForm(comp);
      case 'button': return this.renderButton(comp);
      case 'text': return this.renderText(comp);
      default: return `<div style="padding:16px;background:#f1f5f9;border-radius:8px;color:#64748b">Unknown component: ${comp.type}</div>`;
    }
  },

  // Studio preview renderers (compact)
  previewWidget(comp) {
    const p = comp.props;
    return `<div class="preview-widgets"><div class="preview-widget">
      <div class="preview-widget-label">${p.label || 'Widget'}</div>
      <div class="preview-widget-value" style="color:${p.color||'#6366F1'}">${p.value || '—'}</div>
      <div class="preview-widget-trend">${p.trend || ''}</div>
    </div></div>`;
  },
  previewCard(comp) {
    const p = comp.props;
    return `<div class="preview-card">
      <div class="preview-card-title">${p.title || 'Card'}</div>
      <div class="preview-card-content">${p.content || ''}</div>
    </div>`;
  },
  previewGrid(comp) {
    const p = comp.props;
    const cols = (p.columns || ['Col 1', 'Col 2', 'Col 3']).map(c => `<th>${c}</th>`).join('');
    const rows = (p.rows || []).slice(0, 3).map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('');
    return `<div>
      <div class="preview-grid-title">${p.title || 'Grid'}</div>
      <table class="preview-grid-table">
        <thead><tr>${cols}</tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>`;
  },
  previewForm(comp) {
    const p = comp.props;
    const fields = (p.fields || []).slice(0, 4).map(f =>
      `<div class="preview-form-field"><label>${f.label}</label><input type="${f.type}" placeholder="${f.placeholder || ''}" disabled></div>`
    ).join('');
    return `<div>
      <div class="preview-form-title">${p.title || 'Form'}</div>
      <div class="preview-form-fields">${fields}</div>
    </div>`;
  },
  preview(comp) {
    switch (comp.type) {
      case 'widget': return this.previewWidget(comp);
      case 'card': return this.previewCard(comp);
      case 'grid': return this.previewGrid(comp);
      case 'form': return this.previewForm(comp);
      default: return `<div style="padding:8px;color:#94a3b8;font-size:12px">${comp.type} component</div>`;
    }
  }
};

// ---- Runtime form handlers (global) ----
function handleFormSubmit(btn) {
  const wrap = btn.closest('.runtime-form-wrap');
  const inputs = wrap.querySelectorAll('input, select');
  const data = {};
  inputs.forEach(inp => { data[inp.id] = inp.value; });
  showToast('Form submitted successfully!', 'success');
  inputs.forEach(inp => inp.value = '');
}
function handleFormReset(btn) {
  const wrap = btn.closest('.runtime-form-wrap');
  wrap.querySelectorAll('input, select').forEach(inp => inp.value = '');
  showToast('Form cleared', 'info');
}

// ---- Page render for runtime ----
function renderPage(page, container) {
  if (!page || !container) return;
  container.innerHTML = '';

  const header = document.createElement('div');
  header.className = 'runtime-page-header';
  header.innerHTML = `<div class="runtime-page-title">${page.pageTitle}</div>
    <div class="runtime-page-breadcrumb">Portal › ${page.pageTitle}</div>`;
  container.appendChild(header);

  const widgets = page.components.filter(c => c.type === 'widget');
  const cards   = page.components.filter(c => c.type === 'card');
  const others  = page.components.filter(c => !['widget','card'].includes(c.type));

  if (widgets.length) {
    const div = document.createElement('div');
    div.className = 'runtime-widgets';
    div.innerHTML = widgets.map(c => ComponentRegistry.render(c)).join('');
    container.appendChild(div);
  }
  if (cards.length) {
    const div = document.createElement('div');
    div.className = 'runtime-cards';
    div.innerHTML = cards.map(c => ComponentRegistry.render(c)).join('');
    container.appendChild(div);
  }
  others.forEach(c => {
    const div = document.createElement('div');
    div.innerHTML = ComponentRegistry.render(c);
    container.appendChild(div);
  });
}

window.Storage = Storage;
window.ComponentRegistry = ComponentRegistry;
window.showToast = showToast;
window.renderPage = renderPage;
