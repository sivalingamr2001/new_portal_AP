import Logo from "@/assets/jana.png"
import { useAuth } from "@/context/AuthContext"
import { useState, useEffect } from "react"

export default Logo

export const ENV_CONFIG = {
  BASE_API_URL: import.meta.env.VITE_BASE_API_URL || "/api",
}

export function useDebounce<T>(value: T, delay?: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value)

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay || 500)
    return () => clearTimeout(timer)
  }, [value, delay])

  return debouncedValue
}

export const getInitials = (name: string) => {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
}

export const currentUserId = () => {
  const { currentUser } = useAuth()
  try {
    const userId = currentUser?.user?.id
    if (userId) {
      return userId ?? null
    }
  } catch (e) {
    console.error("Failed to extract current user ID from session storage", e)
  }
  return null
}
