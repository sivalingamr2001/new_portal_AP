import type { LucideIcon } from "lucide-react"
import type { UserRoleType } from "@/components/common/RoleGuard"
import {
  FileText,
  CheckSquare,
  LayoutDashboard,
  ShieldCheck,
  Users,
  Building2,
  FolderTree,
} from "lucide-react"

export interface SidebarGroupItem {
  label: string
  desc?: string
  to: string
  icon: LucideIcon
  roles: UserRoleType[]
}

export interface SidebarGroup {
  title: string
  items: SidebarGroupItem[]
}

export const sidebarItems: SidebarGroup[] = [
  {
    title: "User",
    items: [
      {
        label: "My Requests",
        desc: "View and manage your access requests",
        to: "/my-requests",
        icon: FileText,
        roles: ["User"],
      },
    ],
  },
  {
    title: "HOD",
    items: [
      {
        label: "Pending Approvals",
        desc: "Review and approve pending access requests",
        to: "/hod/pending-approvals",
        icon: CheckSquare,
        roles: ["HOD"],
      },
      {
        label: "All Requests",
        to: "/hod/all-requests",
        icon: FileText,
        roles: ["HOD"],
      },
    ],
  },
  {
    title: "Operator",
    items: [
      {
        label: "Dashboard",
        to: "/operator/dashboard",
        icon: LayoutDashboard,
        roles: ["Operator"],
      },
      {
        label: "Approval Queue",
        to: "/operator/approval-queue",
        icon: ShieldCheck,
        roles: ["Operator"],
      },
      {
        label: "All Requests",
        to: "/operator/all-requests",
        icon: FileText,
        roles: ["Operator"],
      },
    ],
  },
  {
    title: "Admin",
    items: [
      {
        label: "Dashboard",
        to: "/dashboard",
        icon: LayoutDashboard,
        roles: ["Admin"],
      },
      {
        label: "Users",
        to: "/users",
        icon: Users,
        roles: ["Admin"],
      },
      {
        label: "Departments",
        to: "/departments",
        icon: Building2,
        roles: ["Admin"],
      },
      {
        label: "Folder Mapping",
        to: "/folder-mapping",
        icon: FolderTree,
        roles: ["Admin"],
      },
      {
        label: "Audit Logs",
        to: "/admin/audit-logs",
        icon: FileText,
        roles: ["Admin"],
      },
    ],
  },
]
