import { useAuth } from "@/context/AuthContext"
import { Navigate, type RouteObject } from "react-router-dom"

import AppLayout from "@/layout/AppLayout"
import { AuthLayout } from "@/layout/AuthLayout"
import ErrorBountry from "@/pages/common/ErrorBountry"
import { ProtectedRoute } from "@/pages/common/ProtectedRoute"

// 1. Fixed Imports: Import BOTH the component and its type definition safely
import { RoleGuard, type UserRoleType } from '@/components/common/RoleGuard'

import * as Pages from "./pages"
import { withSuspense } from "./withSuspense"

const HomeRedirect = () => {
  const { currentUserRole, isAuthenticated } = useAuth()

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  // 2. Fixed evaluation: Directly evaluate the string values coming from your backend payload
  switch (currentUserRole as UserRoleType) {
    case "Admin":
      return <Navigate to="/dashboard" replace />
    case "Operator":
      return <Navigate to="/operator/dashboard" replace />
    case "HOD":
      return <Navigate to="/hod/pending-approvals" replace />
    case "User":
      return <Navigate to="/my-requests" replace />
    default:
      return <Navigate to="/unauthorized" replace />
  }
}

export const routesConfig: RouteObject[] = [
  {
    element: <ProtectedRoute />,
    errorElement: <ErrorBountry />,
    children: [
      {
        element: <AppLayout />,
        errorElement: <ErrorBountry />,
        children: [
          { index: true, element: <HomeRedirect /> },
          {
            path: "/unauthorized",
            element: withSuspense(Pages.UnauthorizedPage),
          },
          {
            path: "/profile",
            element: withSuspense(Pages.UserProfilePage),
          },

          // --- USER PATHS ---
          {
            element: <RoleGuard allowedRoles={["User"]} />,
            children: [
              {
                path: "/my-requests",
                element: withSuspense(Pages.MyRequestsPage),
              },
            ],
          },

          // --- HOD PATHS ---
          {
            element: <RoleGuard allowedRoles={["HOD"]} />,
            children: [
              {
                path: "/hod/pending-approvals",
                element: withSuspense(Pages.HodApprovalsPage),
              },
            ],
          },

          // --- OPERATOR PATHS ---
          {
            element: <RoleGuard allowedRoles={["Operator"]} />,
            children: [
              {
                path: "/operator/pending-approvals",
                element: withSuspense(Pages.OperatorApprovalsPage),
              },
            ],
          },

          // --- ADMIN PATHS ---
          {
            element: <RoleGuard allowedRoles={["Admin"]} />,
            children: [
              {
                path: "/dashboard",
                element: withSuspense(Pages.DashboardPage),
              },
              { path: "/users", element: withSuspense(Pages.UsersPage) },
              {
                path: "/departments",
                element: withSuspense(Pages.DepartmentsPage),
              },
              {
                path: "/folder-mapping",
                element: withSuspense(Pages.FolderMappingPage),
              },
              {
                path: "/admin/audit-logs",
                element: withSuspense(Pages.AuditLogsPage),
              },
            ],
          },
        ],
      },
    ],
  },
  {
    element: <AuthLayout />,
    children: [
      { index: true, element: <Navigate to="/login" replace /> },
      { path: "/login", element: withSuspense(Pages.LoginPage) },
    ],
  },
]
