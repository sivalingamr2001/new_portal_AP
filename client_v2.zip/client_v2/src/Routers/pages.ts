import { lazy } from "react"

// Common
export const RootRedirect = lazy(() =>
  import("@/pages/common/RootRedirect").then((m) => ({
    default: m.RootRedirect,
  }))
)

export const UserProfilePage = lazy(() =>
  import("@/pages/common/UserProfilePage").then((m) => ({
    default: m.UserProfilePage,
  }))
)

// Auth
export const LoginPage = lazy(() =>
  import("@/pages/Auth/LoginPage").then((m) => ({ default: m.LoginPage }))
)

// Admin Group
export const DashboardPage = lazy(() =>
  import("@/pages/Admin/Dashboard").then((m) => ({ default: m.Dashboard }))
)

export const UsersPage = lazy(() =>
  import("@/pages/Admin/UsersPage").then((m) => ({ default: m.UsersPage }))
)

export const FolderMappingPage = lazy(() =>
  import("@/pages/Admin/FolderMappingPage").then((m) => ({
    default: m.FolderMappingPage,
  }))
)

export const DepartmentsPage = lazy(() =>
  import("@/pages/Admin/DepartmentsPage").then((m) => ({
    default: m.DepartmentsPage,
  }))
)

export const AuditLogsPage = lazy(() =>
  import("@/pages/common/AuditLogsPage").then((m) => ({ default: m.AuditLogsPage }))
)

// Operator
export const OperatorApprovalsPage = lazy(() =>
  import("@/pages/Operator/OperatorApprovalsPage").then((m) => ({
    default: m.OperatorApprovalsPage,
  }))
)

// Hod
export const HodApprovalsPage = lazy(() =>
  import("@/pages/Hod/HodApprovalsPage").then((m) => ({
    default: m.HodApprovalsPage,
  }))
)

// Users
export const MyRequestsPage = lazy(() =>
  import("@/pages/Users/MyRequestsPage").then((m) => ({
    default: m.MyRequestsPage,
  }))
)

// export const HodApprovalsPage = () => {

// }

// Fallback Utilities
export const UnauthorizedPage = lazy(() =>
  import("@/pages/common/UnauthorizedPage").then((m) => ({
    default: m.UnauthorizedPage,
  }))
)
