import React, { Suspense } from "react"
import { Loader } from "@/components/common/Loader"

export const withSuspense = (Component: React.ComponentType) => (
  <Suspense fallback={<Loader />}>
    <Component />
  </Suspense>
)
