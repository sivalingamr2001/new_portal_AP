import { notificationsApi } from "@/api"
import type { NotificationDto } from "@/api/types"
import { NotificationSheet } from "@/components/common/NotificationSheet"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetTrigger } from "@/components/ui/sheet"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { useAuth } from "@/context/AuthContext"
import { Bell, LogOut, User } from "lucide-react"
import { useEffect, useState, useCallback } from "react"
import { useNavigate } from "react-router-dom"

export function AppHeader() {
  const { currentUser, logout } = useAuth()
  const navigate = useNavigate()

  const [notifications, setNotifications] = useState<NotificationDto[]>([])
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const [isError, setIsError] = useState<boolean>(false)

  const userId = currentUser?.user?.id || 0

  // 1. Fetch historical background notifications array on mount / user switch
  useEffect(() => {
    const fetchNotifications = async () => {
      // Guard prevents sending empty header values down to API controllers during initialization
      if (!userId || userId === 0) {
        setIsLoading(false)
        return
      }
      try {
        setIsLoading(true)
        setIsError(false)
        const data = await notificationsApi.getNotifications()
        setNotifications(data || [])
      } catch (error) {
        console.error("Failed to fetch notifications:", error)
        setIsError(true)
      } finally {
        setIsLoading(false)
      }
    }

    fetchNotifications()
  }, [userId])

  // 2. Optimized Single Item Mutation Callback Hook
  const handleMarkAsRead = useCallback(async (targetId: number) => {
    // Optimistic UI state update targeting primary ID key
    setNotifications((prev) =>
      prev.map((n) => (n.auditId === targetId ? { ...n, isRead: true } : n))
    )

    try {
      await notificationsApi.markRead(targetId)
    } catch (error) {
      console.error(`Failed to execute read sequence for record ${targetId}:`, error)
      // Rollback synchronization on failure event logs
      setNotifications((prev) =>
        prev.map((n) => (n.auditId === targetId ? { ...n, isRead: false } : n))
      )
    }
  }, [])

  // 3. Optimized Global Bulk State Mutation Hook
  const handleMarkAllAsRead = useCallback(async () => {
    const backupSnapshotState = [...notifications]
    
    // Optimistically make everything read immediately
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })))

    try {
      await notificationsApi.markAllRead()
    } catch (error) {
      console.error("Bulk updates rejected by destination server layers:", error)
      // Revert back to backup snapshot if backend request fails
      setNotifications(backupSnapshotState)
    }
  }, [notifications])

  const hasUnread = notifications.some((n) => !n.isRead)
  const userName = currentUser?.user?.name || "User Name"
  const userEmail = currentUser?.user?.email || "N/A"

  const handleLogout = () => {
    logout()
    navigate("/login")
  }

  return (
    <header className="flex h-16 w-full shrink-0 items-center justify-between border-b bg-background px-4">
      <div className="flex items-center gap-3">
        <SidebarTrigger className="h-9 w-9" />
        <div className="h-5 w-px bg-border" />
        <div className="flex items-center gap-3">
          <span className="hidden text-xs font-medium text-muted-foreground sm:inline-block">
            Access Portal
          </span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="relative h-9 w-9 text-muted-foreground hover:text-foreground"
            >
              <Bell className="h-5 w-5" />
              {hasUnread && (
                <span className="absolute top-2.5 right-2.5 h-2 w-2 rounded-full bg-destructive animate-pulse" />
              )}
            </Button>
          </SheetTrigger>

          <NotificationSheet
            notifications={notifications}
            isLoading={isLoading}
            isError={isError}
            onMarkAsRead={handleMarkAsRead}
            onMarkAllRead={handleMarkAllAsRead}
          />
        </Sheet>

        <div className="h-5 w-px bg-border" />

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              className="flex h-auto items-center gap-3 rounded-lg p-1 transition-colors hover:bg-accent/50"
            >
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border bg-accent text-accent-foreground">
                <User className="h-4 w-4" />
              </div>

              <div className="hidden flex-col text-left md:flex">
                <span className="text-sm leading-none font-semibold text-foreground">
                  {userName}
                </span>
                <span className="mt-1 text-xs leading-none font-normal text-muted-foreground">
                  {userEmail}
                </span>
              </div>
            </Button>
          </DropdownMenuTrigger>

          <DropdownMenuContent align="end" className="mt-1 w-56">
            <DropdownMenuLabel className="font-normal md:hidden">
              <div className="flex flex-col space-y-1">
                <p className="text-sm leading-none font-medium">{userName}</p>
                <p className="text-xs leading-none text-muted-foreground">{userEmail}</p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator className="md:hidden" />

            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />

            <DropdownMenuItem
              className="cursor-pointer gap-2"
              onClick={() => navigate("/profile")}
            >
              <User className="h-4 w-4 text-muted-foreground" />
              <span>Profile</span>
            </DropdownMenuItem>

            <DropdownMenuSeparator />

            <DropdownMenuItem
              onClick={handleLogout}
              className="cursor-pointer gap-2 text-destructive focus:bg-destructive/10 focus:text-destructive"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}

export default AppHeader
