import { useState, useEffect } from "react"

import { Button } from "@/components/ui/button"
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog"

import { useAuth } from "@/context/AuthContext"

import { AgreementCheckbox } from "./AgreementsSection"
import AccessDetailsSection, { type RequestItem } from "./AccessDetailsSection"
import { UserSection, type UserSectionValue } from "./UserSection"
import { toast } from "sonner"
import type { SubmitAccessRequestDto } from "@/api/types"
import { usersApi } from "@/api/usersApi"
// ✅ FIX: Imported the correct API module instance file
import { accessRequestsApi } from "@/api/accessRequestsApi"

type CreateRequestModalProps = {
    isOpen: boolean
    onOpenChange: (open: boolean) => void
}

export const CreateRequestModal = ({
    isOpen,
    onOpenChange,
}: CreateRequestModalProps) => {
    // ✅ FIX: Extracted currentUserRole to enforce role-based route targeting definitions
    const { currentUser, currentUserRole } = useAuth()
    const [isLoading, setIsLoading] = useState(false)
    const [requestItems, setRequestItems] = useState<RequestItem[]>([
        {
            id: 1,
            accessType: "not-applicable",
            folderPath: "",
            reason: "",
        },
    ])

    const [value, setValue] = useState({
        userId: currentUser?.user?.id ?? 0,
        employeeId: currentUser?.user?.employeeId ?? "",
        name: currentUser?.user?.name ?? "",
        email: currentUser?.user?.email ?? "",
        itsrNumber: "",
        departmentName: currentUser?.department?.name ?? "",
        hodName: currentUser?.headOfDepartment?.name ?? "",
        location: currentUser?.user?.location ?? "",
        mobile: currentUser?.user?.mobileNumber ? String(currentUser.user.mobileNumber) : "",
        agreementAccepted: false,
    })

    // ✅ FIX: Reset state structures completely on toggle interactions to clear old form inputs
    useEffect(() => {
        if (isOpen && currentUser) {
            setValue({
                userId: currentUser.user?.id ?? 0,
                employeeId: currentUser.user?.employeeId ?? "",
                name: currentUser.user?.name ?? "",
                email: currentUser.user?.email ?? "",
                itsrNumber: "",
                departmentName: currentUser.department?.name ?? "",
                hodName: currentUser.headOfDepartment?.name ?? "",
                location: currentUser.user?.location ?? "",
                mobile: currentUser.user?.mobileNumber ? String(currentUser.user.mobileNumber) : "",
                agreementAccepted: false,
            })
            setRequestItems([
                {
                    id: 1,
                    accessType: "not-applicable",
                    folderPath: "",
                    reason: "",
                },
            ])
        }
    }, [isOpen, currentUser])

    const updateValue = (
        field: keyof typeof value,
        fieldValue: string | number | boolean
    ) => {
        setValue((prev) => ({
            ...prev,
            [field]: fieldValue,
        }))
    }

    const handleUserChange = async (
        field: keyof UserSectionValue,
        fieldValue: string | number
    ) => {
        updateValue(field, fieldValue)

        if (!fieldValue) return

        try {
            const response = await usersApi.getPortalUser(Number(fieldValue))

            if (response && response.user) {
                const user = response
                setValue((prev) => ({
                    ...prev,
                    userId: user.user?.id ?? 0,
                    employeeId: user.user?.employeeId ?? "",
                    name: user.user?.name ?? "",
                    email: user.user?.email ?? "",
                    departmentName: user.department?.name ?? "",
                    hodName: user.headOfDepartment?.name ?? "",
                    location: user.user?.location ?? "",
                    mobile: user.user?.mobileNumber ? String(user.user?.mobileNumber) : "",
                }))
            }
        } catch (error) {
            console.error("Failed to fetch changed user details:", error)
        }
    }

    const normalizeAccessType = (value: string): "NotApplicable" | "ReadOnly" | "ReadandWrite" => {
        switch (value) {
            case "read-only":
                return "ReadOnly"
            case "read-write":
                return "ReadandWrite"
            default:
                return "NotApplicable"
        }
    }

    const handleCreate = async (e: React.FormEvent) => {
        e.preventDefault()
        setIsLoading(true)

        try {
            const payload: SubmitAccessRequestDto = {
                userId: value.userId,
                isAgreed: value.agreementAccepted,
                itsrNo: value.itsrNumber || null,
                items: requestItems.map((item) => ({
                    folderPath: item.folderPath,
                    accessType: normalizeAccessType(item.accessType),
                    confirmAccessType: normalizeAccessType(item.confirmAccessType ?? item.accessType),
                    reason: item.reason,
                })),
            }

            // ✅ FIX: Dynamically target specialized endpoints if user has an elevated structural HOD role
            const isHodSession = currentUserRole === "Hod" || currentUserRole === "HOD"
            const response = isHodSession
                ? await accessRequestsApi.submitHodRequest(payload)
                : await accessRequestsApi.submitRequest(payload)

            if (response) {
                toast.success("Access request submitted successfully!")
                onOpenChange(false)
            }
        } catch (error) {
            console.error("Submission failed:", error)
            toast.error("Failed to create request. Please try again.")
        } finally {
            setIsLoading(false)
        }
    }

    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-6xl">
                <DialogHeader>
                    <DialogTitle className="text-3xl font-semibold text-primary">
                        Create New Request
                    </DialogTitle>
                    <DialogDescription>
                        Enter the details for your new access request.
                    </DialogDescription>
                </DialogHeader>

                <form onSubmit={handleCreate} className="space-y-6">
                    <UserSection
                        value={value}
                        onChange={handleUserChange}
                    />

                    <AccessDetailsSection
                        items={requestItems}
                        onItemsChange={setRequestItems}
                    />

                    <AgreementCheckbox
                        checked={value.agreementAccepted}
                        onCheckedChange={(checked) =>
                            updateValue("agreementAccepted", !!checked)
                        }
                    />

                    <DialogFooter>
                        <Button type="submit" disabled={!value.agreementAccepted || isLoading}>
                            {isLoading ? "Submitting..." : "Create Request"}
                        </Button>
                        <Button variant="outline" type="button" onClick={() => onOpenChange(false)} disabled={isLoading}>
                            Close
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    )
}
