import type { NotificationDto } from '@/api/types';
import {
    SheetContent,
    SheetDescription,
    SheetHeader,
    SheetTitle,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Bell, Check, Circle, CheckCheck } from 'lucide-react';
import React from 'react';

interface NotificationSheetProps {
    notifications: NotificationDto[];
    isLoading: boolean;
    isError: boolean;
    onMarkAsRead: (id: number) => Promise<void>;
    onMarkAllRead: () => Promise<void>;
}

// 1. Configured custom relative date format helper string analyzer method
const formatNotificationTime = (dateString?: string): string => {
    if (!dateString) return 'Recent';
    try {
        const timestamp = new Date(dateString);
        const deltaSeconds = Math.floor((new Date().getTime() - timestamp.getTime()) / 1000);
        
        if (deltaSeconds < 60) return 'Just now';
        
        const deltaMinutes = Math.floor(deltaSeconds / 60);
        if (deltaMinutes < 60) return `${deltaMinutes}m ago`;
        
        const deltaHours = Math.floor(deltaMinutes / 60);
        if (deltaHours < 24) return `${deltaHours}h ago`;
        
        return timestamp.toLocaleDateString([], { month: 'short', day: 'numeric' });
    } catch {
        return 'Recent';
    }
};

export const NotificationSheet: React.FC<NotificationSheetProps> = React.memo(({ 
    notifications, 
    isLoading, 
    isError, 
    onMarkAsRead,
    onMarkAllRead
}) => {
    const unreadCount = notifications.filter(n => !n.isRead).length;

    return (
        <SheetContent side="right" className="w-100 sm:w-135 flex flex-col h-full">
            <SheetHeader className="pb-4 border-b">
                <div className="flex items-center justify-between gap-4">
                    <SheetTitle className="flex items-center gap-2">
                        <Bell className="h-5 w-5" />
                        Notifications
                        {unreadCount > 0 && (
                            <span className="bg-primary text-primary-foreground text-xs px-2 py-0.5 rounded-full">
                                {unreadCount} new
                            </span>
                        )}
                    </SheetTitle>
                    
                    {unreadCount > 0 && (
                        <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 text-xs text-muted-foreground hover:text-primary gap-1 px-2 transition-all"
                            onClick={onMarkAllRead}
                        >
                            <CheckCheck className="h-3.5 w-3.5" />
                            Mark all read
                        </Button>
                    )}
                </div>
                <SheetDescription>
                    Stay updated with your enterprise automation logs.
                </SheetDescription>
            </SheetHeader>

            {/* Content Display Grid Area */}
            <div className="flex-1 overflow-y-auto mt-4 space-y-3 pr-2">
                {isLoading && (
                    <div className="text-center py-12 text-sm text-muted-foreground animate-pulse">
                        Loading your notification matrix logs...
                    </div>
                )}

                {isError && (
                    <div className="text-center py-12 text-sm text-destructive bg-destructive/5 rounded-xl p-4 border border-destructive/10">
                        Failed to map server stream connection. Check connection status.
                    </div>
                )}

                {!isLoading && !isError && notifications.length === 0 && (
                    <div className="mt-6 flex flex-col items-center justify-center rounded-2xl border border-dashed border-border py-16 text-sm text-muted-foreground bg-muted/10">
                        <Bell className="h-8 w-8 text-muted-foreground/40 mb-3 stroke-[1.5]" />
                        No notification history mapped to this user session.
                    </div>
                )}

                {!isLoading && !isError && notifications.map((notification) => (
                    <div
                        // 2. Bound key assignment directly onto verified backend data identification id property
                        key={notification.auditId}
                        onClick={() => !notification.isRead && onMarkAsRead(notification.auditId)}
                        className={`flex items-start gap-3 p-4 rounded-xl border transition-all duration-200 cursor-pointer group ${
                            notification.isRead
                                ? 'bg-background hover:bg-accent/40 opacity-75 border-border'
                                : 'bg-accent/20 border-primary/20 hover:bg-accent/40 shadow-sm'
                        }`}
                    >
                        <div className="mt-1 shrink-0">
                            {notification.isRead ? (
                                <Check className="h-4 w-4 text-muted-foreground/60" />
                            ) : (
                                <Circle className="h-4 w-4 fill-primary text-primary animate-pulse" />
                            )}
                        </div>

                        <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between gap-3">
                                <p className={`text-sm font-medium ${notification.isRead ? 'text-foreground/80' : 'text-foreground'}`}>
                                    {notification.eventType || "Log Update"}
                                </p>
                                <span className="text-xs text-muted-foreground whitespace-nowrap font-medium">
                                    {/* 3. Replaced missing property with a dynamic custom timeline calculation */}
                                    {formatNotificationTime(notification.createdOn)}
                                </span>
                            </div>
                            <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
                                {notification.message}
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        </SheetContent>
    );
});

NotificationSheet.displayName = "NotificationSheet";
