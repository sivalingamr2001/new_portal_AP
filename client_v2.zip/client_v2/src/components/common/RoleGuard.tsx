import { useAuth } from "@/context/AuthContext";
import React from "react";
import { Navigate, Outlet } from "react-router-dom";

export type UserRoleType = 'Admin' | 'Operator' | 'HOD' | 'User';

interface RoleGuardProps {
  allowedRoles: UserRoleType[];
  children?: React.ReactNode;
}

export function RoleGuard({ allowedRoles, children }: RoleGuardProps) {
  const { isAuthenticated, currentUserRole } = useAuth();

  if (!isAuthenticated || !currentUserRole) {
    return <Navigate to="/login" replace />;
  }

  const activeRole = currentUserRole as UserRoleType;

  if (!allowedRoles.includes(activeRole)) {
    console.warn(
      `User with role '${activeRole}' does not have access. Allowed roles: ${allowedRoles.join(", ")}`
    );
    return <Navigate to="/unauthorized" replace />;
  }

  return children ? <>{children}</> : <Outlet />;
}

export default RoleGuard;
