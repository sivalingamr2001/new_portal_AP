import React, { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Field, FieldGroup, FieldLabel } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { useAuth } from "@/context/AuthContext"
import { useNavigate } from "react-router-dom"
import Logo from "@/lib/constants"
import { authApi } from "@/api"
import { useLoader } from "@/hooks/useLoader"
import { Loader } from "@/components/common/Loader"

export const LoginPage = () => {
  const { login } = useAuth()
  const navigate = useNavigate()
  const { withLoader, loading } = useLoader()

  const [identifier, setIdentifier] = useState("")
  const [password, setPassword] = useState("")
  const [errorMsg, setErrorMsg] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setErrorMsg(null)

    try {
      const values = {
        identifier,
        password,
      }

      const data = await withLoader(() => authApi.login(values))

      if (data) {
        login(data)

        navigate("/", { replace: true })
      }
    } catch (error: any) {
      console.error("Login failed:", error)
      setErrorMsg(error?.message || "Invalid credentials. Please try again.")
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen w-full items-center justify-center bg-muted/40 p-4 md:p-8">
        <div className="w-full max-w-sm md:max-w-md">
          <Loader />
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-xl">Welcome back</CardTitle>
          <div className="bg-muted p-4">
            <img src={Logo} alt="JANATICS" />
          </div>
          <CardDescription>
            Enter your credentials to access your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit}>
            <FieldGroup>
              {/* 5. Added conditional UI error message notice container */}
              {errorMsg && (
                <div className="text-sm font-medium text-destructive bg-destructive/10 p-2 rounded text-center">
                  {errorMsg}
                </div>
              )}
              <Field>
                <FieldLabel htmlFor="identifier">Username or Email</FieldLabel>
                <Input
                  id="identifier"
                  type="text"
                  placeholder="Username/Email"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  required
                />
              </Field>
              <Field>
                <div className="flex items-center">
                  <FieldLabel htmlFor="password">Password</FieldLabel>
                </div>
                <Input
                  id="password"
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </Field>
              <Field>
                <Button type="submit" disabled={loading} className="w-full">
                  {loading ? "Logging in..." : "Login"}
                </Button>
              </Field>
            </FieldGroup>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
