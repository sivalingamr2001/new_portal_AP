import { DataGrid } from "@/components/DynamicGrid/Index"
import type { DetailSectionConfig } from "@/components/DynamicGrid/types"
import { Button } from "@/components/ui/button"
import type { ColDef } from "ag-grid-community"
import { ChevronUp, TextQuote } from "lucide-react"
import { useCallback, useMemo, useState, useEffect } from "react"
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import { usersApi } from "@/api"
import { useLoader } from "@/hooks/useLoader"
import { useLocation } from "react-router-dom"
import { getTitleFromSidebar } from "@/lib/getTitleFromSidebar"
import { usePaginatedDataGrid } from "@/hooks/usePaginatedDataGrid"
import type { PortalUserDetails } from "@/api/types"
import { EditUsersModal } from "@/components/users/EditUsersModal"

const USERS_PAGE_CHUNK_SIZE = 20

export const UsersPage = () => {
  const location = useLocation()
  const [expandedRowIds, setExpandedRowIds] = useState<number[]>([])
  const { showLoader, hideLoader } = useLoader()
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState<PortalUserDetails | null>(null)

  // 1. Stabilized edit handler inside a useCallback hook to resolve memoization flashing
  const handleEditAction = useCallback((userData: PortalUserDetails) => {
    setSelectedUser(userData)
    setIsEditModalOpen(true)
  }, [])

  const { title } = useMemo(
    () => getTitleFromSidebar(location.pathname),
    [location.pathname]
  )

  const handleUsersError = useCallback(
    (error: Error) => {
      console.error("Failed to load user records:", error)
      hideLoader()
    },
    [hideLoader]
  )

  // 2. Bound fetch hook directly to the real endpoint model without looking for fake proxy properties
  const fetchUsersPage = useCallback(
    async (page: number, pageSize: number) => {
      const result = await usersApi.getPortalUsers({
        page,
        pageSize,
      })
      return result
    },
    []
  )

  const {
    rowData: users,
    totalPages,
    currentPage,
    loading,
    loadData,
    loadMore,
  } = usePaginatedDataGrid<PortalUserDetails>(
    fetchUsersPage,
    {
      pageSize: USERS_PAGE_CHUNK_SIZE,
      onError: handleUsersError,
    }
  )

  useEffect(() => {
    showLoader()
    loadData(1).finally(hideLoader)
  }, [hideLoader, loadData, showLoader])

  const toggleRowExpansion = useCallback((id: number) => {
    setExpandedRowIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    )
  }, [])

  // 3. Normalized expansion logic to safely use real user.id integers
  const computedRowData = useMemo(() => {
    const flatList: any[] = []
    users.forEach((row) => {
      if (!row.user) return
      flatList.push(row)
      if (expandedRowIds.includes(row.user.id)) {
        flatList.push({
          __isDetailRow: true,
          __parentData: row,
          user: { id: `detail_${row.user.id}` },
        })
      }
    })
    return flatList
  }, [users, expandedRowIds])

  // 4. Mapped section breakdown configuration parameters cleanly onto context structures
  const dynamicSectionsConfig = useMemo<DetailSectionConfig[]>(
    () => [
      { title: "Core User Profile Info", objectKey: "user" },
      { title: "Corporate Department Details", objectKey: "department" },
      { title: "Head Of Department Profile", objectKey: "headOfDepartment" },
    ],
    []
  )

  const columns = useMemo<(Omit<ColDef<any>, "field"> & { field?: string })[]>(
    () => [
      {
        headerName: "",
        width: 80,
        suppressMovable: true,
        filter: false,
        sortable: false,
        cellRenderer: (params: any) => {
          if (params.data?.__isDetailRow || !params.data?.user) return null
          const targetId = params.data.user.id
          const isExpanded = expandedRowIds.includes(targetId)

          return (
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 cursor-pointer font-bold text-slate-500 transition hover:text-indigo-600"
                  onClick={() => toggleRowExpansion(targetId)}
                >
                  {isExpanded ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <TextQuote className="h-4 w-4" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="top">
                {isExpanded ? "Collapse Details" : "Expand Details"}
              </TooltipContent>
            </Tooltip>
          )
        },
      },
      // ✅ FIX: Replaced 'field' keys with safe 'valueGetter' functions for nested properties
      {
        headerName: "User ID",
        valueGetter: (params) => params.data?.user?.id ?? ""
      },
      {
        headerName: "Employee ID",
        valueGetter: (params) => params.data?.user?.employeeId ?? ""
      },
      {
        headerName: "Username",
        valueGetter: (params) => params.data?.user?.name ?? ""
      },
      {
        headerName: "Email Address",
        valueGetter: (params) => params.data?.user?.email ?? ""
      },
      {
        headerName: "Mobile",
        valueGetter: (params) => params.data?.user?.mobileNumber ?? ""
      },
      {
        headerName: "Department ID",
        valueGetter: (params) => params.data?.user?.departmentId ?? ""
      },
      {
        headerName: "Actions",
        sortable: false,
        filter: false,
        cellRenderer: (params: any) => {
          if (!params.data || params.data.__isDetailRow) return null
          return (
            <div className="flex h-full items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                className="h-7 px-2 text-xs"
                onClick={() => handleEditAction(params.data)}
              >
                Edit
              </Button>
            </div>
          )
        },
        width: 100,
      },
    ],
    [handleEditAction, expandedRowIds, toggleRowExpansion]
  )

  const handleUserUpdate = async (updatedData: any) => {
    try {
      showLoader()
      if (!selectedUser?.user) return

      await usersApi.updatePortalUser(selectedUser.user.id, {
        cmplUserId: selectedUser.user.id,
        role: updatedData.role,
        location: updatedData.location,
      })

      await loadData(1)
    } catch (error) {
      console.error("Failed to update user:", error)
    } finally {
      hideLoader()
      setIsEditModalOpen(false)
    }
  }

  const globalCustomActions = useMemo(() => [], [])

  return (
    <div className="w-full space-y-4">
      <DataGrid
        title={title}
        rowData={computedRowData}
        rowSelection="none"
        columnDefs={columns}
        gridId="compliance_users_free_v35"
        pageSize={USERS_PAGE_CHUNK_SIZE}
        pageSizeOptions={[20, 50, 100]}
        loading={loading}
        showSearch={true}
        showRefreshButton={true}
        showClearFiltersButton={true}
        customActions={globalCustomActions}
        onRefresh={async () => {
          showLoader()
          try {
            await loadData(1)
          } finally {
            hideLoader()
          }
        }}
        theme="system"
        masterDetail={false}
        detailSections={dynamicSectionsConfig}
        gridHeight="550px"
        virtualScroll={{
          enabled: true,
          pageSize: USERS_PAGE_CHUNK_SIZE,
          bufferSize: 3,
          currentPage,
          totalPages,
          hasMore: currentPage < totalPages,
          onLoadMore: async (nextPage: number) => {
            await loadMore(nextPage)
          },
        }}
      />
      <EditUsersModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        userData={selectedUser}
        onSave={(updatedData) => {
          handleUserUpdate(updatedData)
        }}
      />
    </div>
  )
}
