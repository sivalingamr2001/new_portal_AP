
export const OperatorApprovalsPage = () => {
  return (
    <div>OperatorApprovalsPage</div>
  )
}
