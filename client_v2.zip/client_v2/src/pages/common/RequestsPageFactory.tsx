import { CreateRequestModal } from "@/components/AccessRequests/create-request-modal"
import { DataGrid } from "@/components/DynamicGrid/Index"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/context/AuthContext"
import { useLoader } from "@/hooks/useLoader"
import { getTitleFromSidebar } from "@/lib/getTitleFromSidebar"
import type { ColDef } from "ag-grid-community"
import { useCallback, useEffect, useMemo, useState } from "react"
import { useLocation, useNavigate } from "react-router-dom"

import type { PagedResult, PaginationParams } from "@/api/axiosClient"

// ==========================================
// 1. GENERIC BASE FACTORY COMPONENT
// ==========================================

interface RequestsPageFactoryProps {
    // ✅ FIX: Aligned signature to securely handle paginated arguments and generic pagination params
    fetchApiFn: (params?: PaginationParams & { id?: string }) => Promise<PagedResult<any>>
    actionButtonLabel?: string
    actionButtonRoutePrefix: string
    extraColumns?: (Omit<ColDef<any>, "field"> & { field?: string })[]
    showCreateButton?: boolean
}

export const RequestsPageFactory = ({
    fetchApiFn,
    actionButtonLabel = "View",
    actionButtonRoutePrefix,
    extraColumns = [],
    showCreateButton = false
}: RequestsPageFactoryProps) => {
    const location = useLocation()
    const { currentUser } = useAuth()
    const { loading, withLoader } = useLoader()
    
    // ✅ FIX: Bound state strictly onto the summary data model array
    const [requests, setRequests] = useState<any[]>([])
    const [createRequestModalOpen, setCreateRequestModalOpen] = useState(false)
    const [pagination, setPagination] = useState({ currentPage: 1, totalPages: 1 })
    const navigate = useNavigate()

    const { title } = useMemo(
        () => getTitleFromSidebar(location.pathname),
        [location.pathname]
    )

    // ✅ FIX: Added implicit page index loading mechanics
    const fetchRequests = useCallback(async (pageNumber = 1) => {
        const targetId = currentUser?.user?.id

        try {
            const result = await withLoader(() =>
                fetchApiFn({
                    page: pageNumber,
                    pageSize: 20,
                    id: targetId ? String(targetId) : undefined
                })
            )
            if (result) {
                // Safely update state containers from paginated wrapper layers
                setRequests(result.data || [])
                setPagination({
                    currentPage: result.page || 1,
                    totalPages: result.totalPages || 1
                })
            }
        } catch (error) {
            console.error("Error fetching requests:", error)
        }
    }, [currentUser, fetchApiFn, withLoader])

    useEffect(() => {
        fetchRequests(1)
    }, [fetchRequests])

    const handleActionClick = (data: any): void => {
        // ✅ FIX: Aligned path router tracking parameters to use requestId
        navigate(`${actionButtonRoutePrefix}/${data.requestId}`)
    }

    // ✅ FIX: Replaced status conversion integers with an un-nested, type-safe label translator lookup matrix
    const getStatusStylesAndText = (status: number | string) => {
        // Covers numeric enums or raw string statuses cleanly
        if (status === 1 || status === "Pending") {
            return { text: "Pending", wrapper: "bg-amber-50 text-amber-700 border-amber-200", indicator: "bg-amber-500" }
        }
        if (status === 2 || status === "Approved") {
            return { text: "Approved", wrapper: "bg-emerald-50 text-emerald-700 border-emerald-200", indicator: "bg-emerald-500" }
        }
        if (status === 3 || status === "Rejected") {
            return { text: "Rejected", wrapper: "bg-rose-50 text-rose-700 border-rose-200", indicator: "bg-rose-500" }
        }
        return { text: String(status), wrapper: "bg-slate-50 text-slate-700 border-slate-200", indicator: "bg-slate-400" }
    }

    const coreColumns = useMemo<(Omit<ColDef<any>, "field"> & { field?: string })[]>(
        () => [
            // ✅ FIX: Re-mapped field lookup cells to handle AccessRequestSummaryDto properties
            { headerName: "Request ID", field: "requestId", width: 120 },
            { 
                headerName: "ITSR Number", 
                field: "itsrNo", 
                width: 140,
                valueFormatter: (p) => p.value || "N/A"
            },
            ...extraColumns, // Dynamically injects User Info / Dept Info based on layout parameters
            { headerName: "Total Folders", field: "totalItems", width: 130 },
            { headerName: "Approved Folders", field: "approvedItems", width: 140 },
            { headerName: "Rejected Folders", field: "rejectedItems", width: 140 },
            {
                headerName: "Created Date",
                field: "createdOn",
                width: 150,
                valueFormatter: (p) => p.value ? new Date(p.value).toLocaleDateString() : "-"
            },
            {
                headerName: "Status", 
                field: "currentStatus", 
                width: 120,
                cellRenderer: (params: any) => {
                    if (params.value === undefined || params.value === null) return null;
                    const meta = getStatusStylesAndText(params.value)
                    
                    return (
                        <div className="flex h-full items-center">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${meta.wrapper}`}>
                                <span className={`w-1.5 h-1.5 mr-1.5 rounded-full ${meta.indicator}`} />
                                {meta.text}
                            </span>
                        </div>
                    );
                }
            },
            {
                headerName: "Actions",
                sortable: false,
                filter: false,
                width: 100,
                cellRenderer: (params: any) => {
                    if (!params.data) return null

                    return (
                        <div className="flex h-full items-center gap-2">
                            <Button
                                size="sm"
                                variant="outline"
                                className="h-7 px-3 text-xs font-medium shadow-sm transition-all hover:bg-secondary"
                                onClick={() => handleActionClick(params.data)}
                            >
                                {actionButtonLabel}
                            </Button>
                        </div>
                    )
                },
            },
        ],
        [extraColumns, actionButtonLabel, actionButtonRoutePrefix]
    )

    const customActions = useMemo(() => {
        if (!showCreateButton) return []
        return [
            {
                label: "Create New Request",
                onClick: () => setCreateRequestModalOpen(true),
            },
        ]
    }, [showCreateButton])

    return (
        <div className="space-y-4">
            <DataGrid
                rowData={requests}
                columnDefs={coreColumns}
                title={title}
                loading={loading}
                onRefresh={() => fetchRequests(1)}
                showRefreshButton
                showSearch
                showClearFiltersButton
                customActions={customActions}
                noRowsMessage="No access requests found"
                pageSize={20}
                rowSelection="none"
                virtualScroll={{
                    enabled: true,
                    pageSize: 20,
                    bufferSize: 2,
                    currentPage: pagination.currentPage,
                    totalPages: pagination.totalPages,
                    hasMore: pagination.currentPage < pagination.totalPages,
                    onLoadMore: async (nextPage: number) => {
                        await fetchRequests(nextPage)
                    }
                }}
            />

            {showCreateButton && (
                <CreateRequestModal
                    isOpen={createRequestModalOpen}
                    onOpenChange={setCreateRequestModalOpen}
                />
            )}
        </div>
    )
}
