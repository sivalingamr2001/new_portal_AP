import { useAuth } from "@/context/AuthContext"
import { Navigate } from "react-router-dom"

export const RootRedirect = () => {
  const { currentUserRole, isAuthenticated } = useAuth()

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  switch (currentUserRole) {
    case "Admin":
      return <Navigate to="/dashboard" replace />
    case "Operator": // Operator
      return <Navigate to="/operator/dashboard" replace />
    case "Hod":
      return <Navigate to="/hod/pending-approvals" replace />
    case "User":
      return <Navigate to="/my-requests" replace />
    default:
      return <Navigate to="/dashboard" replace />
  }
}
