
export const HodApprovalsPage = () => {
  return (
    <div>HodApprovalsPage</div>
  )
}
