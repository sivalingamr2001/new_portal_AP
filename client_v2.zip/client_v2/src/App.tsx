import { Router } from "./Routers"

export function App() {
  return <Router />
}

export default App
