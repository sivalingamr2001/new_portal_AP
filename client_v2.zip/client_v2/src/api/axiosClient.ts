import axios, {
  AxiosError,
  type AxiosInstance,
  type AxiosRequestConfig,
  type AxiosResponse,
  type InternalAxiosRequestConfig,
} from "axios"
import type { ApiError } from "./types"

export type { PagedResult, PaginationParams } from "./types"
import { ENV_CONFIG } from "@/lib/constants" // ✅ Removed broken currentUserId import

// ─── Custom API Error ─────────────────────────────────────────────────────────

export class ApiException extends Error {
  public readonly code: string
  public readonly type: ApiError["type"]
  public readonly httpStatus: number

  constructor(apiError: ApiError, httpStatus: number) {
    super(apiError.message)
    this.name = "ApiException"
    this.code = apiError.code
    this.type = apiError.type
    this.httpStatus = httpStatus
  }
}

// ─── ENV Config ───────────────────────────────────────────────────────────────

const BASE_URL =
  typeof ENV_CONFIG !== "undefined"
    ? ENV_CONFIG.BASE_API_URL
    : ((import.meta as unknown as { env: Record<string, string> }).env
        ?.VITE_API_BASE_URL ?? "/api")

const axiosInstance: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
  timeout: 15_000,
})

axiosInstance.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    try {
      const storageData = sessionStorage.getItem("jan_AP_user")

      if (storageData) {
        const parsedSession = JSON.parse(storageData)

        const userId = parsedSession.value.user.id ?? null

        if (userId !== undefined && userId !== null && userId !== "") {
          config.headers["X-User-Id"] = String(userId)
        }
      }
    } catch (e) {
      console.error(
        "Failed to extract X-User-Id header from session storage",
        e
      )
    }

    return config
  },
  (error: unknown) => Promise.reject(error)
)

axiosInstance.interceptors.response.use(
  (response: AxiosResponse) => response,
  (error: AxiosError<ApiError>) => {
    if (error.response) {
      const { data, status } = error.response

      if (
        data &&
        typeof data === "object" &&
        "code" in data &&
        "type" in data
      ) {
        return Promise.reject(new ApiException(data as ApiError, status))
      }

      return Promise.reject(
        new ApiException(
          {
            code: "UNKNOWN_ERROR",
            message: `Request failed with status ${status}`,
            type: "Failure",
          },
          status
        )
      )
    }

    if (error.request) {
      return Promise.reject(
        new ApiException(
          {
            code: "NETWORK_ERROR",
            message:
              "No response received from server. Check your network connection.",
            type: "Failure",
          },
          0
        )
      )
    }

    return Promise.reject(
      new ApiException(
        {
          code: "REQUEST_SETUP_ERROR",
          message: error.message ?? "An unexpected error occurred.",
          type: "Failure",
        },
        0
      )
    )
  }
)

// ─── Thin typed wrapper (mirrors Axios interface) ─────────────────────────────

export const apiService = {
  get: <T>(
    url: string,
    config?: AxiosRequestConfig
  ): Promise<AxiosResponse<T>> => axiosInstance.get<T>(url, config),

  post: <T>(
    url: string,
    data?: unknown,
    config?: AxiosRequestConfig
  ): Promise<AxiosResponse<T>> => axiosInstance.post<T>(url, data, config),

  put: <T>(
    url: string,
    data?: unknown,
    config?: AxiosRequestConfig
  ): Promise<AxiosResponse<T>> => axiosInstance.put<T>(url, data, config),

  patch: <T>(
    url: string,
    data?: unknown,
    config?: AxiosRequestConfig
  ): Promise<AxiosResponse<T>> => axiosInstance.patch<T>(url, data, config),

  delete: <T>(
    url: string,
    config?: AxiosRequestConfig
  ): Promise<AxiosResponse<T>> => axiosInstance.delete<T>(url, config),
}

export default axiosInstance
