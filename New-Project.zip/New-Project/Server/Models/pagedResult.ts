export interface PagedResult<T> {

}