import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Collapse,
  Card,
  Form,
  Row,
  Col,
  Select,
  Input,
  Button,
  DatePicker,
  Space,
  Tag,
  Alert,
  Divider,
  Typography,
  message
} from 'antd';
import { Plus, Trash2, Save, FileText, MapPin, Database, Sparkles } from 'lucide-react';
import {
  getRegions,
  getBillToCustomers,
  getShipToCustomers,
  getCustomerAddresses,
  getWeeksDropdown,
  getOperatingUnits,
  getDemandMetrics,
  getOrganizations,
  getItems,
  getRrsCategory,
  createAllocation
} from '../api/allocationApi';
import type {
  Region,
  Customer,
  CustomerAddress,
  OperatingUnit,
  Organization,
  InventoryItem
} from '../api/allocationApi';
import { useNotification } from '../context/NotificationContext';
import '../styles/Allocations.css';

const { Title, Text } = Typography;
const { Panel } = Collapse;

interface LineItemState {
  id: string;
  organizationId: number | null;
  inventoryItemId: number | null;
  itemCode: string;
  description: string;
  week: string;
  b3Quantity: number;
  targetDate: string;
  // Dynamic API metrics & validations
  oaPendingQuantity?: number;
  oaRsvQty?: number;
  oaPickedQty?: number;
  binQty?: number;
  binRsvQty?: number;
  rrsCategory?: string;
  rrsWarning?: boolean;
}

export default function Allocations() {
  const navigate = useNavigate();
  const { addNotification } = useNotification();
  const [form] = Form.useForm();

  // Dropdown options
  const [regions, setRegions] = useState<Region[]>([]);
  const [operatingUnits, setOperatingUnits] = useState<OperatingUnit[]>([]);
  const [billToCustomers, setBillToCustomers] = useState<Customer[]>([]);
  const [shipToCustomers, setShipToCustomers] = useState<Customer[]>([]);
  const [billToAddresses, setBillToAddresses] = useState<CustomerAddress[]>([]);
  const [shipToAddresses, setShipToAddresses] = useState<CustomerAddress[]>([]);
  
  // Shared line options
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [weeks, setWeeks] = useState<string[]>([]);

  // Selection states
  const [selectedRegion, setSelectedRegion] = useState<string>('');
  const [selectedSubRegion, setSelectedSubRegion] = useState<string>('');
  const [selectedOU, setSelectedOU] = useState<number | null>(null);
  const [selectedBillToCustomer, setSelectedBillToCustomer] = useState<number | null>(null);
  const [selectedShipToCustomer, setSelectedShipToCustomer] = useState<number | null>(null);

  // Address details displays
  const [billToAddressDetail, setBillToAddressDetail] = useState<string>('');
  const [shipToAddressDetail, setShipToAddressDetail] = useState<string>('');

  // Lines state
  const [lines, setLines] = useState<LineItemState[]>([
    { id: '1', organizationId: null, inventoryItemId: null, itemCode: '', description: '', week: '', b3Quantity: 0, targetDate: '' }
  ]);

  const [loading, setLoading] = useState(false);
  const [activePanel, setActivePanel] = useState<string | string[]>(['header']);

  // Fetch initial dropdowns
  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const [regionsData, ouData, orgData, itemsData, weeksData] = await Promise.all([
          getRegions(),
          getOperatingUnits(),
          getOrganizations(),
          getItems(1, 50),
          getWeeksDropdown()
        ]);
        setRegions(regionsData);
        setOperatingUnits(ouData);
        setOrganizations(orgData);
        setItems(itemsData.data);
        setWeeks(weeksData);
      } catch (err) {
        message.error('Failed to load form lookup data.');
      }
    };
    loadInitialData();
  }, []);

  // Compute unique regions list
  const uniqueRegions = useMemo(() => {
    return Array.from(new Set(regions.map(r => r.region)));
  }, [regions]);

  // Compute sub-regions matching the selected region
  const subRegions = useMemo(() => {
    if (!selectedRegion) return [];
    return regions.filter(r => r.region === selectedRegion).map(r => r.subRegion);
  }, [regions, selectedRegion]);

  // Fetch Customers when Region and Sub-Region are selected
  useEffect(() => {
    if (!selectedRegion || !selectedSubRegion) return;

    const loadRegionalData = async () => {
      try {
        const [billTo, shipTo] = await Promise.all([
          getBillToCustomers(selectedRegion, selectedSubRegion),
          getShipToCustomers(selectedRegion, selectedSubRegion)
        ]);
        setBillToCustomers(billTo);
        setShipToCustomers(shipTo);

        // Reset customer dependencies
        form.setFieldsValue({ billToCustomer: null, shipToCustomer: null });
        setSelectedBillToCustomer(null);
        setSelectedShipToCustomer(null);
        setBillToAddresses([]);
        setShipToAddresses([]);
        setBillToAddressDetail('');
        setShipToAddressDetail('');
      } catch (err) {
        message.error('Failed to fetch customers for selected region.');
      }
    };
    loadRegionalData();
  }, [selectedRegion, selectedSubRegion]);

  // Fetch Bill-to Addresses
  useEffect(() => {
    if (!selectedBillToCustomer || !selectedOU) return;
    const fetchBillToAddresses = async () => {
      try {
        const addrs = await getCustomerAddresses(selectedBillToCustomer, 'BILL_TO', selectedOU);
        setBillToAddresses(addrs);
        form.setFieldsValue({ billToLocation: null });
        setBillToAddressDetail('');
      } catch (err) {
        message.error('Failed to load bill-to locations.');
      }
    };
    fetchBillToAddresses();
  }, [selectedBillToCustomer, selectedOU]);

  // Fetch Ship-to Addresses
  useEffect(() => {
    if (!selectedShipToCustomer || !selectedOU) return;
    const fetchShipToAddresses = async () => {
      try {
        const addrs = await getCustomerAddresses(selectedShipToCustomer, 'SHIP_TO', selectedOU);
        setShipToAddresses(addrs);
        form.setFieldsValue({ shipToLocation: null });
        setShipToAddressDetail('');
      } catch (err) {
        message.error('Failed to load ship-to locations.');
      }
    };
    fetchShipToAddresses();
  }, [selectedShipToCustomer, selectedOU]);

  // Handle address location dropdown selection
  const handleBillToLocationSelect = (locName: string) => {
    const address = billToAddresses.find(a => a.location === locName);
    if (address) {
      setBillToAddressDetail(`${address.address1}, ${address.address2 || ''} ${address.address3 || ''}, ${address.city} - ${address.postalCode}`);
    }
  };

  const handleShipToLocationSelect = (locName: string) => {
    const address = shipToAddresses.find(a => a.location === locName);
    if (address) {
      setShipToAddressDetail(`${address.address1}, ${address.address2 || ''} ${address.address3 || ''}, ${address.city} - ${address.postalCode}`);
    }
  };

  // Add/Remove lines
  const addLineRow = () => {
    const newId = (lines.length + 1).toString();
    setLines([...lines, { id: newId, organizationId: null, inventoryItemId: null, itemCode: '', description: '', week: '', b3Quantity: 0, targetDate: '' }]);
  };

  const removeLineRow = (id: string) => {
    if (lines.length === 1) {
      message.warning('At least one line item is required.');
      return;
    }
    setLines(lines.filter(l => l.id !== id));
  };

  // Modify line property
  const updateLineRow = async (id: string, field: keyof LineItemState, value: any) => {
    const updated = await Promise.all(lines.map(async (line) => {
      if (line.id !== id) return line;

      const updatedLine = { ...line, [field]: value } as LineItemState;

      // Handle item auto-fills and metric fetches
      if (field === 'inventoryItemId') {
        const itemObj = items.find(i => i.inventoryItemId === value);
        if (itemObj) {
          updatedLine.itemCode = itemObj.itemCode;
          updatedLine.description = itemObj.description;
        }
      }

      // Check validations and demand metrics if item & org are selected
      if (
        (field === 'inventoryItemId' || field === 'organizationId') &&
        updatedLine.inventoryItemId &&
        updatedLine.organizationId
      ) {
        try {
          // 1. Check RRS Category
          const rrs = await getRrsCategory(updatedLine.organizationId, updatedLine.inventoryItemId);
          updatedLine.rrsCategory = rrs.rrsCategory;
          updatedLine.rrsWarning = rrs.rrsCategory === 'Rn';

          // 2. Fetch Demand Metrics
          if (selectedBillToCustomer) {
            const metrics = await getDemandMetrics(
              selectedBillToCustomer,
              updatedLine.organizationId,
              updatedLine.inventoryItemId
            );
            updatedLine.oaPendingQuantity = metrics.oaPendingQuantity;
            updatedLine.oaRsvQty = metrics.oaRsvQty;
            updatedLine.oaPickedQty = metrics.oaPickedQty;
            updatedLine.binQty = metrics.binQty;
            updatedLine.binRsvQty = metrics.binRsvQty;
          }
        } catch (err) {
          console.error('Failed to retrieve item metrics:', err);
        }
      }

      return updatedLine;
    }));

    setLines(updated);
  };

  // Submit allocation creation
  const handleSave = async () => {
    try {
      const headerValues = await form.validateFields();

      // Check if there are any lines
      if (lines.length === 0) {
        message.error('At least one line item is required.');
        return;
      }

      // Validate lines
      for (const line of lines) {
        if (!line.organizationId || !line.inventoryItemId || !line.week || line.b3Quantity <= 0 || !line.targetDate) {
          message.error('Please fill in all line item details and ensure quantity is positive.');
          return;
        }
        if (line.rrsWarning) {
          message.error(`Cannot save: Item ${line.itemCode} has a restricted RRS Category ("Rn").`);
          return;
        }
      }

      setLoading(true);

      const requestPayload = {
        transactionDate: new Date().toISOString().split('T')[0],
        customerOrItemSpecific: 1,
        customerId: selectedBillToCustomer,
        territoryId: null,
        billToCustomer: selectedBillToCustomer,
        shipToCustomer: selectedShipToCustomer,
        createdBy: 'Smith', // Default logged-in employee username
        remarks: headerValues.remarks,
        lines: lines.map(l => ({
          organizationId: l.organizationId,
          inventoryItemId: l.inventoryItemId!,
          b3Quantity: l.b3Quantity,
          targetDate: l.targetDate
        }))
      };

      const result = await createAllocation(requestPayload);
      addNotification(`Bin Allocation created successfully under Header ID: ${result.headerId}`, 'info');
      navigate('/');
    } catch (err) {
      console.error(err);
      message.error('Failed to create Bin Allocation. Check form errors.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fulfillment-container">
      <div className="fulfillment-header">
        <Space direction="vertical" size={2}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Sparkles size={24} style={{ color: 'var(--primary-color)' }} />
            <Title level={2} style={{ margin: 0, color: 'var(--text-primary)' }}>Create Bin Allocation</Title>
          </div>
          <Text type="secondary">Define header details and add line item quantities below</Text>
        </Space>
      </div>

      <Collapse
        activeKey={activePanel}
        onChange={setActivePanel}
        expandIconPosition="end"
        style={{ marginBottom: 24, borderRadius: 12, border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-primary)', boxShadow: 'var(--shadow-sm)' }}
      >
        <Panel
          header={
            <Space>
              <FileText size={18} style={{ color: 'var(--primary-color)' }} />
              <span style={{ fontWeight: 600, fontSize: 16 }}>1. Allocation Header Context (Collapsible)</span>
            </Space>
          }
          key="header"
        >
          <Form form={form} layout="vertical" className="header-form">
            <Row gutter={[16, 12]}>
              <Col xs={24} sm={12} md={8}>
                <Form.Item label="Region" required>
                  <Select
                    placeholder="Select region"
                    value={selectedRegion || undefined}
                    onChange={(val) => {
                      setSelectedRegion(val);
                      setSelectedSubRegion('');
                      setBillToCustomers([]);
                      setShipToCustomers([]);
                      form.setFieldsValue({ billToCustomer: null, shipToCustomer: null });
                    }}
                    showSearch
                  >
                    {uniqueRegions.map((reg, i) => (
                      <Select.Option key={i} value={reg}>
                        {reg}
                      </Select.Option>
                    ))}
                  </Select>
                </Form.Item>
              </Col>

              <Col xs={24} sm={12} md={8}>
                <Form.Item label="Sub-Region" required>
                  <Select
                    placeholder="Select sub-region"
                    value={selectedSubRegion || undefined}
                    disabled={!selectedRegion}
                    onChange={(val) => setSelectedSubRegion(val)}
                    showSearch
                  >
                    {subRegions.map((sub, i) => (
                      <Select.Option key={i} value={sub}>
                        {sub}
                      </Select.Option>
                    ))}
                  </Select>
                </Form.Item>
              </Col>

              <Col xs={24} sm={12} md={8}>
                <Form.Item
                  name="operatingUnit"
                  label="Operating Unit"
                  rules={[{ required: true, message: 'Operating unit is required' }]}
                >
                  <Select
                    placeholder="Select operating unit"
                    onChange={(val) => setSelectedOU(val)}
                  >
                    {operatingUnits.map(ou => (
                      <Select.Option key={ou.organizationId} value={ou.organizationId}>
                        {ou.name}
                      </Select.Option>
                    ))}
                  </Select>
                </Form.Item>
              </Col>

              <Col xs={24} sm={12} md={12}>
                <Card size="small" className="address-card" title={
                  <Space><MapPin size={16} color="var(--primary-color)" /><span>Bill To Destination</span></Space>
                }>
                  <Form.Item
                    name="billToCustomer"
                    label="Bill To Customer"
                    rules={[{ required: true, message: 'Bill to customer is required' }]}
                  >
                    <Select
                      placeholder="Select bill-to customer"
                      disabled={!selectedSubRegion}
                      onChange={(val) => setSelectedBillToCustomer(val)}
                      showSearch
                      optionFilterProp="children"
                    >
                      {billToCustomers.map(c => (
                        <Select.Option key={c.customerId} value={c.customerId}>
                          {c.customerName}
                        </Select.Option>
                      ))}
                    </Select>
                  </Form.Item>

                  <Form.Item
                    name="billToLocation"
                    label="Bill To Address Location"
                    rules={[{ required: true, message: 'Address location is required' }]}
                  >
                    <Select
                      placeholder="Select address location"
                      disabled={!selectedBillToCustomer || !selectedOU}
                      onChange={handleBillToLocationSelect}
                    >
                      {billToAddresses.map((addr, i) => (
                        <Select.Option key={i} value={addr.location}>
                          {addr.location}
                        </Select.Option>
                      ))}
                    </Select>
                  </Form.Item>
                  {billToAddressDetail && (
                    <div className="address-detail-text">
                      <Text type="secondary" style={{ fontSize: '12px' }}>{billToAddressDetail}</Text>
                    </div>
                  )}
                </Card>
              </Col>

              <Col xs={24} sm={12} md={12}>
                <Card size="small" className="address-card" title={
                  <Space><MapPin size={16} color="var(--secondary-color)" /><span>Ship To Destination</span></Space>
                }>
                  <Form.Item
                    name="shipToCustomer"
                    label="Ship To Customer"
                    rules={[{ required: true, message: 'Ship to customer is required' }]}
                  >
                    <Select
                      placeholder="Select ship-to customer"
                      disabled={!selectedSubRegion}
                      onChange={(val) => setSelectedShipToCustomer(val)}
                      showSearch
                      optionFilterProp="children"
                    >
                      {shipToCustomers.map(c => (
                        <Select.Option key={c.customerId} value={c.customerId}>
                          {c.customerName}
                        </Select.Option>
                      ))}
                    </Select>
                  </Form.Item>

                  <Form.Item
                    name="shipToLocation"
                    label="Ship To Address Location"
                    rules={[{ required: true, message: 'Address location is required' }]}
                  >
                    <Select
                      placeholder="Select address location"
                      disabled={!selectedShipToCustomer || !selectedOU}
                      onChange={handleShipToLocationSelect}
                    >
                      {shipToAddresses.map((addr, i) => (
                        <Select.Option key={i} value={addr.location}>
                          {addr.location}
                        </Select.Option>
                      ))}
                    </Select>
                  </Form.Item>
                  {shipToAddressDetail && (
                    <div className="address-detail-text">
                      <Text type="secondary" style={{ fontSize: '12px' }}>{shipToAddressDetail}</Text>
                    </div>
                  )}
                </Card>
              </Col>

              <Col xs={24}>
                <Form.Item name="remarks" label="Transaction Remarks">
                  <Input.TextArea rows={2} placeholder="Add optional remarks..." />
                </Form.Item>
              </Col>
            </Row>
          </Form>
        </Panel>
      </Collapse>

      <Card
        className="lines-card"
        title={
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Space>
              <Database size={18} style={{ color: 'var(--primary-color)' }} />
              <span style={{ fontWeight: 600 }}>2. Allocation Line Items</span>
            </Space>
            <Button type="primary" onClick={addLineRow} icon={<Plus size={16} />}>
              Add Line Row
            </Button>
          </div>
        }
        style={{ borderRadius: 12, border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)' }}
      >
        {lines.map((line, idx) => (
          <div key={line.id} className="line-item-row-container">
            {idx > 0 && <Divider style={{ margin: '16px 0' }} />}

            <Row gutter={[16, 12]} align="bottom">
              <Col xs={24} sm={12} md={4}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <span className="field-label-custom">ORG</span>
                  <Select
                    placeholder="Select Org"
                    value={line.organizationId}
                    onChange={(val) => updateLineRow(line.id, 'organizationId', val)}
                    style={{ width: '100%' }}
                  >
                    {organizations.map(org => (
                      <Select.Option key={org.organizationId} value={org.organizationId}>
                        {org.organizationCode}
                      </Select.Option>
                    ))}
                  </Select>
                </div>
              </Col>

              <Col xs={24} sm={12} md={5}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <span className="field-label-custom">Item Code</span>
                  <Select
                    placeholder="Select Item"
                    value={line.inventoryItemId}
                    onChange={(val) => updateLineRow(line.id, 'inventoryItemId', val)}
                    style={{ width: '100%' }}
                    showSearch
                    optionFilterProp="children"
                  >
                    {items.map(item => (
                      <Select.Option key={item.inventoryItemId} value={item.inventoryItemId}>
                        {item.itemCode}
                      </Select.Option>
                    ))}
                  </Select>
                </div>
              </Col>

              <Col xs={24} sm={12} md={5}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <span className="field-label-custom">Item Description</span>
                  <Input value={line.description} disabled style={{ backgroundColor: 'var(--bg-tertiary)' }} />
                </div>
              </Col>

              <Col xs={24} sm={12} md={3}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <span className="field-label-custom">Week</span>
                  <Select
                    placeholder="Week"
                    value={line.week}
                    onChange={(val) => updateLineRow(line.id, 'week', val)}
                    style={{ width: '100%' }}
                  >
                    {weeks.map(wk => (
                      <Select.Option key={wk} value={wk}>
                        {wk}
                      </Select.Option>
                    ))}
                  </Select>
                </div>
              </Col>

              <Col xs={24} sm={12} md={3}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <span className="field-label-custom">Requested Qty</span>
                  <Input
                    type="number"
                    min={1}
                    value={line.b3Quantity === 0 ? '' : line.b3Quantity}
                    onChange={(e) => updateLineRow(line.id, 'b3Quantity', parseInt(e.target.value) || 0)}
                  />
                </div>
              </Col>

              <Col xs={24} sm={12} md={3}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <span className="field-label-custom">Target Date</span>
                  <DatePicker
                    placeholder="Date"
                    style={{ width: '100%' }}
                    onChange={(_, dateString) => updateLineRow(line.id, 'targetDate', Array.isArray(dateString) ? dateString[0] : dateString)}
                  />
                </div>
              </Col>

              <Col xs={24} sm={12} md={1}>
                <Button
                  danger
                  type="text"
                  icon={<Trash2 size={18} />}
                  onClick={() => removeLineRow(line.id)}
                  style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 40 }}
                />
              </Col>
            </Row>

            {/* Validation alerts and demand metrics */}
            <div style={{ marginTop: 12 }}>
              {line.rrsWarning && (
                <Alert
                  type="error"
                  showIcon
                  message={`Validation Alert: Item returned restricted Sales Category "Rn" for organization.`}
                  style={{ marginBottom: 8, borderRadius: 6 }}
                />
              )}

              {line.oaPendingQuantity !== undefined && (
                <div className="metrics-container" style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 4 }}>
                  <Tag color="blue" style={{ borderRadius: 4, padding: '4px 8px' }}>
                    <strong>OA Pending Qty:</strong> {line.oaPendingQuantity}
                  </Tag>
                  <Tag color="warning" style={{ borderRadius: 4, padding: '4px 8px' }}>
                    <strong>OA Reserved Qty:</strong> {line.oaRsvQty}
                  </Tag>
                  <Tag color="success" style={{ borderRadius: 4, padding: '4px 8px' }}>
                    <strong>OA Picked Qty:</strong> {line.oaPickedQty}
                  </Tag>
                  <Tag color="purple" style={{ borderRadius: 4, padding: '4px 8px' }}>
                    <strong>Bin Qty:</strong> {line.binQty}
                  </Tag>
                  <Tag color="cyan" style={{ borderRadius: 4, padding: '4px 8px' }}>
                    <strong>Bin Reserved Qty:</strong> {line.binRsvQty}
                  </Tag>
                </div>
              )}
            </div>
          </div>
        ))}
      </Card>

      <div style={{ marginTop: 24, display: 'flex', justifyContent: 'flex-end', gap: 12 }}>
        <Button onClick={() => navigate('/')} style={{ borderRadius: 8 }}>
          Cancel
        </Button>
        <Button
          type="primary"
          onClick={handleSave}
          icon={<Save size={16} />}
          loading={loading}
          style={{ borderRadius: 8 }}
        >
          Save Allocation
        </Button>
      </div>
    </div>
  );
}
