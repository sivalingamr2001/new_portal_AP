import {
    Badge,
    Button,
    Card,
    InputNumber,
    Modal,
    Popover,
    Space,
    Tag,
    Timeline,
    Typography,
    message
} from 'antd';
import {
    Edit,
    History,
    Plus,
    TrendingUp
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type {
    AllocationRow,
    AllocationSummary,
    B3Line,
    InventoryItem,
    Organization
} from '../api/allocationApi';
import {
    getAllocationByHeaderId,
    getAllocationSummary,
    getItems,
    getLineRevisionHistory,
    getOrganizations,
    reviseQuantity
} from '../api/allocationApi';
import { DynamicGrid } from '../components/DynamicGrid';
import { useNotification } from '../context/NotificationContext';
import '../styles/Fulfillment.css';

const { Title, Text } = Typography;

export default function Fulfillment() {
  const navigate = useNavigate();
  const { addNotification } = useNotification();

  // Component states
  const [summaries, setSummaries] = useState<AllocationSummary[]>([]);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(false);

  // Line details cache: { [headerId]: AllocationRow[] }
  const [detailsCache, setDetailsCache] = useState<{ [key: number]: AllocationRow[] }>({});
  
  // Revision revision state
  const [revisionQty, setRevisionQty] = useState<number>(0);
  const [activeReviseLineId, setActiveReviseLineId] = useState<number | null>(null);

  // History modal state
  const [historyModalVisible, setHistoryModalVisible] = useState(false);
  const [historyLines, setHistoryLines] = useState<B3Line[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyItemCode, setHistoryItemCode] = useState('');

  // Customer lookups
  const customerMap: { [key: number]: string } = {
    101: 'TechCorp Solutions Inc.',
    102: 'Apex Systems Corp.',
    201: 'EuroRetail GmbH',
    202: 'GlobalTrade Ltd.',
    301: 'IndoIndustries Pvt. Ltd.',
    302: 'Nippon Tech KK'
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [sumData, orgData, itemsData] = await Promise.all([
        getAllocationSummary(),
        getOrganizations(),
        getItems(1, 100)
      ]);
      setSummaries(sumData);
      setOrganizations(orgData);
      setItems(itemsData.data);
    } catch (err) {
      message.error('Failed to load dashboard summaries.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Fetch header lines if not cached
  const handleExpandRow = async (expanded: boolean, record: AllocationSummary) => {
    if (!expanded) return;
    try {
      const lines = await getAllocationByHeaderId(record.headerId);
      setDetailsCache(prev => ({ ...prev, [record.headerId]: lines }));
    } catch (err) {
      message.error(`Failed to load lines for allocation #${record.headerId}`);
    }
  };

  // Revision submit handler
  const handleReviseQuantity = async (originalLineId: number, headerId: number) => {
    if (revisionQty <= 0) {
      message.error('Please enter a valid revision quantity.');
      return;
    }

    try {
      const res = await reviseQuantity({
        originalLineId,
        newB3Quantity: revisionQty
      });

      addNotification(`Quantity revised successfully! New Line ID: ${res.newLineId}`, 'info');
      setActiveReviseLineId(null);
      setRevisionQty(0);

      // Force refresh lines under this header
      const updatedLines = await getAllocationByHeaderId(headerId);
      setDetailsCache(prev => ({ ...prev, [headerId]: updatedLines }));

      // Reload dashboard stats
      loadData();
    } catch (err: any) {
      message.error(err.message || 'Revision failed.');
    }
  };

  // Load Revision History timeline
  const handleViewHistory = async (lineId: number, itemCode: string) => {
    setHistoryItemCode(itemCode);
    setHistoryLoading(true);
    setHistoryModalVisible(true);
    try {
      const history = await getLineRevisionHistory(lineId);
      setHistoryLines(history);
    } catch (err) {
      message.error('Failed to fetch revision history.');
    } finally {
      setHistoryLoading(false);
    }
  };

  // Main table columns
  const columns = [
    {
      title: 'Allocation ID',
      dataIndex: 'headerId',
      key: 'headerId',
      render: (id: number) => (
        <Button type="link" style={{ padding: 0, fontWeight: 600 }} onClick={() => addNotification(`Selected Allocation Header Context: #${id}`, 'info')}>
          #{id}
        </Button>
      ),
      sorter: (a: AllocationSummary, b: AllocationSummary) => a.headerId - b.headerId
    },
    {
      title: 'Transaction Date',
      dataIndex: 'transactionDate',
      key: 'transactionDate',
      sorter: (a: AllocationSummary, b: AllocationSummary) => new Date(a.transactionDate).getTime() - new Date(b.transactionDate).getTime()
    },
    {
      title: 'Customer',
      dataIndex: 'customerId',
      key: 'customerId',
      render: (id: number) => customerMap[id] || `Customer ID: ${id}`
    },
    {
      title: 'Total Lines',
      dataIndex: 'totalLines',
      key: 'totalLines',
      sorter: (a: AllocationSummary, b: AllocationSummary) => a.totalLines - b.totalLines
    },
    {
      title: 'Req Qty',
      dataIndex: 'totalRequestedQty',
      key: 'totalRequestedQty',
      render: (qty: number) => <strong>{qty}</strong>,
      sorter: (a: AllocationSummary, b: AllocationSummary) => a.totalRequestedQty - b.totalRequestedQty
    },
    {
      title: 'Appr Qty',
      dataIndex: 'totalApprovedQty',
      key: 'totalApprovedQty',
      render: (qty: number) => <span style={{ color: 'var(--success-color)', fontWeight: 600 }}>{qty}</span>,
      sorter: (a: AllocationSummary, b: AllocationSummary) => a.totalApprovedQty - b.totalApprovedQty
    },
    {
      title: 'Status',
      key: 'status',
      render: (_: any, record: AllocationSummary) => {
        if (record.pendingLines > 0) {
          return <Badge status="processing" text="Pending HOD" style={{ color: 'var(--warning-color)' }} />;
        }
        return <Badge status="success" text="Closed" style={{ color: 'var(--success-color)' }} />;
      }
    }
  ];

  // Render child lines table under expanded header
  const renderExpandedRow = (record: AllocationSummary) => {
    const lines = detailsCache[record.headerId] || [];

    const lineColumns = [
      {
        title: 'Line ID',
        dataIndex: 'lineId',
        key: 'lineId',
        render: (id: number) => <Text type="secondary">#{id}</Text>
      },
      {
        title: 'Org Code',
        dataIndex: 'organizationId',
        key: 'organizationId',
        render: (orgId: number) => {
          const org = organizations.find(o => o.organizationId === orgId);
          return org ? org.organizationCode : `ORG ${orgId}`;
        }
      },
      {
        title: 'Item Code',
        dataIndex: 'inventoryItemId',
        key: 'inventoryItemId',
        render: (itemId: number) => {
          const item = items.find(i => i.inventoryItemId === itemId);
          return item ? <strong>{item.itemCode}</strong> : `ITEM ${itemId}`;
        }
      },
      {
        title: 'Item Description',
        dataIndex: 'inventoryItemId',
        key: 'description',
        render: (itemId: number) => {
          const item = items.find(i => i.inventoryItemId === itemId);
          return item ? item.description : '';
        }
      },
      {
        title: 'Target Date',
        dataIndex: 'targetDate',
        key: 'targetDate'
      },
      {
        title: 'Req Qty',
        dataIndex: 'b3Quantity',
        key: 'b3Quantity',
        render: (qty: number) => <Badge count={qty} style={{ backgroundColor: 'var(--info-color)' }} />
      },
      {
        title: 'Appr Qty',
        dataIndex: 'b3ApprovedQuantity',
        key: 'b3ApprovedQuantity',
        render: (qty: number | null) => qty !== null ? (
          <Tag color="success" style={{ fontWeight: 600 }}>{qty}</Tag>
        ) : (
          <Tag color="default">Pending</Tag>
        )
      },
      {
        title: 'Revision No.',
        dataIndex: 'revision',
        key: 'revision',
        render: (rev: number, line: AllocationRow) => {
          const item = items.find(i => i.inventoryItemId === line.inventoryItemId);
          return (
            <Button
              type="text"
              size="small"
              onClick={() => handleViewHistory(line.lineId, item ? item.itemCode : '')}
              icon={<History size={14} />}
              style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}
            >
              Rev {rev}
            </Button>
          );
        }
      },
      {
        title: 'Status',
        key: 'status',
        render: (_: any, line: AllocationRow) => {
          if (line.closureFlag === 'Y' && line.approvalFlag === 'N') {
            return <Tag color="error">Cancelled</Tag>;
          }
          if (line.approvalFlag === 'Y') {
            return <Tag color="success">Approved</Tag>;
          }
          return <Tag color="warning">Pending Approval</Tag>;
        }
      },
      {
        title: 'Revision Action',
        key: 'actions',
        render: (_: any, line: AllocationRow) => {
          const isPending = line.approvalFlag === 'N' && line.closureFlag === 'N';
          if (!isPending) {
            return <Text type="secondary" style={{ fontSize: '12px' }}>Locked</Text>;
          }
          return (
            <Popover
              title="Revise Quantity"
              trigger="click"
              open={activeReviseLineId === line.lineId}
              onOpenChange={(visible) => {
                if (visible) {
                  setActiveReviseLineId(line.lineId);
                  setRevisionQty(line.b3Quantity);
                } else {
                  setActiveReviseLineId(null);
                }
              }}
              content={
                <Space direction="vertical" style={{ width: 180 }}>
                  <InputNumber
                    min={1}
                    value={revisionQty}
                    onChange={(val) => setRevisionQty(val || 0)}
                    style={{ width: '100%' }}
                  />
                  <Button
                    type="primary"
                    size="small"
                    style={{ width: '100%', borderRadius: 4 }}
                    onClick={() => handleReviseQuantity(line.lineId, record.headerId)}
                  >
                    Confirm Revision
                  </Button>
                </Space>
              }
            >
              <Button
                type="dashed"
                size="small"
                icon={<Edit size={12} />}
                style={{ display: 'inline-flex', alignItems: 'center', gap: 4, borderRadius: 4 }}
              >
                Revise Qty
              </Button>
            </Popover>
          );
        }
      }
    ];

    return (
      <Card
        size="small"
        style={{ margin: '8px 16px', backgroundColor: 'var(--bg-secondary)', border: '1px dashed var(--border-color)', borderRadius: 8 }}
      >
        <div style={{ padding: '4px 0 12px 0' }}>
          <Text type="secondary" style={{ fontSize: '12px', fontWeight: 600 }}>Detailed Line Allocations (Grouped by Root Revision)</Text>
        </div>
        <DynamicGrid
          columns={lineColumns as any}
          dataSource={lines}
          enableSearch={false}
          pagination={false}
          size="small"
        />
      </Card>
    );
  };

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <Space direction="vertical" size={2}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <TrendingUp size={24} style={{ color: 'var(--primary-color)' }} />
            <Title level={2} style={{ margin: 0, color: 'var(--text-primary)' }}>Fulfillment</Title>
          </div>
          <Text type="secondary">Fulfillment</Text>
        </Space>
        <Button
          type="primary"
          onClick={() => navigate('/production')}
          icon={<Plus size={16} />}
          style={{ borderRadius: 8, height: 40, display: 'inline-flex', alignItems: 'center', gap: 4 }}
        >
          Create Allocation
        </Button>
      </div>

      <DynamicGrid
        columns={columns}
        dataSource={summaries}
        searchPlaceholder="Search allocations (ID, Date, Customer...)"
        expandable={{
          expandedRowRender: renderExpandedRow,
          rowExpandable: () => true,
          onExpand: handleExpandRow
        }}
        loading={loading}
      />

      {/* Revision History Modal */}
      <Modal
        title={
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <History size={18} style={{ color: 'var(--primary-color)' }} />
            <span>Line Revision History — Item: {historyItemCode}</span>
          </div>
        }
        open={historyModalVisible}
        onCancel={() => setHistoryModalVisible(false)}
        footer={[
          <Button key="close" onClick={() => setHistoryModalVisible(false)}>
            Close
          </Button>
        ]}
        width={500}
      >
        <div style={{ padding: '20px 10px' }}>
          {historyLoading ? (
            <div style={{ textAlign: 'center', padding: '20px 0' }}>Loading revision chain...</div>
          ) : (
            <Timeline mode="left">
              {historyLines.map((revLine) => {
                const isApproved = revLine.approvalFlag === 'Y';
                const isCancelled = revLine.closureFlag === 'Y' && revLine.approvalFlag === 'N';
                return (
                  <Timeline.Item
                    key={revLine.lineId}
                    color={isCancelled ? 'red' : isApproved ? 'green' : 'blue'}
                    label={`Revision ${revLine.revision}`}
                  >
                    <div className="revision-timeline-item">
                      <div style={{ fontWeight: 600, fontSize: 14 }}>
                        Requested Qty: {revLine.b3Quantity}
                      </div>
                      <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 4 }}>
                        Line ID: #{revLine.lineId}
                      </div>
                      {isApproved && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 2, marginTop: 6 }}>
                          <Tag color="success" style={{ width: 'fit-content' }}>
                            Approved Qty: {revLine.b3ApprovedQuantity}
                          </Tag>
                          <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>
                            Authorized by {revLine.approvedBy} on {new Date(revLine.approvedDate!).toLocaleDateString()}
                          </span>
                        </div>
                      )}
                      {isCancelled && (
                        <Tag color="error" style={{ width: 'fit-content', marginTop: 6 }}>
                          Cancelled / Closed
                        </Tag>
                      )}
                      {!isApproved && !isCancelled && (
                        <Tag color="processing" style={{ width: 'fit-content', marginTop: 6 }}>
                          Pending Authorization
                        </Tag>
                      )}
                    </div>
                  </Timeline.Item>
                );
              })}
            </Timeline>
          )}
        </div>
      </Modal>
    </div>
  );
}
