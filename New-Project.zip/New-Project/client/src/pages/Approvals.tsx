import React, { useState, useEffect } from 'react';
import {
  Space,
  Button,
  InputNumber,
  Badge,
  Input,
  Popover,
  Card,
  Tooltip,
  Typography,
  message
} from 'antd';
import { Check, X, ClipboardCheck, UserCheck } from 'lucide-react';
import { DynamicGrid } from '../components/DynamicGrid';
import {
  getAllAllocations,
  approveLine,
  cancelLine,
  cancelAllLines,
  getOrganizations,
  getItems
} from '../api/allocationApi';
import type {
  AllocationRow,
  Organization,
  InventoryItem,
  Customer
} from '../api/allocationApi';
import { useNotification } from '../context/NotificationContext';
import '../styles/Approvals.css';

const { Title, Text } = Typography;

export default function Approvals() {
  const { addNotification } = useNotification();
  const [allocations, setAllocations] = useState<AllocationRow[]>([]);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(false);

  // Store editable approved quantities in state: { [lineId]: quantity }
  const [approvedQuantities, setApprovedQuantities] = useState<{ [key: number]: number }>({});
  // Store cancellation reasons in state: { [id]: reason }
  const [cancelReasons, setCancelReasons] = useState<{ [key: number]: string }>({});

  const loadData = async () => {
    setLoading(true);
    try {
      const [allData, orgData, itemsData] = await Promise.all([
        getAllAllocations(),
        getOrganizations(),
        getItems(1, 100)
      ]);
      setAllocations(allData);
      setOrganizations(orgData);
      setItems(itemsData.data);

      // Since it's mockup data, let's create a lookup mapping or mock fetch
      // For this demonstration, we'll map IDs to customer details
      const customerMap = [
        { customerId: 101, customerName: 'TechCorp Solutions Inc.', region: 'North America' },
        { customerId: 102, customerName: 'Apex Systems Corp.', region: 'North America' },
        { customerId: 201, customerName: 'EuroRetail GmbH', region: 'Europe' },
        { customerId: 202, customerName: 'GlobalTrade Ltd.', region: 'Europe' },
        { customerId: 301, customerName: 'IndoIndustries Pvt. Ltd.', region: 'Asia Pacific' },
        { customerId: 302, customerName: 'Nippon Tech KK', region: 'Asia Pacific' }
      ];
      setCustomers(customerMap);

      // Prepopulate approved quantities with requested quantities
      const pendingQuantities: { [key: number]: number } = {};
      allData.forEach(row => {
        if (row.approvalFlag === 'N' && row.closureFlag === 'N') {
          pendingQuantities[row.lineId] = row.b3Quantity;
        }
      });
      setApprovedQuantities(prev => ({ ...prev, ...pendingQuantities }));
    } catch (err) {
      message.error('Failed to retrieve pending allocations.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // HOD Line Approve Handler
  const handleApproveLine = async (lineId: number, requestedQty: number) => {
    const qty = approvedQuantities[lineId] ?? requestedQty;
    if (qty <= 0) {
      message.error('Approved quantity must be greater than zero.');
      return;
    }

    try {
      await approveLine({
        lineId,
        approvedQuantity: qty,
        approvedBy: 'HOD-Patel'
      });
      addNotification(`Line #${lineId} approved successfully with qty: ${qty}`, 'info');
      loadData();
    } catch (err: any) {
      message.error(err.message || 'Approval failed.');
    }
  };

  // HOD Line Cancel Handler
  const handleCancelLine = async (lineId: number, qty: number) => {
    const reason = cancelReasons[lineId] || 'Cancelled by HOD';
    try {
      await cancelLine({
        lineId,
        cancelledQty: qty,
        cancelReason: reason,
        createdBy: 'HOD-Patel'
      });
      addNotification(`Line #${lineId} cancelled. Reason: ${reason}`, 'warning');
      loadData();
    } catch (err: any) {
      message.error(err.message || 'Cancellation failed.');
    }
  };

  // HOD Bulk Header Approval Handler
  const handleApproveAll = async (headerId: number) => {
    const linesToApprove = allocations.filter(
      r => r.headerId === headerId && r.approvalFlag === 'N' && r.closureFlag === 'N'
    );

    if (linesToApprove.length === 0) {
      message.warning('No pending lines to approve under this header.');
      return;
    }

    try {
      setLoading(true);
      await Promise.all(
        linesToApprove.map(line =>
          approveLine({
            lineId: line.lineId,
            approvedQuantity: approvedQuantities[line.lineId] ?? line.b3Quantity,
            approvedBy: 'HOD-Patel'
          })
        )
      );
      addNotification(`Approved all pending lines under Header #${headerId}`, 'info');
      loadData();
    } catch (err: any) {
      message.error('Bulk approval failed.');
    } finally {
      setLoading(false);
    }
  };

  // HOD Bulk Header Cancel Handler
  const handleCancelAll = async (headerId: number) => {
    const reason = cancelReasons[headerId] || 'Full allocation cancelled by HOD';
    try {
      setLoading(true);
      await cancelAllLines({
        headerId,
        cancelReason: reason,
        createdBy: 'HOD-Patel'
      });
      addNotification(`Cancelled all lines under Header #${headerId}`, 'critical');
      loadData();
    } catch (err: any) {
      message.error('Bulk cancellation failed.');
    } finally {
      setLoading(false);
    }
  };

  // Group allocations to headers list
  const parentHeaders = React.useMemo(() => {
    const headerGroups: { [key: number]: any } = {};

    allocations.forEach(row => {
      // We only care about allocations that contain at least one pending line in HOD console
      if (row.approvalFlag === 'N' && row.closureFlag === 'N') {
        if (!headerGroups[row.headerId]) {
          const cust = customers.find(c => c.customerId === row.customerId);
          headerGroups[row.headerId] = {
            headerId: row.headerId,
            transactionDate: row.transactionDate,
            customerId: row.customerId,
            customerName: cust ? cust.customerName : `Customer ID: ${row.customerId}`,
            createdBy: row.createdBy,
            remarks: row.remarks,
            pendingLinesCount: 0
          };
        }
        headerGroups[row.headerId].pendingLinesCount += 1;
      }
    });

    return Object.values(headerGroups).sort((a, b) => b.headerId - a.headerId);
  }, [allocations, customers]);

  // Headers Columns definition
  const parentColumns = [
    {
      title: 'Header ID',
      dataIndex: 'headerId',
      key: 'headerId',
      render: (id: number) => <strong style={{ color: 'var(--primary-color)' }}>#{id}</strong>,
      sorter: (a: any, b: any) => a.headerId - b.headerId
    },
    {
      title: 'Transaction Date',
      dataIndex: 'transactionDate',
      key: 'transactionDate',
      sorter: (a: any, b: any) => new Date(a.transactionDate).getTime() - new Date(b.transactionDate).getTime()
    },
    {
      title: 'Customer Name',
      dataIndex: 'customerName',
      key: 'customerName'
    },
    {
      title: 'Created By',
      dataIndex: 'createdBy',
      key: 'createdBy'
    },
    {
      title: 'Pending Lines',
      dataIndex: 'pendingLinesCount',
      key: 'pendingLinesCount',
      render: (count: number) => <Badge count={count} style={{ backgroundColor: 'var(--warning-color)' }} />
    },
    {
      title: 'Bulk Actions',
      key: 'bulkActions',
      render: (_: any, record: any) => (
        <Space size="middle">
          <Button
            type="primary"
            size="small"
            onClick={() => handleApproveAll(record.headerId)}
            icon={<Check size={14} />}
            style={{ borderRadius: 6 }}
          >
            Approve All
          </Button>

          <Popover
            title="Cancel Entire Allocation"
            trigger="click"
            content={
              <Space direction="vertical" style={{ width: 220 }}>
                <Input
                  placeholder="Enter cancel reason"
                  value={cancelReasons[record.headerId] || ''}
                  onChange={(e) => setCancelReasons({ ...cancelReasons, [record.headerId]: e.target.value })}
                />
                <Button
                  danger
                  type="primary"
                  size="small"
                  onClick={() => handleCancelAll(record.headerId)}
                  style={{ width: '100%', borderRadius: 4 }}
                >
                  Confirm Cancel All
                </Button>
              </Space>
            }
          >
            <Button
              danger
              size="small"
              icon={<X size={14} />}
              style={{ borderRadius: 6 }}
            >
              Cancel All
            </Button>
          </Popover>
        </Space>
      )
    }
  ];

  // Child Lines rendering function
  const renderExpandedRow = (record: any) => {
    // Get all pending lines for this specific headerId
    const pendingLines = allocations.filter(
      r => r.headerId === record.headerId && r.approvalFlag === 'N' && r.closureFlag === 'N'
    );

    const childColumns = [
      {
        title: 'Line ID',
        dataIndex: 'lineId',
        key: 'lineId',
        render: (id: number) => <Text type="secondary">#{id}</Text>
      },
      {
        title: 'Org Code',
        dataIndex: 'organizationId',
        key: 'organizationId',
        render: (orgId: number) => {
          const org = organizations.find(o => o.organizationId === orgId);
          return org ? org.organizationCode : `ORG ${orgId}`;
        }
      },
      {
        title: 'Item Code',
        dataIndex: 'inventoryItemId',
        key: 'inventoryItemId',
        render: (itemId: number) => {
          const item = items.find(i => i.inventoryItemId === itemId);
          return item ? <strong>{item.itemCode}</strong> : `ITEM ${itemId}`;
        }
      },
      {
        title: 'Description',
        dataIndex: 'inventoryItemId',
        key: 'description',
        render: (itemId: number) => {
          const item = items.find(i => i.inventoryItemId === itemId);
          return item ? item.description : '';
        }
      },
      {
        title: 'Target Date',
        dataIndex: 'targetDate',
        key: 'targetDate'
      },
      {
        title: 'Requested Qty',
        dataIndex: 'b3Quantity',
        key: 'b3Quantity',
        render: (qty: number) => <Badge count={qty} style={{ backgroundColor: 'var(--info-color)' }} />
      },
      {
        title: 'Approved Qty Input',
        key: 'approvedQtyInput',
        render: (_: any, line: any) => (
          <InputNumber
            min={1}
            value={approvedQuantities[line.lineId] ?? line.b3Quantity}
            onChange={(val) => setApprovedQuantities({ ...approvedQuantities, [line.lineId]: val || 0 })}
            style={{ width: 100, borderRadius: 6 }}
          />
        )
      },
      {
        title: 'Actions',
        key: 'actions',
        render: (_: any, line: any) => (
          <Space>
            <Tooltip title="Approve Line">
              <Button
                type="text"
                className="action-btn-approve"
                icon={<Check size={18} color="var(--success-color)" />}
                onClick={() => handleApproveLine(line.lineId, line.b3Quantity)}
              />
            </Tooltip>

            <Popover
              title="Cancel Line"
              trigger="click"
              content={
                <Space direction="vertical" style={{ width: 180 }}>
                  <Input
                    placeholder="Reason"
                    size="small"
                    value={cancelReasons[line.lineId] || ''}
                    onChange={(e) => setCancelReasons({ ...cancelReasons, [line.lineId]: e.target.value })}
                  />
                  <Button
                    danger
                    type="primary"
                    size="small"
                    style={{ width: '100%', borderRadius: 4 }}
                    onClick={() => handleCancelLine(line.lineId, line.b3Quantity)}
                  >
                    Confirm Cancel
                  </Button>
                </Space>
              }
            >
              <Tooltip title="Cancel Line">
                <Button
                  type="text"
                  danger
                  icon={<X size={18} />}
                />
              </Tooltip>
            </Popover>
          </Space>
        )
      }
    ];

    return (
      <Card
        size="small"
        style={{ margin: '8px 16px', backgroundColor: 'var(--bg-secondary)', border: '1px dashed var(--border-color)', borderRadius: 8 }}
      >
        <div style={{ padding: '4px 0 12px 0' }}>
          <Text type="secondary" strong>Line Items Pending HOD Verification</Text>
        </div>
        <DynamicGrid
          columns={childColumns as any}
          dataSource={pendingLines}
          enableSearch={false}
          pagination={false}
          size="small"
        />
      </Card>
    );
  };

  return (
    <div className="approvals-container">
      <div className="approvals-header">
        <Space direction="vertical" size={2}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <UserCheck size={24} style={{ color: 'var(--primary-color)' }} />
            <Title level={2} style={{ margin: 0, color: 'var(--text-primary)' }}>HOD Approvals Console</Title>
          </div>
          <Text type="secondary">Review requested quantities, adjust allocations, and authorize transactions</Text>
        </Space>
      </div>

      {parentHeaders.length === 0 ? (
        <Card style={{ borderRadius: 12, border: '1px solid var(--border-color)', textAlign: 'center', padding: '40px 0' }}>
          <ClipboardCheck size={48} style={{ color: 'var(--text-secondary)', marginBottom: 12 }} />
          <Title level={4} style={{ margin: 0 }}>All caught up!</Title>
          <Text type="secondary">There are no pending allocations requiring HOD approval at this time.</Text>
        </Card>
      ) : (
        <DynamicGrid
          columns={parentColumns}
          dataSource={parentHeaders}
          searchPlaceholder="Search pending headers..."
          expandable={{
            expandedRowRender: renderExpandedRow,
            rowExpandable: () => true
          }}
          loading={loading}
        />
      )}
    </div>
  );
}
