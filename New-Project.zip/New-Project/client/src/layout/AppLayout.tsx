import React, { useState } from 'react';
import { Layout } from 'antd';
import { Sidebar } from './Sidebar';
import { TopHeader } from './Header';
import '../styles/AppLayout.css';

interface AppLayoutProps {
  children: React.ReactNode;
}

export const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const [collapsed, setCollapsed] = useState(false);
  const { Content } = Layout;

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sidebar collapsed={collapsed} onCollapse={setCollapsed} />
      <Layout className={`main-layout ${collapsed ? 'collapsed' : ''}`}>
        <TopHeader />
        <Content className="main-content">{children}</Content>
      </Layout>
    </Layout>
  );
};
