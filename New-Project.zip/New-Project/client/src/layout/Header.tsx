import { Col, Layout, Row, Space } from 'antd';
import { Bell } from 'lucide-react';
import React from 'react';
import '../styles/Header.css';

const { Header } = Layout;

export const TopHeader: React.FC = () => {

  return (
    <Header className="app-header">
      <Row justify="space-between" align="middle" style={{ width: '100%', height: '100%' }}>
        <Col>
          <h1 className="header-title">Manufacturing Analytics Portal</h1>
        </Col>

        <Col className="header-actions">
          <Space>
            <Bell />
          </Space>
        </Col>
      </Row>
    </Header>
  );
};

