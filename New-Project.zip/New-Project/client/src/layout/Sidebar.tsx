import { Button, Layout, Menu } from 'antd';
import { ChevronLeft, ChevronRight, ClipboardList, Users, Zap } from 'lucide-react';
import React from 'react';
import { NavLink } from 'react-router-dom';
import '../styles/Sidebar.css';

const { Sider } = Layout;

const navigationItems = [
  {
    section: '',
    icon: Zap,
    items: [{ path: '/', label: 'Dashboard' }],
  },
  {
    section: '',
    icon: Users,
    items: [{ path: '/fulfillment', label: 'Fulfillment' }],
  },
  {
    section: '',
    icon: ClipboardList,
    items: [{ path: '/quality', label: 'Approvals' }],
  }
];

interface SidebarProps {
  collapsed: boolean;
  onCollapse: (collapsed: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ collapsed, onCollapse }) => {
  return (
    <Sider
      collapsible
      collapsed={collapsed}
      onCollapse={onCollapse}
      width={240}
      collapsedWidth={80}
      className="app-sider"
      trigger={null}
    >
      <div className="sidebar-header">
        <div className="sidebar-logo">
          <Zap size={24} color="var(--primary-color)" />
          {!collapsed && <span className="logo-text">MFG Analytics</span>}
        </div>
      </div>
      
      <Button
        type="text"
        icon={collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
        onClick={() => onCollapse(!collapsed)}
        className="collapse-btn"
      />

      <Menu theme="light" className="sidebar-menu">
        {navigationItems.map((group, idx) => {
          const IconComponent = group.icon;
          return (
            <div key={idx} className="menu-section">
              <div className="menu-section-title">{!collapsed && <span>{group.section}</span>}</div>
              {group.items.map((item, itemIdx) => (
                <NavLink
                  key={itemIdx}
                  to={item.path}
                  className={({ isActive }) => `menu-item ${isActive ? 'active' : ''}`}
                >
                  <IconComponent size={18} />
                  {!collapsed && <span>{item.label}</span>}
                </NavLink>
              ))}
            </div>
          );
        })}
      </Menu>
    </Sider>
  );
};
