import axios from 'axios';

export const axiosClient = axios.create({
  baseURL: 'http://localhost:5028',
  headers: {
    'Content-Type': 'application/json',
  },
});
