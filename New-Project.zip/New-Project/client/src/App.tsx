import React, { useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import { ConfigProvider } from 'antd';
import './App.css';
import Dashboard from './pages/Dashboard';
import Approvals from './pages/Approvals';
import { ConfigureAntTheme } from './theme/antTheme';
import { NotificationProvider, useNotification } from './context/NotificationContext';
import { AppLayout } from './layout/AppLayout';
import Allocations from './pages/Allocations';
import Fulfillment from './pages/Fulfillment';

const AppContent: React.FC = () => {
  const { addNotification } = useNotification();

  // Show initial alert on load
  useEffect(() => {
    setTimeout(() => {
      addNotification('Critical: Machine M-12 temperature threshold exceeded', 'critical');
    }, 500);
  }, [addNotification]);

  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/production" element={<Allocations />} />
        <Route path="/fulfillment" element={<Fulfillment />} />
        <Route path="/quality" element={<Approvals />} />
      </Routes>
    </AppLayout>
  );
};

const App: React.FC = () => {
  return (
    <ConfigProvider theme={ConfigureAntTheme}>
      <NotificationProvider>
          <AppContent />
      </NotificationProvider>
    </ConfigProvider>
  );
};

export default App;
