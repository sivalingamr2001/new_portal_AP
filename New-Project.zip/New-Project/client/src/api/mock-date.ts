import type {
  Region,
  Customer,
  Employee,
  CustomerAddress,
  OperatingUnit,
  DemandMetrics,
  Organization,
  InventoryItem,
  RrsCategory,
  B3Header,
  B3Line,
  B3Cancellation,
  AllocationRow,
  AllocationSummary,
  CreateAllocationRequest,
  ReviseQuantityRequest,
  ApproveLineRequest,
  AmendQuantityRequest,
  CancelLineRequest,
  CancelHeaderRequest
} from './allocationApi';

// ==================== MOCK DATA LISTS ====================

export const mockRegions: Region[] = [
  { region: 'North America', subRegion: 'US East' },
  { region: 'North America', subRegion: 'US West' },
  { region: 'Europe', subRegion: 'Germany' },
  { region: 'Europe', subRegion: 'United Kingdom' },
  { region: 'Asia Pacific', subRegion: 'India' },
  { region: 'Asia Pacific', subRegion: 'Japan' }
];

export const mockCustomers: Customer[] = [
  { customerId: 101, customerName: 'TechCorp Solutions Inc.', region: 'North America' },
  { customerId: 102, customerName: 'Apex Systems Corp.', region: 'North America' },
  { customerId: 201, customerName: 'EuroRetail GmbH', region: 'Europe' },
  { customerId: 202, customerName: 'GlobalTrade Ltd.', region: 'Europe' },
  { customerId: 301, customerName: 'IndoIndustries Pvt. Ltd.', region: 'Asia Pacific' },
  { customerId: 302, customerName: 'Nippon Tech KK', region: 'Asia Pacific' }
];

export const mockEmployees: Employee[] = [
  { lastName: 'Smith', employeeNumber: 'E001' },
  { lastName: 'Jones', employeeNumber: 'E002' },
  { lastName: 'Patel', employeeNumber: 'E003' },
  { lastName: 'Tanaka', employeeNumber: 'E004' }
];

export const mockOperatingUnits: OperatingUnit[] = [
  { organizationId: 1001, name: 'OU North America' },
  { organizationId: 2001, name: 'OU Europe' },
  { organizationId: 3001, name: 'OU Asia Pacific' }
];

export const mockOrganizations: Organization[] = [
  { organizationId: 110, organizationCode: 'US1' },
  { organizationId: 120, organizationCode: 'US2' },
  { organizationId: 210, organizationCode: 'DE1' },
  { organizationId: 220, organizationCode: 'UK1' },
  { organizationId: 310, organizationCode: 'IN1' },
  { organizationId: 320, organizationCode: 'JP1' }
];

export const mockInventoryItems: InventoryItem[] = [
  { inventoryItemId: 5001, itemCode: 'ITEM-100', description: 'High-Performance CPU Board' },
  { inventoryItemId: 5002, itemCode: 'ITEM-200', description: 'Dual-Core Memory Controller' },
  { inventoryItemId: 5003, itemCode: 'ITEM-300', description: 'Ultra-Fast Cache Unit' },
  { inventoryItemId: 5004, itemCode: 'ITEM-400', description: 'Graphics Processing Core' },
  { inventoryItemId: 5005, itemCode: 'ITEM-500', description: 'System Power Converter' },
  { inventoryItemId: 5006, itemCode: 'ITEM-600', description: 'PCI Express Interface' }
];

export const mockWeeksList: string[] = [
  'W26-2026', 'W27-2026', 'W28-2026', 'W29-2026', 'W30-2026', 'W31-2026', 'W32-2026'
];

export const mockAddresses: CustomerAddress[] = [
  // TechCorp (101) - Bill To
  { address1: '100 Broadway Suite 400', address2: 'Financial District', address3: '', city: 'New York', postalCode: '10005', orgId: 1001, location: 'NY-BILL-TO' },
  // TechCorp (101) - Ship To
  { address1: '45 Industrial Way', address2: 'Dock 4', address3: 'Warehouse 2', city: 'Newark', postalCode: '07101', orgId: 1001, location: 'NJ-SHIP-TO' },
  // Apex Systems (102) - Bill To
  { address1: '500 Sand Hill Rd', address2: 'Building 1', address3: '', city: 'Menlo Park', postalCode: '94025', orgId: 1001, location: 'CA-BILL-TO' },
  // Apex Systems (102) - Ship To
  { address1: '1200 Logistics Blvd', address2: 'Bay 12', address3: '', city: 'San Jose', postalCode: '95112', orgId: 1001, location: 'SJ-SHIP-TO' },
  // EuroRetail (201) - Bill To
  { address1: 'Leipziger Str. 12', address2: '', address3: '', city: 'Berlin', postalCode: '10117', orgId: 2001, location: 'DE-BILL-TO' },
  // EuroRetail (201) - Ship To
  { address1: 'Hafenstrasse 88', address2: 'Tor 3', address3: '', city: 'Hamburg', postalCode: '20457', orgId: 2001, location: 'HH-SHIP-TO' },
  // GlobalTrade (202) - Bill To
  { address1: '25 Cannon St', address2: '', address3: '', city: 'London', postalCode: 'EC4M 5TA', orgId: 2001, location: 'UK-BILL-TO' },
  // GlobalTrade (202) - Ship To
  { address1: 'Unit 4, Gateway Park', address2: 'Orchard Rd', address3: '', city: 'Heathrow', postalCode: 'TW6 1AP', orgId: 2001, location: 'LHR-SHIP-TO' },
  // IndoIndustries (301) - Bill To
  { address1: 'Plot 45, MIDC Industrial Area', address2: 'Andheri East', address3: '', city: 'Mumbai', postalCode: '400093', orgId: 3001, location: 'IN-BILL-TO' },
  // IndoIndustries (301) - Ship To
  { address1: 'Survey 220, NH 4', address2: 'Pune-Bangalore Highway', address3: '', city: 'Pune', postalCode: '411019', orgId: 3001, location: 'PN-SHIP-TO' },
  // Nippon Tech (302) - Bill To
  { address1: '1-2-1 Otemachi', address2: 'Chiyoda-ku', address3: '', city: 'Tokyo', postalCode: '100-0004', orgId: 3001, location: 'JP-BILL-TO' },
  // Nippon Tech (302) - Ship To
  { address1: '3-4-5 Minato Mirai', address2: 'Nishi-ku', address3: '', city: 'Yokohama', postalCode: '220-0012', orgId: 3001, location: 'YK-SHIP-TO' }
];

// ==================== IN-MEMORY DB TABLES ====================

export let dbHeaders: B3Header[] = [
  {
    headerId: 10001,
    transactionDate: '2026-06-18',
    customerOrItemSpecific: 1,
    customerId: 101,
    territoryId: null,
    billToCustomer: 101,
    shipToCustomer: 101,
    createdBy: 'Smith',
    createdDate: '2026-06-18T10:00:00Z',
    updatedBy: null,
    updatedDate: null,
    remarks: 'Urgent CPU allocation request'
  },
  {
    headerId: 10002,
    transactionDate: '2026-06-20',
    customerOrItemSpecific: 1,
    customerId: 201,
    territoryId: null,
    billToCustomer: 201,
    shipToCustomer: 201,
    createdBy: 'Jones',
    createdDate: '2026-06-20T14:30:00Z',
    updatedBy: null,
    updatedDate: null,
    remarks: 'Routine restocking'
  }
];

export let dbLines: B3Line[] = [
  // Header 10001 Lines
  {
    lineId: 20001,
    headerId: 10001,
    organizationId: 110,
    inventoryItemId: 5001, // ITEM-100
    b3Quantity: 100,
    targetDate: '2026-07-01',
    b3ApprovedQuantity: 80,
    approvalFlag: 'Y',
    approvedDate: '2026-06-19T09:00:00Z',
    approvedBy: 'Patel',
    closureFlag: 'Y', // Set to Y on approval since approved lines lock
    revision: 0,
    parentLineId: null
  },
  {
    lineId: 20002,
    headerId: 10001,
    organizationId: 110,
    inventoryItemId: 5002, // ITEM-200
    b3Quantity: 50,
    targetDate: '2026-07-05',
    b3ApprovedQuantity: null,
    approvalFlag: 'N',
    approvedDate: null,
    approvedBy: null,
    closureFlag: 'N',
    revision: 0,
    parentLineId: null
  },
  // Header 10002 Lines
  {
    lineId: 20003,
    headerId: 10002,
    organizationId: 210,
    inventoryItemId: 5003, // ITEM-300
    b3Quantity: 200,
    targetDate: '2026-07-15',
    b3ApprovedQuantity: null,
    approvalFlag: 'N',
    approvedDate: null,
    approvedBy: null,
    closureFlag: 'N',
    revision: 0,
    parentLineId: null
  }
];

export let dbCancellations: B3Cancellation[] = [];

// Helper generators
let nextHeaderId = 10003;
let nextLineId = 20004;
let nextCancelId = 30001;

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// ==================== QUERY & MUTATION EXPORTS ====================

export const mockGetRegions = async (): Promise<Region[]> => {
  await delay(150);
  return mockRegions;
};

export const mockGetBillToCustomers = async (region: string, subRegion: string): Promise<Customer[]> => {
  await delay(150);
  console.log(`[Mock DB] getBillToCustomers - region: ${region}, subRegion: ${subRegion}`);
  return mockCustomers.filter(c => c.region.toLowerCase() === region.toLowerCase());
};

export const mockGetShipToCustomers = async (region: string, subRegion: string): Promise<Customer[]> => {
  await delay(150);
  console.log(`[Mock DB] getShipToCustomers - region: ${region}, subRegion: ${subRegion}`);
  return mockCustomers.filter(c => c.region.toLowerCase() === region.toLowerCase());
};

export const mockGetPreparedByEmployees = async (region: string): Promise<Employee[]> => {
  await delay(100);
  console.log(`[Mock DB] getPreparedByEmployees - region: ${region}`);
  return mockEmployees;
};

export const mockGetCustomerAddresses = async (
  customerId: number,
  siteUseCode?: string,
  orgId?: number
): Promise<CustomerAddress[]> => {
  await delay(150);
  console.log(`[Mock DB] getCustomerAddresses - customerId: ${customerId}, siteUseCode: ${siteUseCode}, orgId: ${orgId}`);
  // Filter addresses by orgId and location containing siteUseCode type
  let filtered = mockAddresses;
  if (siteUseCode) {
    const isBill = siteUseCode.toUpperCase().includes('BILL');
    filtered = filtered.filter(addr => isBill ? addr.location.includes('BILL') : addr.location.includes('SHIP'));
  }
  if (orgId) {
    filtered = filtered.filter(addr => addr.orgId === orgId);
  }
  return filtered;
};

export const mockGetWeeksDropdown = async (): Promise<string[]> => {
  await delay(100);
  return mockWeeksList;
};

export const mockGetOperatingUnits = async (): Promise<OperatingUnit[]> => {
  await delay(100);
  return mockOperatingUnits;
};

export const mockGetOrganizations = async (): Promise<Organization[]> => {
  await delay(100);
  return mockOrganizations;
};

export const mockGetItems = async (
  page: number = 1,
  pageSize: number = 10,
  search?: string
): Promise<{ data: InventoryItem[], totalCount: number, page: number, pageSize: number, totalPages: number, hasNextPage: boolean, hasPreviousPage: boolean }> => {
  await delay(200);
  let list = mockInventoryItems;
  if (search) {
    const term = search.toLowerCase();
    list = list.filter(i => i.itemCode.toLowerCase().includes(term) || i.description.toLowerCase().includes(term));
  }
  const start = (page - 1) * pageSize;
  const data = list.slice(start, start + pageSize);
  const totalCount = list.length;
  const totalPages = Math.ceil(totalCount / pageSize);
  return {
    data,
    totalCount,
    page,
    pageSize,
    totalPages,
    hasNextPage: page < totalPages,
    hasPreviousPage: page > 1
  };
};

export const mockGetRrsCategory = async (organizationId: number, inventoryItemId: number): Promise<RrsCategory> => {
  await delay(100);
  // Specifically trigger validation rule on item 5005 (ITEM-500) under org 110
  if (organizationId === 110 && inventoryItemId === 5005) {
    return { rrsCategory: 'Rn' };
  }
  return { rrsCategory: 'R1' };
};

export const mockGetDemandMetrics = async (
  customerId: number,
  organizationId: number,
  inventoryItemId: number
): Promise<DemandMetrics> => {
  await delay(200);
  // Generate slightly dynamic but realistic metrics
  const seed = (customerId + organizationId + inventoryItemId) % 5;
  return {
    oaPendingQuantity: 50 + seed * 25,
    oaRsvQty: 30 + seed * 15,
    oaPickedQty: 20 + seed * 10,
    binQty: 200 + seed * 50,
    binRsvQty: 80 + seed * 20
  };
};

// --- Core Allocation Services ---

export const mockCreateAllocation = async (req: CreateAllocationRequest): Promise<{ headerId: number }> => {
  await delay(300);
  const headerId = nextHeaderId++;
  const newHeader: B3Header = {
    headerId,
    transactionDate: req.transactionDate || new Date().toISOString().split('T')[0],
    customerOrItemSpecific: req.customerOrItemSpecific ?? 1,
    customerId: req.customerId || null,
    territoryId: req.territoryId || null,
    billToCustomer: req.billToCustomer || null,
    shipToCustomer: req.shipToCustomer || null,
    createdBy: req.createdBy || 'Unknown',
    createdDate: new Date().toISOString(),
    updatedBy: null,
    updatedDate: null,
    remarks: req.remarks || null
  };

  dbHeaders.push(newHeader);

  req.lines.forEach(lineReq => {
    const lineId = nextLineId++;
    const newLine: B3Line = {
      lineId,
      headerId,
      organizationId: lineReq.organizationId || null,
      inventoryItemId: lineReq.inventoryItemId,
      b3Quantity: lineReq.b3Quantity,
      targetDate: lineReq.targetDate || null,
      b3ApprovedQuantity: null,
      approvalFlag: 'N',
      approvedDate: null,
      approvedBy: null,
      closureFlag: 'N',
      revision: 0,
      parentLineId: null
    };
    dbLines.push(newLine);
  });

  return { headerId };
};

// Filter helper to return only the LATEST revision for each unique logical line item
const filterLatestRevisions = (linesList: B3Line[]): B3Line[] => {
  // Logical line items are grouped by their root line ID: (parentLineId ?? lineId)
  const groups: { [key: number]: B3Line[] } = {};
  linesList.forEach(line => {
    const rootId = line.parentLineId ?? line.lineId;
    if (!groups[rootId]) {
      groups[rootId] = [];
    }
    groups[rootId].push(line);
  });

  // For each group, take the one with the maximum revision number
  return Object.values(groups).map(group => {
    return group.reduce((prev, current) => {
      const prevRev = prev.revision ?? 0;
      const curRev = current.revision ?? 0;
      return curRev > prevRev ? current : prev;
    });
  });
};

export const mockGetAllocationByHeaderId = async (headerId: number): Promise<AllocationRow[]> => {
  await delay(200);
  const header = dbHeaders.find(h => h.headerId === headerId);
  if (!header) return [];

  // Filter lines under this header
  const linesUnderHeader = dbLines.filter(l => l.headerId === headerId);
  // Get latest revisions only
  const latestLines = filterLatestRevisions(linesUnderHeader);

  return latestLines.map(line => ({
    ...header,
    lineId: line.lineId,
    organizationId: line.organizationId,
    inventoryItemId: line.inventoryItemId,
    b3Quantity: line.b3Quantity,
    targetDate: line.targetDate,
    b3ApprovedQuantity: line.b3ApprovedQuantity,
    approvalFlag: line.approvalFlag,
    approvedDate: line.approvedDate,
    approvedBy: line.approvedBy,
    closureFlag: line.closureFlag,
    revision: line.revision
  }));
};

export const mockGetAllAllocations = async (): Promise<AllocationRow[]> => {
  await delay(250);
  const rows: AllocationRow[] = [];
  dbHeaders.forEach(header => {
    const linesUnderHeader = dbLines.filter(l => l.headerId === header.headerId);
    const latestLines = filterLatestRevisions(linesUnderHeader);

    latestLines.forEach(line => {
      rows.push({
        ...header,
        lineId: line.lineId,
        organizationId: line.organizationId,
        inventoryItemId: line.inventoryItemId,
        b3Quantity: line.b3Quantity,
        targetDate: line.targetDate,
        b3ApprovedQuantity: line.b3ApprovedQuantity,
        approvalFlag: line.approvalFlag,
        approvedDate: line.approvedDate,
        approvedBy: line.approvedBy,
        closureFlag: line.closureFlag,
        revision: line.revision
      });
    });
  });
  return rows.sort((a, b) => a.headerId - b.headerId || a.lineId - b.lineId);
};

export const mockGetAllocationSummary = async (): Promise<AllocationSummary[]> => {
  await delay(200);
  const summaries: AllocationSummary[] = [];

  dbHeaders.forEach(header => {
    const linesUnderHeader = dbLines.filter(l => l.headerId === header.headerId);
    const latestLines = filterLatestRevisions(linesUnderHeader);

    const totalLines = latestLines.length;
    let totalRequestedQty = 0;
    let totalApprovedQty = 0;
    let approvedLines = 0;
    let pendingLines = 0;
    let cancelledLines = 0;

    latestLines.forEach(line => {
      totalRequestedQty += line.b3Quantity;
      totalApprovedQty += line.b3ApprovedQuantity ?? 0;

      if (line.approvalFlag === 'Y') {
        approvedLines++;
      } else {
        pendingLines++;
      }

      if (line.closureFlag === 'Y' && line.approvalFlag === 'N') {
        cancelledLines++;
      }
    });

    summaries.push({
      headerId: header.headerId,
      transactionDate: header.transactionDate,
      customerId: header.customerId,
      totalLines,
      totalRequestedQty,
      totalApprovedQty,
      approvedLines,
      pendingLines,
      cancelledLines
    });
  });

  return summaries.sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime());
};

export const mockGetPendingApprovalLines = async (): Promise<B3Line[]> => {
  await delay(200);
  const pending = dbLines.filter(l => l.approvalFlag === 'N' && l.closureFlag === 'N');
  return filterLatestRevisions(pending);
};

export const mockReviseQuantity = async (req: ReviseQuantityRequest): Promise<{ newLineId: number, message: string }> => {
  await delay(250);
  const originalLine = dbLines.find(l => l.lineId === req.originalLineId);
  if (!originalLine) {
    throw new Error('Original allocation line not found.');
  }

  const newLineId = nextLineId++;
  const revisedLine: B3Line = {
    lineId: newLineId,
    headerId: originalLine.headerId,
    organizationId: originalLine.organizationId,
    inventoryItemId: originalLine.inventoryItemId,
    b3Quantity: req.newB3Quantity,
    targetDate: originalLine.targetDate,
    b3ApprovedQuantity: null,
    approvalFlag: 'N',
    approvedDate: null,
    approvedBy: null,
    closureFlag: 'N',
    revision: (originalLine.revision ?? 0) + 1,
    parentLineId: originalLine.parentLineId ?? originalLine.lineId
  };

  dbLines.push(revisedLine);
  return {
    newLineId,
    message: 'Revision created successfully.'
  };
};

export const mockGetLineRevisionHistory = async (originalLineId: number): Promise<B3Line[]> => {
  await delay(150);
  // Find the true root line ID
  const line = dbLines.find(l => l.lineId === originalLineId);
  if (!line) return [];

  const rootLineId = line.parentLineId ?? line.lineId;

  // Retrieve all lines that share this root
  return dbLines
    .filter(l => l.lineId === rootLineId || l.parentLineId === rootLineId)
    .sort((a, b) => (a.revision ?? 0) - (b.revision ?? 0));
};

export const mockApproveLine = async (req: ApproveLineRequest): Promise<{ message: string }> => {
  await delay(200);
  const line = dbLines.find(l => l.lineId === req.lineId);
  if (!line) {
    throw new Error('Line not found.');
  }
  if (line.approvalFlag === 'Y' || line.closureFlag === 'Y') {
    throw new Error('Line already approved or closed.');
  }

  line.b3ApprovedQuantity = req.approvedQuantity;
  line.approvalFlag = 'Y';
  line.approvedDate = new Date().toISOString();
  line.approvedBy = req.approvedBy;
  line.closureFlag = 'Y'; // lock down editing on approval

  return { message: 'Line approved successfully.' };
};

export const mockAmendApprovedQuantity = async (req: AmendQuantityRequest): Promise<{ message: string }> => {
  await delay(200);
  const line = dbLines.find(l => l.lineId === req.lineId);
  if (!line) {
    throw new Error('Line not found.');
  }
  // Amendments are allowed on approved lines
  if (line.approvalFlag !== 'Y') {
    throw new Error('Only approved lines can be amended.');
  }

  line.b3ApprovedQuantity = req.amendedQuantity;
  line.approvedDate = new Date().toISOString();
  line.approvedBy = req.amendedBy;
  line.closureFlag = 'Y'; // maintain closure

  return { message: 'Approved quantity amended successfully.' };
};

export const mockCancelLine = async (req: CancelLineRequest): Promise<{ message: string }> => {
  await delay(250);
  const line = dbLines.find(l => l.lineId === req.lineId);
  if (!line) {
    throw new Error('Line not found.');
  }

  // Set line to closed
  line.closureFlag = 'Y';

  // Add cancellation record
  const cancelId = nextCancelId++;
  const cancellation: B3Cancellation = {
    cancelId,
    lineId: req.lineId,
    cancelledQty: req.cancelledQty,
    cancelledDate: new Date().toISOString(),
    cancelReason: req.cancelReason,
    createdBy: req.createdBy,
    createdDate: new Date().toISOString(),
    headerId: line.headerId,
    inventoryItemId: line.inventoryItemId,
    organizationId: line.organizationId,
    originalQuantity: line.b3Quantity,
    approvedQuantity: line.b3ApprovedQuantity,
    transactionDate: new Date().toISOString().split('T')[0]
  };

  dbCancellations.push(cancellation);
  return { message: 'Line cancelled successfully.' };
};

export const mockCancelAllLines = async (req: CancelHeaderRequest): Promise<{ message: string }> => {
  await delay(300);
  const linesUnderHeader = dbLines.filter(l => l.headerId === req.headerId && l.closureFlag === 'N');

  linesUnderHeader.forEach(line => {
    line.closureFlag = 'Y';

    const cancelId = nextCancelId++;
    dbCancellations.push({
      cancelId,
      lineId: line.lineId,
      cancelledQty: line.b3Quantity,
      cancelledDate: new Date().toISOString(),
      cancelReason: req.cancelReason,
      createdBy: req.createdBy,
      createdDate: new Date().toISOString(),
      headerId: req.headerId,
      inventoryItemId: line.inventoryItemId,
      organizationId: line.organizationId,
      originalQuantity: line.b3Quantity,
      approvedQuantity: line.b3ApprovedQuantity,
      transactionDate: new Date().toISOString().split('T')[0]
    });
  });

  return { message: 'All lines for header cancelled successfully.' };
};

export const mockGetAllCancellations = async (): Promise<B3Cancellation[]> => {
  await delay(200);
  return dbCancellations.sort((a, b) => new Date(b.cancelledDate).getTime() - new Date(a.cancelledDate).getTime());
};
