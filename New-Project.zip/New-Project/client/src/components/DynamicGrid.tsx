import React, { useState, useMemo } from 'react';
import { Table, Input, Card, Space } from 'antd';
import type { ColumnsType, TableProps } from 'antd/es/table';
import { Search } from 'lucide-react';

interface DynamicGridProps<RecordType> extends Omit<TableProps<RecordType>, 'columns' | 'dataSource'> {
  columns: ColumnsType<RecordType>;
  dataSource: RecordType[];
  searchPlaceholder?: string;
  extraHeaderActions?: React.ReactNode;
  enableSearch?: boolean;
}

export function DynamicGrid<RecordType extends object>({
  columns,
  dataSource,
  searchPlaceholder = 'Search...',
  extraHeaderActions,
  enableSearch = true,
  ...tableProps
}: DynamicGridProps<RecordType>) {
  const [searchText, setSearchText] = useState('');

  // Local global search filter across all searchable fields
  const filteredData = useMemo(() => {
    if (!searchText) return dataSource;
    const lowerSearch = searchText.toLowerCase();

    return dataSource.filter((record) => {
      return Object.values(record).some((value) => {
        if (value === null || value === undefined) return false;
        
        // Skip searching complex objects/arrays
        if (typeof value === 'object') return false;

        return String(value).toLowerCase().includes(lowerSearch);
      });
    });
  }, [dataSource, searchText]);

  return (
    <Card className="dynamic-grid-card" style={{ borderRadius: 12, border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)', backgroundColor: 'var(--bg-primary)' }}>
      {(enableSearch || extraHeaderActions) && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 12 }}>
          {enableSearch ? (
            <Input
              placeholder={searchPlaceholder}
              prefix={<Search size={16} style={{ color: 'var(--text-secondary)' }} />}
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              allowClear
              style={{ maxWidth: 320, borderRadius: 8 }}
            />
          ) : (
            <div />
          )}
          <Space>{extraHeaderActions}</Space>
        </div>
      )}

      <Table
        columns={columns}
        dataSource={filteredData}
        pagination={{
          defaultPageSize: 10,
          showSizeChanger: true,
          pageSizeOptions: ['5', '10', '20', '50'],
          showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} records`,
          style: { marginTop: 16 }
        }}
        rowKey={(record: any) => record.lineId || record.headerId || record.id || Math.random().toString()}
        scroll={{ x: 'max-content' }}
        {...tableProps}
      />
    </Card>
  );
}
