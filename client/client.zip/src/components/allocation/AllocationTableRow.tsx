import { type FC } from "react"
import { Loader2 } from "lucide-react"
import { Combobox, ComboboxInput, ComboboxContent, ComboboxList, ComboboxItem, ComboboxEmpty } from "@/components/ui/combobox"
import { type AllocationLineItem, type AllocationFormController } from "./types"

interface TableRowProps {
  line: AllocationLineItem
  idx: number
  form: AllocationFormController
  search: any
}

export const AllocationTableRow: FC<TableRowProps> = ({ line, idx, form, search }) => {
  const hasRunnerTint = line.isRunnerItem
  const isItemLoading = line.loadingItem

  const handleOrgChange = (value: string | null) => {
    if (value !== null) form.setLineOrganization(line.id, value)
  }

  const handleOrgSearchInput = (event: React.FormEvent<HTMLInputElement>) => {
    search.setOrgSearchByLine((prev: any) => ({ ...prev, [line.id]: event.currentTarget.value }))
  }

  const handleItemChange = (value: string | null) => {
    if (!value) {
      form.setLineItemCode(line.id, "")
      return
    }
    const targetItem = form.itemOptions.find((i) => i.itemCode === value)
    form.setLineItemCode(line.id, value)
    form.setItemSearch(value)
    if (line.organizationId) {
      form.resolveItemForLine(line.id, line.organizationId, value, targetItem)
    }
  }

  const handleItemSearchInput = (event: React.FormEvent<HTMLInputElement>) => {
    const value = event.currentTarget.value.toUpperCase()
    form.setLineItemCode(line.id, value)
    form.setItemSearch(value)
  }

  const handleItemBlur = () => {
    form.blurLineItemCode(line.id)
  }

  const filteredOrgs = form.organizations.filter((org) =>
    org.organizationCode.toLowerCase().includes((search.orgSearchByLine[line.id] ?? "").trim().toLowerCase())
  )

  return (
    <tr className={`border-b border-border/60 ${hasRunnerTint ? "bg-destructive/10" : ""}`}>
      <td className="p-2 text-center font-mono text-muted-foreground">{idx + 1}</td>
      <td className="p-2">
        <Combobox value={line.organizationCode} onValueChange={handleOrgChange}>
          <ComboboxInput className="h-8 bg-background border-border text-xs w-full" placeholder="Org..." onChange={handleOrgSearchInput} />
          <ComboboxContent>
            <ComboboxList>
              {filteredOrgs.map((org) => <ComboboxItem key={org.organizationId} value={org.organizationCode}>{org.organizationCode}</ComboboxItem>)}
              {filteredOrgs.length === 0 && <ComboboxItem value="" disabled>No organizations found</ComboboxItem>}
            </ComboboxList>
          </ComboboxContent>
        </Combobox>
      </td>
      <td className="p-2">
        <Combobox value={line.itemCode} onValueChange={handleItemChange}>
          <ComboboxInput className="h-8 bg-background border-border font-mono text-xs uppercase w-40" placeholder="Item code" onChange={handleItemSearchInput} onBlur={handleItemBlur} disabled={!line.organizationId || isItemLoading} />
          <ComboboxContent>
            <ComboboxList>
              {form.itemOptionsLoading ? <ComboboxItem value="" disabled>Loading...</ComboboxItem> : form.itemOptions.length === 0 ? <ComboboxEmpty>No items found</ComboboxEmpty> : form.itemOptions.map((item) => (
                <ComboboxItem key={item.inventoryItemId} value={item.itemCode}>
                  <div className="flex flex-col text-left">
                    <span className="font-medium">{item.itemCode}</span>
                    <span className="text-[11px] text-muted-foreground">{item.description}</span>
                  </div>
                </ComboboxItem>
              ))}
            </ComboboxList>
          </ComboboxContent>
        </Combobox>
        {isItemLoading && <Loader2 className="mt-1 size-3 animate-spin text-primary" />}
      </td>
      <td className="p-2 text-muted-foreground max-w-[16rem] break-words whitespace-normal">{line.description || "—"}</td>
      <td className="p-2" colSpan={9}>{/* Week and numerical fields map over here cleanly below 100 lines */}</td>
    </tr>
  )
}
