import { type FC } from "react"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"
import { type Props } from "./types"
import { useAllocationForm } from "@/hooks/useAllocationForm"

export const AllocationHeader = () => {
    const form = useAllocationForm();
    
    return (
        <div className="flex items-center justify-between rounded-xl border border-border bg-card px-6 py-2 shadow-sm">
            <div>
                <h2 className="text-md font-bold text-foreground">New BIN Allocation</h2>
                <p className="text-xs text-muted-foreground">
                    Customer header details and item lines — only B3 header/line fields are saved on submit.
                </p>
            </div>
            <Button
                onClick={form.submitForApproval}
                disabled={!form.canSubmit}
                size="sm"
                className="text-xs font-semibold disabled:opacity-40"
            >
                {form.hasSubmittingState ? (
                    <>
                        <Loader2 className="mr-2 size-3.5 animate-spin" />
                        Submitting...
                    </>
                ) : (
                    "Submit for Approval"
                )}
            </Button>
        </div>
    )
}
