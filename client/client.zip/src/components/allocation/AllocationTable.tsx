import { type FC } from "react"
import { Plus } from "lucide-react"
import { type Props } from "./types"
import { AllocationTableRow } from "./AllocationTableRow"
import { useAllocationSearch } from "./hooks/useAllocationSearch"

export const AllocationTable: FC<Props> = ({ form }) => {
  const search = useAllocationSearch()

  const handleAddLineRow = () => {
    form.addLine()
  }

  return (
    <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Item Lines</h3>
          <p className="mt-1 text-[11px] text-muted-foreground/80">
            Metrics and week are UI-only. Saved: organization, item, quantity, target date.
          </p>
        </div>
        <button type="button" onClick={handleAddLineRow} className="flex items-center gap-1 text-xs font-medium text-primary hover:text-primary/80 cursor-pointer">
          <Plus size={14} /> Add Row
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[1100px] text-left text-xs">
          <thead>
            <tr className="border-b border-border text-[10px] uppercase tracking-wider text-muted-foreground">
              <th className="p-2 w-8">#</th>
              <th className="p-2 w-28">ORG *</th>
              <th className="p-2">Item Code *</th>
              <th className="p-2 min-w-36">Description</th>
              <th className="p-2 w-32">Week *</th>
              <th className="p-2">OA Pend</th>
              <th className="p-2">OA Rsv</th>
              <th className="p-2">OA Picked</th>
              <th className="p-2">BIN Qty</th>
              <th className="p-2">BIN Rsv</th>
              <th className="p-2 w-20">Qty *</th>
              <th className="p-2">Target Date *</th>
              <th className="p-2 w-10"></th>
            </tr>
          </thead>
          <tbody>
            {form.lines.map((line, idx) => (
              <AllocationTableRow
                key={line.id}
                line={line}
                idx={idx}
                form={form}
                search={search}
              />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
