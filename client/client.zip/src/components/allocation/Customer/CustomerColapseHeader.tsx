import { useAllocationForm } from "@/hooks/useAllocationForm";
import { ChevronRight } from "lucide-react";
import { useState } from "react";

export const CustomerColapseHeader = () => {
    const [customerDetailsOpen, setCustomerDetailsOpen] = useState(true)
    const form = useAllocationForm()
    return (
        <div
            onClick={() => setCustomerDetailsOpen((prev) => !prev)}
            className="flex cursor-pointer items-center justify-between border-b border-border px-6 py-4 transition-colors hover:bg-muted/40"
        >
            <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Customer Details
                </h3>

                {!customerDetailsOpen && (
                    <div className="mt-2 flex flex-wrap gap-2 text-[11px]">
                        {form.selectedRegion && (
                            <span className="rounded-md bg-muted px-2 py-1 text-muted-foreground border border-border">
                                Region: {form.selectedRegion}
                            </span>
                        )}

                        {form.operatingUnit && (
                            <span className="rounded-md bg-muted px-2 py-1 text-muted-foreground border border-border">
                                OU: {form.operatingUnit.name}
                            </span>
                        )}

                        {form.billToCustomer && (
                            <span className="rounded-md bg-muted px-2 py-1 text-muted-foreground border border-border">
                                Bill To: {form.billToCustomer.customerName}
                            </span>
                        )}

                        {form.shipToCustomer && (
                            <span className="rounded-md bg-muted px-2 py-1 text-muted-foreground border border-border">
                                Ship To: {form.shipToCustomer.customerName}
                            </span>
                        )}

                        <span className="rounded-md bg-blue-500/10 px-2 py-1 text-blue-600 dark:text-blue-400 border border-blue-500/20 font-medium">
                            {form.allocationBasis === "customer"
                                ? "Customer Specific"
                                : "Open Pool"}
                        </span>
                    </div>
                )}
            </div>

            <ChevronRight
                className={`h-5 w-5 text-muted-foreground transition-transform duration-200 ${customerDetailsOpen ? "rotate-90" : ""
                    }`}
            />
        </div>
    );
}
