import { useState } from "react"

export function useAllocationSearch() {
  const [regionSearch, setRegionSearch] = useState("")
  const [subRegionSearch, setSubRegionSearch] = useState("")
  const [operatingUnitSearch, setOperatingUnitSearch] = useState("")
  const [billToCustomerSearch, setBillToCustomerSearch] = useState("")
  const [shipToCustomerSearch, setShipToCustomerSearch] = useState("")
  const [orgSearchByLine, setOrgSearchByLine] = useState<Record<string, string>>({})
  const [weekSearch, setWeekSearch] = useState("")

  return {
    regionSearch,
    setRegionSearch,
    subRegionSearch,
    setSubRegionSearch,
    operatingUnitSearch,
    setOperatingUnitSearch,
    billToCustomerSearch,
    setBillToCustomerSearch,
    shipToCustomerSearch,
    setShipToCustomerSearch,
    orgSearchByLine,
    setOrgSearchByLine,
    weekSearch,
    setWeekSearch,
  }
}
