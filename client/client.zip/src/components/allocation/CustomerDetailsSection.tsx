import { useState, type JSXElementConstructor, type Key, type ReactElement, type ReactNode, type ReactPortal } from "react";
import { Combobox, ComboboxInput, ComboboxList, ComboboxItem } from "../ui/combobox";
import { ComboboxContent } from "../ui/combobox";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { useAllocationForm } from "@/hooks/useAllocationForm";

const fieldClass = "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:border-primary"

const labelClass = "text-xs font-medium text-muted-foreground block mb-1.5"


export const CustomerDetailsSection = () => {
    const form = useAllocationForm()
    const [customerDetailsOpen, setCustomerDetailsOpen] = useState(true)
    const [regionSearch, setRegionSearch] = useState("")
    const [subRegionSearch, setSubRegionSearch] = useState("")
    const [operatingUnitSearch, setOperatingUnitSearch] = useState("")
    const [billToCustomerSearch, setBillToCustomerSearch] = useState("")
    const [shipToCustomerSearch, setShipToCustomerSearch] = useState("")
    const [billToLocationSearch, setBillToLocationSearch] = useState("")
    const [shipToLocationSearch, setShipToLocationSearch] = useState("")

    const filteredRegionNames = form.regionNames.filter((region: string) =>
        region.toLowerCase().includes(regionSearch.trim().toLowerCase())
    )

    const filteredSubRegions = form.subRegionsForSelected.filter((subRegion: string) =>
        subRegion.toLowerCase().includes(subRegionSearch.trim().toLowerCase())
    )

    const filteredOperatingUnits = form.operatingUnits.filter((unit: { name: string; }) =>
        unit.name.toLowerCase().includes(operatingUnitSearch.trim().toLowerCase())
    )

    const filteredBillToCustomers = form.billToCustomers.filter((customer: { customerName: string; }) =>
        customer.customerName
            .toLowerCase()
            .includes(billToCustomerSearch.trim().toLowerCase())
    )

    const filteredShipToCustomers = form.shipToCustomers.filter((customer: { customerName: string; }) =>
        customer.customerName
            .toLowerCase()
            .includes(shipToCustomerSearch.trim().toLowerCase())
    )

    const filteredBillToAddresses = form.billToAddresses.filter((address: { location: any; address1: any; }) =>
        `${address.location} ${address.address1}`
            .toLowerCase()
            .includes(billToLocationSearch.trim().toLowerCase())
    )

    const filteredShipToAddresses = form.shipToAddresses.filter((address: { location: any; address1: any; }) =>
        `${address.location} ${address.address1}`
            .toLowerCase()
            .includes(shipToLocationSearch.trim().toLowerCase())
    )


    return (
        <div>
            {customerDetailsOpen && (
                <div className="p-6">
                    <div className="mb-4">
                        <Label className={labelClass}>Allocation Type</Label>
                        <div className="flex w-fit gap-2 rounded-lg border border-border bg-muted p-1">
                            <button
                                type="button"
                                onClick={() => form.setAllocationBasis("customer")}
                                className={`rounded-md px-4 py-1.5 text-xs font-medium transition-all cursor-pointer ${form.allocationBasis === "customer"
                                    ? "bg-primary text-primary-foreground shadow-sm"
                                    : "text-muted-foreground hover:text-foreground"
                                    }`}
                            >
                                Customer Specific
                            </button>
                            <button
                                type="button"
                                onClick={() => form.setAllocationBasis("open")}
                                className={`rounded-md px-4 py-1.5 text-xs font-medium transition-all cursor-pointer ${form.allocationBasis === "open"
                                    ? "bg-primary text-primary-foreground shadow-sm"
                                    : "text-muted-foreground hover:text-foreground"
                                    }`}
                            >
                                Open Pool
                            </button>
                        </div>
                    </div>
                    {form.allocationBasis === "customer" && (
                        <div className="grid grid-cols-1 gap-4 md:grid-cols-6">
                            <div className="md:col-span-2">
                                <Label className={labelClass}>Region *</Label>
                                <Combobox
                                    value={form.selectedRegion}
                                    onValueChange={(value) => form.setSelectedRegion(value ?? "")}
                                    disabled={form.regionNames.length === 0}
                                >
                                    <ComboboxInput
                                        className={fieldClass}
                                        placeholder="Select region..."
                                        onChange={(event) => setRegionSearch(event.currentTarget.value)}
                                    />
                                    <ComboboxContent>
                                        <ComboboxList>
                                            {filteredRegionNames.length === 0 ? (
                                                <ComboboxItem value="" disabled>
                                                    No regions found
                                                </ComboboxItem>
                                            ) : (
                                                filteredRegionNames.map((region: unknown) => (
                                                    <ComboboxItem key={region} value={region}>
                                                        <span className="whitespace-nowrap">{region}</span>
                                                    </ComboboxItem>
                                                ))
                                            )}
                                        </ComboboxList>
                                    </ComboboxContent>
                                </Combobox>
                            </div>

                            <div className="md:col-span-2">
                                <Label className={labelClass}>Sub Region *</Label>
                                <Combobox
                                    value={form.selectedSubRegion}
                                    onValueChange={(value) => form.setSelectedSubRegion(value ?? "")}
                                    disabled={!form.selectedRegion || form.subRegionsForSelected.length === 0}
                                >
                                    <ComboboxInput
                                        className={fieldClass}
                                        placeholder={
                                            !form.selectedRegion
                                                ? "Select region first..."
                                                : "Select sub-region..."
                                        }
                                        onChange={(event) => setSubRegionSearch(event.currentTarget.value)}
                                    />
                                    <ComboboxContent>
                                        <ComboboxList>
                                            {filteredSubRegions.length === 0 ? (
                                                <ComboboxItem value="" disabled>
                                                    No sub-regions found
                                                </ComboboxItem>
                                            ) : (
                                                filteredSubRegions.map((subRegion: unknown) => (
                                                    <ComboboxItem key={subRegion} value={subRegion}>
                                                        <span className="whitespace-nowrap">{subRegion}</span>
                                                    </ComboboxItem>
                                                ))
                                            )}
                                        </ComboboxList>
                                    </ComboboxContent>
                                </Combobox>
                            </div>

                            <div className="md:col-span-2">
                                <Label className={labelClass}>Operating Unit *</Label>
                                <Combobox
                                    value={form.operatingUnit ? form.operatingUnit.name : ""}
                                    onValueChange={(value) => {
                                        const unit = form.operatingUnits.find((u: { name: any; }) => u.name === value)
                                        form.setOperatingUnit(unit ?? null)
                                    }}
                                    disabled={!form.selectedRegion}
                                >
                                    <ComboboxInput
                                        className={fieldClass}
                                        placeholder="Select operating unit..."
                                        onChange={(event) => setOperatingUnitSearch(event.currentTarget.value)}
                                    />
                                    <ComboboxContent>
                                        <ComboboxList>
                                            {filteredOperatingUnits.length === 0 ? (
                                                <ComboboxItem value="" disabled>
                                                    No operating units found
                                                </ComboboxItem>
                                            ) : (
                                                filteredOperatingUnits.map((unit: { organizationId: Key | null | undefined; name: unknown; }) => (
                                                    <ComboboxItem
                                                        key={unit.organizationId}
                                                        value={unit.name}
                                                    >
                                                        <span className="whitespace-nowrap">{unit.name}</span>
                                                    </ComboboxItem>
                                                ))
                                            )}
                                        </ComboboxList>
                                    </ComboboxContent>
                                </Combobox>
                            </div>

                            <div className="md:col-span-3">
                                <Label className={labelClass}>Bill To Customer *</Label>
                                <Combobox
                                    value={form.billToCustomer ? form.billToCustomer.customerName : ""}
                                    onValueChange={(value) => {
                                        const customer = form.billToCustomers.find((c: { customerName: any; }) => c.customerName === value)
                                        form.setBillToCustomer(customer ?? null)
                                    }}
                                    disabled={!form.operatingUnit}
                                >
                                    <ComboboxInput
                                        className={fieldClass}
                                        placeholder="Select bill-to customer..."
                                        onChange={(event) => setBillToCustomerSearch(event.currentTarget.value)}
                                    />
                                    <ComboboxContent>
                                        <ComboboxList>
                                            {filteredBillToCustomers.length === 0 ? (
                                                <ComboboxItem value="" disabled>
                                                    No customers found
                                                </ComboboxItem>
                                            ) : (
                                                filteredBillToCustomers.map((customer: { customerId: Key | null | undefined; customerName: unknown; }) => (
                                                    <ComboboxItem
                                                        key={customer.customerId}
                                                        value={customer.customerName}
                                                    >
                                                        <span className="whitespace-nowrap">{customer.customerName}</span>
                                                    </ComboboxItem>
                                                ))
                                            )}
                                        </ComboboxList>
                                    </ComboboxContent>
                                </Combobox>
                            </div>

                            <div className="md:col-span-3">
                                <Label className={labelClass}>Ship To Customer *</Label>
                                <Combobox
                                    value={form.shipToCustomer ? form.shipToCustomer.customerName : ""}
                                    onValueChange={(value) => {
                                        const customer = form.shipToCustomers.find((c: { customerName: any; }) => c.customerName === value)
                                        form.setShipToCustomer(customer ?? null)
                                    }}
                                    disabled={!form.operatingUnit}
                                >
                                    <ComboboxInput
                                        className={fieldClass}
                                        placeholder="Select ship-to customer..."
                                        onChange={(event) => setShipToCustomerSearch(event.currentTarget.value)}
                                    />
                                    <ComboboxContent>
                                        <ComboboxList>
                                            {filteredShipToCustomers.length === 0 ? (
                                                <ComboboxItem value="" disabled>
                                                    No customers found
                                                </ComboboxItem>
                                            ) : (
                                                filteredShipToCustomers.map((customer: { customerId: Key | null | undefined; customerName: unknown; }) => (
                                                    <ComboboxItem
                                                        key={customer.customerId}
                                                        value={customer.customerName}
                                                    >
                                                        <span className="whitespace-nowrap">{customer.customerName}</span>
                                                    </ComboboxItem>
                                                ))
                                            )}
                                        </ComboboxList>
                                    </ComboboxContent>
                                </Combobox>
                            </div>

                            <div className="md:col-span-3">
                                <Label className={labelClass}>Bill To Location *</Label>
                                <Combobox
                                    value={
                                        form.billToLocation
                                            ? `${form.billToLocation.location}-${form.billToLocation.address1}`
                                            : ""
                                    }
                                    onValueChange={(value) => {
                                        const address = form.billToAddresses.find(
                                            (a: { location: any; address1: any; }) => `${a.location}-${a.address1}` === value
                                        )
                                        form.setBillToLocation(address ?? null)
                                    }}
                                    disabled={!form.billToCustomer || form.billToAddresses.length === 0}
                                >
                                    <ComboboxInput
                                        className={fieldClass}
                                        placeholder="Select location..."
                                        onChange={(event) => setBillToLocationSearch(event.currentTarget.value)}
                                    />
                                    <ComboboxContent>
                                        <ComboboxList>
                                            {filteredBillToAddresses.length === 0 ? (
                                                <ComboboxItem value="" disabled>
                                                    No locations found
                                                </ComboboxItem>
                                            ) : (
                                                filteredBillToAddresses.map((address: { location: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | Promise<string | number | bigint | boolean | ReactPortal | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; address1: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | Promise<string | number | bigint | boolean | ReactPortal | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; }) => (
                                                    <ComboboxItem
                                                        key={`${address.location}-${address.address1}`}
                                                        value={`${address.location}-${address.address1}`}
                                                    >
                                                        <div className="flex flex-col text-left">
                                                            <span>{address.location}</span>
                                                            <span className="text-[11px] text-muted-foreground">
                                                                {address.address1}
                                                            </span>
                                                        </div>
                                                    </ComboboxItem>
                                                ))
                                            )}
                                        </ComboboxList>
                                    </ComboboxContent>
                                </Combobox>
                            </div>

                            <div className="md:col-span-3">
                                <Label className={labelClass}>Ship To Location *</Label>
                                <Combobox
                                    value={
                                        form.shipToLocation
                                            ? `${form.shipToLocation.location}-${form.shipToLocation.address1}`
                                            : ""
                                    }
                                    onValueChange={(value) => {
                                        const address = form.shipToAddresses.find(
                                            (a: { location: any; address1: any; }) => `${a.location}-${a.address1}` === value
                                        )
                                        form.setShipToLocation(address ?? null)
                                    }}
                                    disabled={!form.shipToCustomer || form.shipToAddresses.length === 0}
                                >
                                    <ComboboxInput
                                        className={fieldClass}
                                        placeholder="Select location..."
                                        onChange={(event) => setShipToLocationSearch(event.currentTarget.value)}
                                    />
                                    <ComboboxContent>
                                        <ComboboxList>
                                            {filteredShipToAddresses.length === 0 ? (
                                                <ComboboxItem value="" disabled>
                                                    No locations found
                                                </ComboboxItem>
                                            ) : (
                                                filteredShipToAddresses.map((address: { location: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | Promise<string | number | bigint | boolean | ReactPortal | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; address1: string | number | bigint | boolean | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | Promise<string | number | bigint | boolean | ReactPortal | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined; }) => (
                                                    <ComboboxItem
                                                        key={`${address.location}-${address.address1}`}
                                                        value={`${address.location}-${address.address1}`}
                                                    >
                                                        <div className="flex flex-col text-left">
                                                            <span>{address.location}</span>
                                                            <span className="text-[11px] text-muted-foreground">
                                                                {address.address1}
                                                            </span>
                                                        </div>
                                                    </ComboboxItem>
                                                ))
                                            )}
                                        </ComboboxList>
                                    </ComboboxContent>
                                </Combobox>
                            </div>

                            <div className="md:col-span-3">
                                <Label className={labelClass}>Bill To Address</Label>
                                <div className="min-h-[72px] rounded-lg border border-border bg-background px-3 py-2 text-sm leading-relaxed text-muted-foreground whitespace-pre-wrap break-words">
                                    {form.billToLocation
                                        ? form.formatAddress(form.billToLocation)
                                        : "Select a Bill To location"}
                                </div>
                            </div>

                            <div className="md:col-span-3">
                                <Label className={labelClass}>Ship To Address</Label>
                                <div className="min-h-[72px] rounded-lg border border-border bg-background px-3 py-2 text-sm leading-relaxed text-muted-foreground whitespace-pre-wrap break-words">
                                    {form.shipToLocation
                                        ? form.formatAddress(form.shipToLocation)
                                        : "Select a Ship To location"}
                                </div>
                            </div>

                            <div className="md:col-span-6">
                                <Label className={labelClass}>Remarks</Label>
                                <Textarea
                                    value={form.remarks}
                                    onChange={(e) => form.setRemarks(e.target.value)}
                                    placeholder="Optional header remarks (saved to JAN_B3_HEADER.REMARKS)"
                                    className={`${fieldClass} min-h-20 resize-none`}
                                    maxLength={250}
                                />
                            </div>
                        </div>
                    )}
                    {form.allocationBasis === "open" && (
                        <div>
                            <Label className={labelClass}>Remarks</Label>
                            <Textarea
                                value={form.remarks}
                                onChange={(e) => form.setRemarks(e.target.value)}
                                placeholder="Enter remarks for Open Pool allocation"
                                className={`${fieldClass} min-h-24 resize-none`}
                                maxLength={250}
                            />
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}