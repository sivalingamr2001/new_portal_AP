import { useAllocationForm } from "@/hooks/useAllocationForm";
import { AlertTriangle } from "lucide-react";

export const AllocationFooter = () => {
    const form = useAllocationForm();

    return (
        <div>
            {form.lines.some((l) => l.itemError) && (
                <div className="mt-3 space-y-1">
                    {form.lines
                        .filter((l) => l.itemError)
                        .map((l) => (
                            <p key={l.id} className="flex items-center gap-1.5 text-[11px] text-destructive">
                                <AlertTriangle size={12} />
                                Row {form.lines.indexOf(l) + 1}: {l.itemError}
                            </p>
                        ))}
                </div>
            )}

            {!form.headerComplete && form.allocationBasis === "customer" && (
                <p className="mt-3 text-[11px] text-amber-600 dark:text-amber-400 font-medium">
                    Complete all required customer header fields before submitting.
                </p>
            )}
            {form.headerComplete && form.validLines.length === 0 && (
                <p className="mt-3 text-[11px] text-amber-600 dark:text-amber-400 font-medium">
                    Add at least one valid item line (non-runner, with org, item, week, qty, and target date).
                </p>
            )}
        </div>
    );
}
