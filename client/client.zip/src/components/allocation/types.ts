import { type ComponentPropsWithoutRef } from "react"
import {
  type AllocationRow,
  type AllocationSummary,
  type B3Line,
  type B3Cancellation,
  type CreateAllocationRequest,
  type ReviseQuantityRequest,
  type ReviseQuantityResponse,
  type ApproveLineRequest,
  type AmendQuantityRequest,
  type CancelLineRequest,
  type CancelHeaderRequest,
  type ActionResponse,
} from "@/api/binAllocationApi"

export interface AllocationLineItem {
  id: string
  organizationId?: string
  organizationCode: string
  itemCode: string
  description: string
  week: string
  loadingItem: boolean
  isRunnerItem: boolean
  quantity: number
  targetDate: string
}

export interface AllocationFormController {
  selectedRegion: string
  setSelectedRegion: (v: string) => void
  operatingUnit: { name: string } | null
  setOperatingUnit: (v: { name: string; organizationId: string } | null) => void
  billToCustomer: { customerName: string; customerId: string } | null
  setBillToCustomer: (v: { customerName: string; customerId: string } | null) => void
  shipToCustomer: { customerName: string; customerId: string } | null
  setShipToCustomer: (v: { customerName: string; customerId: string } | null) => void
  allocationBasis: "customer" | "open"
  setAllocationBasis: (v: "customer" | "open") => void
  remarks: string
  setRemarks: (v: string) => void
  regionNames: string[]
  subRegionsForSelected: string[]
  selectedSubRegion: string
  setSelectedSubRegion: (v: string) => void
  operatingUnits: Array<{ name: string; organizationId: string }>
  billToCustomers: Array<{ customerName: string; customerId: string }>
  shipToCustomers: Array<{ customerName: string; customerId: string }>
  lines: AllocationLineItem[]
  addLine: () => void
  setLineOrganization: (id: string, code: string) => void
  setLineItemCode: (id: string, code: string) => void
  setItemSearch: (v: string) => void
  resolveItemForLine: (id: string, orgId: string, itemCode: string, itemOption: any) => void
  blurLineItemCode: (id: string) => void
  updateLine: (id: string, updates: Partial<AllocationLineItem>) => void
  organizations: Array<{ organizationId: string; organizationCode: string }>
  itemOptions: Array<{ inventoryItemId: string; itemCode: string; description: string }>
  itemOptionsLoading: boolean
  canSubmit: boolean
  submitting: boolean
  submitForApproval: () => void
}

export interface Props extends ComponentPropsWithoutRef<"div"> {
  form: AllocationFormController
}
