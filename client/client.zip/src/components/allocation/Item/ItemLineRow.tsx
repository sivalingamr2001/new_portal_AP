import { memo, useMemo } from "react";
import { Loader2, Trash2 } from "lucide-react";
import { Combobox, ComboboxContent, ComboboxEmpty, ComboboxInput, ComboboxItem, ComboboxList } from "@/components/ui/combobox";
import { Input } from "@/components/ui/input";

// Form and Data Type Contract Specifications
export interface AllocationLine {
    id: string;
    organizationId?: string;
    organizationCode?: string;
    itemCode: string;
    description?: string;
    week: string;
    loadingItem?: boolean;
    isRunnerItem?: boolean;
    itemError?: string;
    quantity: number | "";
    targetDate: string;
    metrics?: {
        oaPendingQuantity?: number;
        oaRsvQty?: number;
        oaPickedQty?: number;
        binQty?: number;
        binRsvQty?: number;
    };
}

export interface AllocationFormHook {
    lines: AllocationLine[];
    organizations: Array<{ organizationId: string; organizationCode: string }>;
    weekOptions: string[];
    itemOptions: Array<{ inventoryItemId: string; itemCode: string; description: string }>;
    itemOptionsLoading: boolean;
    headerComplete: boolean;
    allocationBasis: "customer" | string;
    validLines: any[];
    addLine: () => void;
    removeLine: (id: string) => void;
    updateLine: (id: string, updates: Partial<AllocationLine>) => void;
    setLineOrganization: (id: string, code: string) => void;
    setLineItemCode: (id: string, code: string) => void;
    setItemSearch: (search: string) => void;
    blurLineItemCode: (id: string) => void;
    resolveItemForLine: (id: string, orgId: string, itemCode: string, selectedItem: any) => void;
}

interface ItemLineRowProps {
    idx: number;
    line: AllocationLine;
    form: AllocationFormHook;
    orgSearch: string;
    weekSearch: string;
    setOrgSearch: (val: string) => void;
    setWeekSearch: (val: string) => void;
}

// Memory-isolated component cell rendering to prevent metrics rewriting cycles
const MetricsCell = memo(({ value }: { value?: number }) => (
    <span>{value !== undefined && value !== null ? value : "—"}</span>
));
MetricsCell.displayName = "MetricsCell";

export const ItemLineRow = memo(({
    idx,
    line,
    form,
    orgSearch,
    weekSearch,
    setOrgSearch,
    setWeekSearch
}: ItemLineRowProps) => {
    const filteredOrgs = useMemo(() => {
        const query = orgSearch.trim().toLowerCase();
        return form.organizations.filter((org) =>
            org.organizationCode.toLowerCase().includes(query)
        );
    }, [form.organizations, orgSearch]);

    const filteredWeeks = useMemo(() => {
        const query = weekSearch.trim().toLowerCase();
        return form.weekOptions.filter((week: string) =>
            week.toLowerCase().includes(query)
        );
    }, [form.weekOptions, weekSearch]);

    return (
        <tr className={`border-b border-border/60 ${line.isRunnerItem ? "bg-destructive/10" : ""}`}>
            {/* Index Counter Column */}
            <td className="p-2 text-center font-mono text-muted-foreground">{idx + 1}</td>

            {/* Organization Dropdown Field */}
            <td className="p-2">
                <Combobox
                    value={line.organizationCode}
                    onValueChange={(value: string | null) => {
                        if (value === null) return;
                        form.setLineOrganization(line.id, value);
                    }}
                >
                    <ComboboxInput
                        className="h-8 bg-background border-border text-xs w-full"
                        placeholder="Org..."
                        onChange={(e: { currentTarget: { value: string; }; }) => setOrgSearch(e.currentTarget.value)}
                    />
                    <ComboboxContent>
                        <ComboboxList>
                            {filteredOrgs.map((org) => (
                                <ComboboxItem key={org.organizationId} value={org.organizationCode}>
                                    {org.organizationCode}
                                </ComboboxItem>
                            ))}
                            {filteredOrgs.length === 0 && (
                                <ComboboxItem value="" disabled>No organizations found</ComboboxItem>
                            )}
                        </ComboboxList>
                    </ComboboxContent>
                </Combobox>
            </td>

            {/* Inventory Item Auto-Suggest Search Input Field */}
            <td className="p-2">
                <div className="relative flex items-center">
                    <Combobox
                        value={line.itemCode}
                        onValueChange={(value: string | null) => {
                            if (!value) {
                                form.setLineItemCode(line.id, "");
                                return;
                            }
                            const selectedItem = form.itemOptions.find((item) => item.itemCode === value);
                            form.setLineItemCode(line.id, value);
                            form.setItemSearch(value);
                            if (line.organizationId) {
                                form.resolveItemForLine(line.id, line.organizationId, value, selectedItem);
                            }
                        }}
                    >
                        <ComboboxInput
                            className="h-8 bg-background border-border font-mono text-xs uppercase w-40"
                            placeholder="Item code"
                            onChange={(event: { currentTarget: { value: string; }; }) => {
                                const value = event.currentTarget.value.toUpperCase();
                                form.setLineItemCode(line.id, value);
                                form.setItemSearch(value);
                            }}
                            onBlur={() => form.blurLineItemCode(line.id)}
                            disabled={!line.organizationId || line.loadingItem}
                        />
                        <ComboboxContent>
                            <ComboboxList>
                                {form.itemOptionsLoading ? (
                                    <ComboboxItem value="" disabled>Loading...</ComboboxItem>
                                ) : form.itemOptions.length === 0 ? (
                                    <ComboboxEmpty>No items found</ComboboxEmpty>
                                ) : (
                                    form.itemOptions.map((item) => (
                                        <ComboboxItem key={item.inventoryItemId} value={item.itemCode}>
                                            <div className="flex flex-col text-left">
                                                <span className="font-medium">{item.itemCode}</span>
                                                <span className="text-[11px] text-muted-foreground">{item.description}</span>
                                            </div>
                                        </ComboboxItem>
                                    ))
                                )}
                            </ComboboxList>
                        </ComboboxContent>
                    </Combobox>
                    {line.loadingItem && (
                        <span className="absolute right-2 top-1/2 -translate-y-1/2">
                            <Loader2 className="size-3 animate-spin text-primary" />
                        </span>
                    )}
                </div>
            </td>

            {/* Item Catalog Extended Text Description */}
            <td className="p-2 text-muted-foreground max-w-[16rem] wrap-break-word whitespace-normal">
                {line.description || "—"}
            </td>

            {/* Delivery target/schedule window select column */}
            <td className="p-2">
                <Combobox
                    value={line.week}
                    onValueChange={(value: string | null) => {
                        if (value === null) return;
                        form.updateLine(line.id, { week: value });
                    }}
                >
                    <ComboboxInput
                        className="h-8 bg-background border-border text-xs w-full"
                        placeholder="Week"
                        onChange={(event: { currentTarget: { value: string; }; }) => setWeekSearch(event.currentTarget.value)}
                    />
                    <ComboboxContent>
                        <ComboboxList>
                            {filteredWeeks.length === 0 ? (
                                <ComboboxItem value="" disabled>No weeks found</ComboboxItem>
                            ) : (
                                filteredWeeks.map((week) => (
                                    <ComboboxItem key={week} value={week}>
                                        {week}
                                    </ComboboxItem>
                                ))
                            )}
                        </ComboboxList>
                    </ComboboxContent>
                </Combobox>
            </td>

            {/* Metrics Breakdown Tracking Grid Blocks */}
            <td className="p-2 font-mono"><MetricsCell value={line.metrics?.oaPendingQuantity} /></td>
            <td className="p-2 font-mono"><MetricsCell value={line.metrics?.oaRsvQty} /></td>
            <td className="p-2 font-mono"><MetricsCell value={line.metrics?.oaPickedQty} /></td>
            <td className="p-2 font-mono"><MetricsCell value={line.metrics?.binQty} /></td>
            <td className="p-2 font-mono"><MetricsCell value={line.metrics?.binRsvQty} /></td>

            {/* Allocation Count Demand Value Input Box */}
            <td className="p-2">
                <Input
                    type="number"
                    min={1}
                    value={line.quantity}
                    onChange={(e: { target: { value: string; }; }) =>
                        form.updateLine(line.id, {
                            quantity: e.target.value === "" ? "" : Number(e.target.value),
                        })
                    }
                    disabled={line.isRunnerItem}
                    className="h-8 bg-background border-border font-mono text-xs"
                    placeholder="Qty"
                />
            </td>

            {/* Target Delivery Date Field picker element */}
            <td className="p-2">
                <Input
                    type="date"
                    value={line.targetDate}
                    onChange={(e: { target: { value: any; }; }) => form.updateLine(line.id, { targetDate: e.target.value })}
                    disabled={line.isRunnerItem}
                    className="h-8 bg-background border-border text-xs"
                />
            </td>

            {/* Individual Row Removals/Deletion Trigger Call-To-Action */}
            <td className="p-2">
                <button
                    type="button"
                    onClick={() => form.removeLine(line.id)}
                    className="p-1.5 text-muted-foreground/60 transition-colors hover:text-destructive"
                    aria-label={`Delete row ${idx + 1}`}
                >
                    <Trash2 size={14} />
                </button>
            </td>
        </tr>
    );
});
ItemLineRow.displayName = "ItemLineRow";
