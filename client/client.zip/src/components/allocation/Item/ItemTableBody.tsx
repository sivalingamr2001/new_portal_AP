import { ComboboxContent } from "@/components/ui/combobox";
import { Combobox, ComboboxInput, ComboboxList, ComboboxItem, ComboboxEmpty } from "@/components/ui/combobox";
import { Input } from "@/components/ui/input";
import { useAllocationForm } from "@/hooks/useAllocationForm";
import { Loader2, Trash2 } from "lucide-react";
import { useState } from "react";

export const ItemTableBody = () => {
    const form = useAllocationForm();
    const [orgSearchByLine, setOrgSearchByLine] = useState<Record<string, string>>({});
    const [weekSearch, setWeekSearch] = useState<Record<string, string>>({});

    const filteredWeeks = form.weekOptions.filter((week) =>
        week.toLowerCase().includes(weekSearch.trim().toLowerCase())
    )

    return (
        <tbody>
            {form.lines.map((line, idx) => (
                <tr
                    key={line.id}
                    className={`border-b border-border/60 ${line.isRunnerItem ? "bg-destructive/10" : ""}`}
                >
                    <td className="p-2 text-center font-mono text-muted-foreground">{idx + 1}</td>
                    <td className="p-2">
                        <Combobox
                            value={line.organizationCode}
                            onValueChange={(value) => {
                                if (value === null) return
                                form.setLineOrganization(line.id, value)
                            }}
                        >
                            <ComboboxInput
                                className="h-8 bg-background border-border text-xs w-full"
                                placeholder="Org..."
                                onChange={(event) =>
                                    setOrgSearchByLine((prev) => ({
                                        ...prev,
                                        [line.id]: event.currentTarget.value,
                                    }))
                                }
                            />
                            <ComboboxContent>
                                <ComboboxList>
                                    {form.organizations
                                        .filter((org) =>
                                            org.organizationCode
                                                .toLowerCase()
                                                .includes((orgSearchByLine[line.id] ?? "").trim().toLowerCase())
                                        )
                                        .map((org) => (
                                            <ComboboxItem
                                                key={org.organizationId}
                                                value={org.organizationCode}
                                            >
                                                {org.organizationCode}
                                            </ComboboxItem>
                                        ))}
                                    {form.organizations.filter((org) =>
                                        org.organizationCode
                                            .toLowerCase()
                                            .includes((orgSearchByLine[line.id] ?? "").trim().toLowerCase())
                                    ).length === 0 && (
                                            <ComboboxItem value="" disabled>
                                                No organizations found
                                            </ComboboxItem>
                                        )}
                                </ComboboxList>
                            </ComboboxContent>
                        </Combobox>
                    </td>
                    <td className="p-2">
                        <Combobox
                            value={line.itemCode}
                            onValueChange={(value) => {
                                if (!value) {
                                    form.setLineItemCode(line.id, "")
                                    return
                                }
                                const selectedItem = form.itemOptions.find(
                                    (item) => item.itemCode === value
                                )
                                form.setLineItemCode(line.id, value)
                                form.setItemSearch(value)
                                if (line.organizationId) {
                                    form.resolveItemForLine(
                                        line.id,
                                        line.organizationId,
                                        value,
                                        selectedItem
                                    )
                                }
                            }}
                        >
                            <ComboboxInput
                                className="h-8 bg-background border-border font-mono text-xs uppercase w-40"
                                placeholder="Item code"
                                onChange={(event) => {
                                    const value = event.currentTarget.value.toUpperCase()
                                    form.setLineItemCode(line.id, value)
                                    form.setItemSearch(value)
                                }}
                                onBlur={() => form.blurLineItemCode(line.id)}
                                disabled={!line.organizationId || line.loadingItem}
                            />
                            <ComboboxContent>
                                <ComboboxList>
                                    {form.itemOptionsLoading ? (
                                        <ComboboxItem value="" disabled>
                                            Loading...
                                        </ComboboxItem>
                                    ) : form.itemOptions.length === 0 ? (
                                        <ComboboxEmpty>No items found</ComboboxEmpty>
                                    ) : (
                                        form.itemOptions.map((item) => (
                                            <ComboboxItem key={item.inventoryItemId} value={item.itemCode}>
                                                <div className="flex flex-col text-left">
                                                    <span className="font-medium">{item.itemCode}</span>
                                                    <span className="text-[11px] text-muted-foreground">{item.description}</span>
                                                </div>
                                            </ComboboxItem>
                                        ))
                                    )}
                                </ComboboxList>
                            </ComboboxContent>
                        </Combobox>
                        {line.loadingItem && (
                            <Loader2 className="mt-1 size-3 animate-spin text-primary" />
                        )}
                    </td>
                    <td className="p-2 text-muted-foreground max-w-[16rem] break-words whitespace-normal">
                        {line.description || "—"}
                    </td>
                    <td className="p-2">
                        <Combobox
                            value={line.week}
                            onValueChange={(value) => {
                                if (value === null) return
                                form.updateLine(line.id, { week: value })
                            }}
                        >
                            <ComboboxInput
                                className="h-8 bg-background border-border text-xs w-full"
                                placeholder="Week"
                                onChange={(event) => setWeekSearch(event.currentTarget.value)}
                            />
                            <ComboboxContent>
                                <ComboboxList>
                                    {filteredWeeks.length === 0 ? (
                                        <ComboboxItem value="" disabled>
                                            No weeks found
                                        </ComboboxItem>
                                    ) : (
                                        filteredWeeks.map((week) => (
                                            <ComboboxItem key={week} value={week}>
                                                {week}
                                            </ComboboxItem>
                                        ))
                                    )}
                                </ComboboxList>
                            </ComboboxContent>
                        </Combobox>
                    </td>
                    <td className="p-2">
                        <MetricsCell value={line.metrics?.oaPendingQuantity} />
                    </td>
                    <td className="p-2">
                        <MetricsCell value={line.metrics?.oaRsvQty} />
                    </td>
                    <td className="p-2">
                        <MetricsCell value={line.metrics?.oaPickedQty} />
                    </td>
                    <td className="p-2">
                        <MetricsCell value={line.metrics?.binQty} />
                    </td>
                    <td className="p-2">
                        <MetricsCell value={line.metrics?.binRsvQty} />
                    </td>
                    <td className="p-2">
                        <Input
                            type="number"
                            min={1}
                            value={line.quantity}
                            onChange={(e) =>
                                form.updateLine(line.id, {
                                    quantity: e.target.value === "" ? "" : Number(e.target.value),
                                })
                            }
                            disabled={line.isRunnerItem}
                            className="h-8 bg-background border-border font-mono text-xs"
                            placeholder="Qty"
                        />
                    </td>
                    <td className="p-2">
                        <Input
                            type="date"
                            value={line.targetDate}
                            onChange={(e) =>
                                form.updateLine(line.id, { targetDate: e.target.value })
                            }
                            disabled={line.isRunnerItem}
                            className="h-8 bg-background border-border text-xs"
                        />
                    </td>
                    <td className="p-2">
                        <button
                            type="button"
                            onClick={() => form.removeLine(line.id)}
                            className="p-1.5 text-muted-foreground/60 transition-colors hover:text-destructive cursor-pointer"
                        >
                            <Trash2 size={14} />
                        </button>
                    </td>
                </tr>
            ))}
        </tbody>
    );
}