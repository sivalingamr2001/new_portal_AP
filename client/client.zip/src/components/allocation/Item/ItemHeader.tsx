import { useAllocationForm } from "@/hooks/useAllocationForm";
import { Plus } from "lucide-react";

export const ItemHeader = () => {
    
    const form = useAllocationForm();

    return (
        <div className="mb-4 flex items-center justify-between">
            <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Item Lines
                </h3>
                <p className="mt-1 text-[11px] text-muted-foreground/80">
                    Metrics and week are UI-only. Saved: organization, item, quantity, target date.
                </p>
            </div>
            <button
                type="button"
                onClick={form.addLine}
                className="flex items-center gap-1 text-xs font-medium text-primary hover:text-primary/80 cursor-pointer"
            >
                <Plus size={14} /> Add Row
            </button>
        </div>
    );
}