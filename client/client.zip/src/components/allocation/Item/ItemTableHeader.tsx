export const ItemTableHeader = () => {
    return (
        <thead>
            <tr className="border-b border-border text-[10px] uppercase tracking-wider text-muted-foreground">
                <th className="p-2 w-8">#</th>
                <th className="p-2 w-28">ORG *</th>
                <th className="p-2">Item Code *</th>
                <th className="p-2 min-w-36">Description</th>
                <th className="p-2 w-32">Week *</th>
                <th className="p-2">OA Pend</th>
                <th className="p-2">OA Rsv</th>
                <th className="p-2">OA Picked</th>
                <th className="p-2">BIN Qty</th>
                <th className="p-2">BIN Rsv</th>
                <th className="p-2 w-20">Qty *</th>
                <th className="p-2">Target Date *</th>
                <th className="p-2 w-10"></th>
            </tr>
        </thead>
    );
}