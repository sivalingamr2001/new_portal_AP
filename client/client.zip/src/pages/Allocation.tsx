import { AlertTriangle, ChevronRight, Loader2, Plus, Trash2 } from "lucide-react"

import { useState } from "react"

import { Loader } from "@/components/Loader"
import { Button } from "@/components/ui/button"
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useAllocationForm } from "@/hooks/useAllocationForm"
import { AppHeader } from "@/layout/AppHeader"
import { AllocationHeader } from "@/components/allocation/AllocationHeader"
import { CustomerColapseHeader } from "@/components/allocation/Customer/CustomerColapseHeader"
import { CustomerDetailsSection } from "@/components/allocation/CustomerDetailsSection"
import { ItemHeader } from "@/components/ui/item"
import { ItemTableHeader } from "@/components/allocation/Item/ItemTableHeader"
import { ItemTableBody } from "@/components/allocation/Item/ItemTableBody"
import { AllocationFooter } from "@/components/allocation/AllocationFooter"

const fieldClass =
  "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:border-primary"

const labelClass = "text-xs font-medium text-muted-foreground block mb-1.5"

function MetricsCell({ value }: { value: number | undefined }) {
  return (
    <span className="font-mono text-[11px] text-muted-foreground font-medium">
      {value?.toLocaleString() ?? "—"}
    </span>
  )
}

export function AllocationScreen() {


  if (form.loadingInitial) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader />
      </div>
    )
  }

  return (
    <div className="space-y-2">
      <AllocationHeader />

      {/* Header — customer details */}
      <div className="overflow-hidden rounded-xl border border-border bg-card shadow-sm">
        <CustomerColapseHeader />


        <CustomerDetailsSection />
      </div>

      {/* Item lines */}
      <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
        <ItemHeader />

        <div className="overflow-x-auto">
          <table className="w-full min-w-[1100px] text-left text-xs">
            <ItemTableHeader />
            <ItemTableBody />
          </table>
        </div>

        <AllocationFooter />
      </div>
    </div>
  )
}
